package com.ca.usm.plugins.samples.applications.pam;

import java.util.Base64;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.Authenticator;
import org.json.*;

import com.ca.usm.plugins.apis.PluginContext;
import com.ca.usm.plugins.apis.forms.FDOption;
import com.ca.usm.plugins.apis.forms.FDSelectDataProvider;
import com.ca.usm.plugins.samples.applications.utils.BasicAuthenticator;

import org.apache.commons.logging.Log;

public class GetSrfsPAM implements FDSelectDataProvider {

	private PluginContext context;
	private Log log;
	private int count;

	
	
	@Override
	public void setContext(PluginContext context) {
		this.context = context;
		this.log = this.context.getLogger(GetSrfsPAM.class);
		
		
	}

	@Override
	public void setInputs(Map<String, Object> inputs) {
		// TODO Auto-generated method stub
	    
	}

	@Override
	public List<FDOption> getOptions(int start, int numToReturn) {
		
		this.log.info("***** Inicio plugin ****** ");
		
		List<FDOption> options = new LinkedList<FDOption>();
		
		Map<String, Object> itpamConf =this.context.getSystemConfigValues("itpam");
		
		String servidor = itpamConf.get("hostname").toString();
		String puerto= itpamConf.get("portno").toString();
		String user = itpamConf.get("login").toString();
		String pass = itpamConf.get("password").toString();
		String enableHttps = itpamConf.get("enablehttps").toString();
		String protocol ="";
		
			
		if(enableHttps.equals("false")) {			
			protocol ="http://";
		}else {
			protocol="https://";
		}
		
		
		
		String uri = protocol+servidor+":"+puerto+"/api/rest/v1/srfs";
		
		this.log.info("Consumo web service PAM " + uri);
		
		try {
			
			URL url = new URL(uri);
			HttpURLConnection con = (HttpURLConnection) url.openConnection();
			
			String credentials = user+":"+pass;
			String basicAuth = "Basic " + new String(Base64.getEncoder().encode(credentials.getBytes()));
						
			
			Authenticator.setDefault(new BasicAuthenticator(user, pass));
			//con.setRequestProperty("Authorization", basicAuth);
			con.setRequestProperty("Content-Type", "application/xml");
			con.setRequestMethod("GET");
			this.log.info("test");
			this.log.info(con.getHeaderField("Authorization"));
			
			int responseCode = con.getResponseCode();
			
			if(responseCode !=200) {
				
				this.log.error("Error consumo web service PAM " + uri);
				
			}else {
				StringBuilder respBuilder = new StringBuilder();
				Scanner sc = new Scanner(url.openStream());
				
				while(sc.hasNext()){
					respBuilder.append(sc.nextLine());
		        }
		        sc.close();
		        
		        String resp =String.valueOf(respBuilder);
		        
		        JSONObject json = XML.toJSONObject(resp);
		        
		        this.log.info("Consumo web service PAM Exitoso");
		        
		        FDOption opt = new FDOption("respuesta",json.toString());
		       
		        options.add(opt);
		        this.count = options.size();
			}
			
		}catch(Exception e) {
			this.log.error(e);
		}
		
		
		this.log.info("***** Fin plugin ****** ");
		return options;
	}

	@Override
	public int totalCount() {
		// TODO Auto-generated method stub
		return this.count;
	}

	
}

package com.ca.usm.plugins.samples.applications.utils;

import java.net.Authenticator;
import java.net.PasswordAuthentication;

public final class BasicAuthenticator extends Authenticator {
	
 public String user;
 public String password;
	
	
public BasicAuthenticator(String user, String password) {
	super();
	this.user = user;
	this.password = password;
}


protected PasswordAuthentication getPasswordAuthentication() {
return new PasswordAuthentication(user, password.toCharArray());
}

}
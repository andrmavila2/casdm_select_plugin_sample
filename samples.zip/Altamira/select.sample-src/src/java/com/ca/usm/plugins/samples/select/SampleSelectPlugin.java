package com.ca.usm.plugins.samples.select;

import com.ca.usm.plugins.apis.PluginContext;
import com.ca.usm.plugins.apis.forms.FDOption;
import com.ca.usm.plugins.apis.forms.FDSelectDataProvider;

import org.apache.commons.logging.Log;

import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

public class SampleSelectPlugin implements FDSelectDataProvider {

  private PluginContext context;
  private Log log;
  private int totalCount = 0;

  @Override
  public void setContext(PluginContext context) {
    this.context = context;
    this.log = this.context.getLogger(SampleSelectPlugin.class);
  }

  @Override
  public void setInputs(Map<String, Object> inputs) {
    // Not used in this example. Inputs are returned from the Report/Plugin
    // Variables attribute of the select field and can be used to pass extra
    // information to the plugin

    // this.inputs = inputs;
  }

  @Override
  public List<FDOption> getOptions(int start, int numToReturn) {
    log.trace("Fetching select options");

    List<FDOption> options = new LinkedList<FDOption>();

    // Fetch data from source. In this example the data is hard-coded, in actual
    // use cases this call would be replaced to a call to a database or web
    // service to fetch data. Also in this example we fetch all the data
    // everytime which would not be efficient in real world scenarios. In most
    // cases we would pass the start, numToReturn, sortField, sortAscending
    // fields to the datasource to reduce the amount of data we would fetch from
    // the data source
    String[][] data = getData();
    if (log.isDebugEnabled()) log.debug("Fetched data:" + Arrays.asList(data));

    // Map data returned into FDOption objects
    for (int i = start; i < data.length && (numToReturn == -1 || i - start < numToReturn); i++) {
      String[] role = data[i];
      
      FDOption option = new FDOption(role[0], role[1]);
      options.add(option);
    }

    return options;
  }

  @Override
  public int totalCount() {
    return getData().length;
  }

  private String[][] getData() {

    return new String[][] {
            { "administrator", "Administrator" },
            { "catadministrator", "Catalog Administrator" },
            { "catalogenduser", "Catalog User" },
            { "enduser", "End User" },
            { "requestmanager", "Request Manager" },
            { "servicemanager", "Service Manager" },
            { "spadministrator", "Service Provider Administrator" },
            { "stadministrator", "Super Tenant Administrator" } };
  }
}

/**
 * Software_class_rec.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ca.usm.plugins.samples.resourceplugin.sam.ws.proxy;

public class Software_class_rec  implements java.io.Serializable {
    private int software_class_id;

    private java.lang.String import_id;

    private int data_source_id;

    private int software_category_id;

    private java.lang.String class_key;

    private java.lang.String name;

    private java.math.BigInteger depreciation;

    public Software_class_rec() {
    }

    public Software_class_rec(
           int software_class_id,
           java.lang.String import_id,
           int data_source_id,
           int software_category_id,
           java.lang.String class_key,
           java.lang.String name,
           java.math.BigInteger depreciation) {
           this.software_class_id = software_class_id;
           this.import_id = import_id;
           this.data_source_id = data_source_id;
           this.software_category_id = software_category_id;
           this.class_key = class_key;
           this.name = name;
           this.depreciation = depreciation;
    }


    /**
     * Gets the software_class_id value for this Software_class_rec.
     * 
     * @return software_class_id
     */
    public int getSoftware_class_id() {
        return software_class_id;
    }


    /**
     * Sets the software_class_id value for this Software_class_rec.
     * 
     * @param software_class_id
     */
    public void setSoftware_class_id(int software_class_id) {
        this.software_class_id = software_class_id;
    }


    /**
     * Gets the import_id value for this Software_class_rec.
     * 
     * @return import_id
     */
    public java.lang.String getImport_id() {
        return import_id;
    }


    /**
     * Sets the import_id value for this Software_class_rec.
     * 
     * @param import_id
     */
    public void setImport_id(java.lang.String import_id) {
        this.import_id = import_id;
    }


    /**
     * Gets the data_source_id value for this Software_class_rec.
     * 
     * @return data_source_id
     */
    public int getData_source_id() {
        return data_source_id;
    }


    /**
     * Sets the data_source_id value for this Software_class_rec.
     * 
     * @param data_source_id
     */
    public void setData_source_id(int data_source_id) {
        this.data_source_id = data_source_id;
    }


    /**
     * Gets the software_category_id value for this Software_class_rec.
     * 
     * @return software_category_id
     */
    public int getSoftware_category_id() {
        return software_category_id;
    }


    /**
     * Sets the software_category_id value for this Software_class_rec.
     * 
     * @param software_category_id
     */
    public void setSoftware_category_id(int software_category_id) {
        this.software_category_id = software_category_id;
    }


    /**
     * Gets the class_key value for this Software_class_rec.
     * 
     * @return class_key
     */
    public java.lang.String getClass_key() {
        return class_key;
    }


    /**
     * Sets the class_key value for this Software_class_rec.
     * 
     * @param class_key
     */
    public void setClass_key(java.lang.String class_key) {
        this.class_key = class_key;
    }


    /**
     * Gets the name value for this Software_class_rec.
     * 
     * @return name
     */
    public java.lang.String getName() {
        return name;
    }


    /**
     * Sets the name value for this Software_class_rec.
     * 
     * @param name
     */
    public void setName(java.lang.String name) {
        this.name = name;
    }


    /**
     * Gets the depreciation value for this Software_class_rec.
     * 
     * @return depreciation
     */
    public java.math.BigInteger getDepreciation() {
        return depreciation;
    }


    /**
     * Sets the depreciation value for this Software_class_rec.
     * 
     * @param depreciation
     */
    public void setDepreciation(java.math.BigInteger depreciation) {
        this.depreciation = depreciation;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Software_class_rec)) return false;
        Software_class_rec other = (Software_class_rec) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            this.software_class_id == other.getSoftware_class_id() &&
            ((this.import_id==null && other.getImport_id()==null) || 
             (this.import_id!=null &&
              this.import_id.equals(other.getImport_id()))) &&
            this.data_source_id == other.getData_source_id() &&
            this.software_category_id == other.getSoftware_category_id() &&
            ((this.class_key==null && other.getClass_key()==null) || 
             (this.class_key!=null &&
              this.class_key.equals(other.getClass_key()))) &&
            ((this.name==null && other.getName()==null) || 
             (this.name!=null &&
              this.name.equals(other.getName()))) &&
            ((this.depreciation==null && other.getDepreciation()==null) || 
             (this.depreciation!=null &&
              this.depreciation.equals(other.getDepreciation())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        _hashCode += getSoftware_class_id();
        if (getImport_id() != null) {
            _hashCode += getImport_id().hashCode();
        }
        _hashCode += getData_source_id();
        _hashCode += getSoftware_category_id();
        if (getClass_key() != null) {
            _hashCode += getClass_key().hashCode();
        }
        if (getName() != null) {
            _hashCode += getName().hashCode();
        }
        if (getDepreciation() != null) {
            _hashCode += getDepreciation().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Software_class_rec.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://aspera.com/wsdl/", "software_class_rec"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("software_class_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "software_class_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("import_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "import_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("data_source_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "data_source_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("software_category_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "software_category_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("class_key");
        elemField.setXmlName(new javax.xml.namespace.QName("", "class_key"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("name");
        elemField.setXmlName(new javax.xml.namespace.QName("", "name"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("depreciation");
        elemField.setXmlName(new javax.xml.namespace.QName("", "depreciation"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}

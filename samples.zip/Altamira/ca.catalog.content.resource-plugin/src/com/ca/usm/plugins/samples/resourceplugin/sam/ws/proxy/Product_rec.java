/**
 * Product_rec.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ca.usm.plugins.samples.resourceplugin.sam.ws.proxy;

public class Product_rec  implements java.io.Serializable {
    private int product_id;

    private java.lang.String import_id;

    private int data_source_id;

    private int product_family_id;

    private java.lang.String description;

    private int prod_manager_id;

    private boolean act_version;

    private boolean versionless;

    private java.lang.String release_date;

    private java.lang.String end_of_life;

    private boolean no_license_required;

    private boolean true_up;

    private boolean allow_secondary_copy;

    private int license_metric_id;

    private boolean is_enabled;

    private boolean license_key_required;

    private boolean early_install_possible;

    private java.math.BigInteger minimum_usage_days;

    private java.math.BigInteger minimum_balance;

    private java.math.BigInteger minimum_balance_percent;

    private boolean balance_notice;

    private java.lang.String reference_price;

    private int currency_id;

    private java.lang.String reference_price_source;

    private java.lang.String charging_price;

    private int charging_currency_id;

    private int product_status_id;

    private java.lang.String remarks;

    private java.lang.String long_description;

    private int software_class_id;

    public Product_rec() {
    }

    public Product_rec(
           int product_id,
           java.lang.String import_id,
           int data_source_id,
           int product_family_id,
           java.lang.String description,
           int prod_manager_id,
           boolean act_version,
           boolean versionless,
           java.lang.String release_date,
           java.lang.String end_of_life,
           boolean no_license_required,
           boolean true_up,
           boolean allow_secondary_copy,
           int license_metric_id,
           boolean is_enabled,
           boolean license_key_required,
           boolean early_install_possible,
           java.math.BigInteger minimum_usage_days,
           java.math.BigInteger minimum_balance,
           java.math.BigInteger minimum_balance_percent,
           boolean balance_notice,
           java.lang.String reference_price,
           int currency_id,
           java.lang.String reference_price_source,
           java.lang.String charging_price,
           int charging_currency_id,
           int product_status_id,
           java.lang.String remarks,
           java.lang.String long_description,
           int software_class_id) {
           this.product_id = product_id;
           this.import_id = import_id;
           this.data_source_id = data_source_id;
           this.product_family_id = product_family_id;
           this.description = description;
           this.prod_manager_id = prod_manager_id;
           this.act_version = act_version;
           this.versionless = versionless;
           this.release_date = release_date;
           this.end_of_life = end_of_life;
           this.no_license_required = no_license_required;
           this.true_up = true_up;
           this.allow_secondary_copy = allow_secondary_copy;
           this.license_metric_id = license_metric_id;
           this.is_enabled = is_enabled;
           this.license_key_required = license_key_required;
           this.early_install_possible = early_install_possible;
           this.minimum_usage_days = minimum_usage_days;
           this.minimum_balance = minimum_balance;
           this.minimum_balance_percent = minimum_balance_percent;
           this.balance_notice = balance_notice;
           this.reference_price = reference_price;
           this.currency_id = currency_id;
           this.reference_price_source = reference_price_source;
           this.charging_price = charging_price;
           this.charging_currency_id = charging_currency_id;
           this.product_status_id = product_status_id;
           this.remarks = remarks;
           this.long_description = long_description;
           this.software_class_id = software_class_id;
    }


    /**
     * Gets the product_id value for this Product_rec.
     * 
     * @return product_id
     */
    public int getProduct_id() {
        return product_id;
    }


    /**
     * Sets the product_id value for this Product_rec.
     * 
     * @param product_id
     */
    public void setProduct_id(int product_id) {
        this.product_id = product_id;
    }


    /**
     * Gets the import_id value for this Product_rec.
     * 
     * @return import_id
     */
    public java.lang.String getImport_id() {
        return import_id;
    }


    /**
     * Sets the import_id value for this Product_rec.
     * 
     * @param import_id
     */
    public void setImport_id(java.lang.String import_id) {
        this.import_id = import_id;
    }


    /**
     * Gets the data_source_id value for this Product_rec.
     * 
     * @return data_source_id
     */
    public int getData_source_id() {
        return data_source_id;
    }


    /**
     * Sets the data_source_id value for this Product_rec.
     * 
     * @param data_source_id
     */
    public void setData_source_id(int data_source_id) {
        this.data_source_id = data_source_id;
    }


    /**
     * Gets the product_family_id value for this Product_rec.
     * 
     * @return product_family_id
     */
    public int getProduct_family_id() {
        return product_family_id;
    }


    /**
     * Sets the product_family_id value for this Product_rec.
     * 
     * @param product_family_id
     */
    public void setProduct_family_id(int product_family_id) {
        this.product_family_id = product_family_id;
    }


    /**
     * Gets the description value for this Product_rec.
     * 
     * @return description
     */
    public java.lang.String getDescription() {
        return description;
    }


    /**
     * Sets the description value for this Product_rec.
     * 
     * @param description
     */
    public void setDescription(java.lang.String description) {
        this.description = description;
    }


    /**
     * Gets the prod_manager_id value for this Product_rec.
     * 
     * @return prod_manager_id
     */
    public int getProd_manager_id() {
        return prod_manager_id;
    }


    /**
     * Sets the prod_manager_id value for this Product_rec.
     * 
     * @param prod_manager_id
     */
    public void setProd_manager_id(int prod_manager_id) {
        this.prod_manager_id = prod_manager_id;
    }


    /**
     * Gets the act_version value for this Product_rec.
     * 
     * @return act_version
     */
    public boolean isAct_version() {
        return act_version;
    }


    /**
     * Sets the act_version value for this Product_rec.
     * 
     * @param act_version
     */
    public void setAct_version(boolean act_version) {
        this.act_version = act_version;
    }


    /**
     * Gets the versionless value for this Product_rec.
     * 
     * @return versionless
     */
    public boolean isVersionless() {
        return versionless;
    }


    /**
     * Sets the versionless value for this Product_rec.
     * 
     * @param versionless
     */
    public void setVersionless(boolean versionless) {
        this.versionless = versionless;
    }


    /**
     * Gets the release_date value for this Product_rec.
     * 
     * @return release_date
     */
    public java.lang.String getRelease_date() {
        return release_date;
    }


    /**
     * Sets the release_date value for this Product_rec.
     * 
     * @param release_date
     */
    public void setRelease_date(java.lang.String release_date) {
        this.release_date = release_date;
    }


    /**
     * Gets the end_of_life value for this Product_rec.
     * 
     * @return end_of_life
     */
    public java.lang.String getEnd_of_life() {
        return end_of_life;
    }


    /**
     * Sets the end_of_life value for this Product_rec.
     * 
     * @param end_of_life
     */
    public void setEnd_of_life(java.lang.String end_of_life) {
        this.end_of_life = end_of_life;
    }


    /**
     * Gets the no_license_required value for this Product_rec.
     * 
     * @return no_license_required
     */
    public boolean isNo_license_required() {
        return no_license_required;
    }


    /**
     * Sets the no_license_required value for this Product_rec.
     * 
     * @param no_license_required
     */
    public void setNo_license_required(boolean no_license_required) {
        this.no_license_required = no_license_required;
    }


    /**
     * Gets the true_up value for this Product_rec.
     * 
     * @return true_up
     */
    public boolean isTrue_up() {
        return true_up;
    }


    /**
     * Sets the true_up value for this Product_rec.
     * 
     * @param true_up
     */
    public void setTrue_up(boolean true_up) {
        this.true_up = true_up;
    }


    /**
     * Gets the allow_secondary_copy value for this Product_rec.
     * 
     * @return allow_secondary_copy
     */
    public boolean isAllow_secondary_copy() {
        return allow_secondary_copy;
    }


    /**
     * Sets the allow_secondary_copy value for this Product_rec.
     * 
     * @param allow_secondary_copy
     */
    public void setAllow_secondary_copy(boolean allow_secondary_copy) {
        this.allow_secondary_copy = allow_secondary_copy;
    }


    /**
     * Gets the license_metric_id value for this Product_rec.
     * 
     * @return license_metric_id
     */
    public int getLicense_metric_id() {
        return license_metric_id;
    }


    /**
     * Sets the license_metric_id value for this Product_rec.
     * 
     * @param license_metric_id
     */
    public void setLicense_metric_id(int license_metric_id) {
        this.license_metric_id = license_metric_id;
    }


    /**
     * Gets the is_enabled value for this Product_rec.
     * 
     * @return is_enabled
     */
    public boolean isIs_enabled() {
        return is_enabled;
    }


    /**
     * Sets the is_enabled value for this Product_rec.
     * 
     * @param is_enabled
     */
    public void setIs_enabled(boolean is_enabled) {
        this.is_enabled = is_enabled;
    }


    /**
     * Gets the license_key_required value for this Product_rec.
     * 
     * @return license_key_required
     */
    public boolean isLicense_key_required() {
        return license_key_required;
    }


    /**
     * Sets the license_key_required value for this Product_rec.
     * 
     * @param license_key_required
     */
    public void setLicense_key_required(boolean license_key_required) {
        this.license_key_required = license_key_required;
    }


    /**
     * Gets the early_install_possible value for this Product_rec.
     * 
     * @return early_install_possible
     */
    public boolean isEarly_install_possible() {
        return early_install_possible;
    }


    /**
     * Sets the early_install_possible value for this Product_rec.
     * 
     * @param early_install_possible
     */
    public void setEarly_install_possible(boolean early_install_possible) {
        this.early_install_possible = early_install_possible;
    }


    /**
     * Gets the minimum_usage_days value for this Product_rec.
     * 
     * @return minimum_usage_days
     */
    public java.math.BigInteger getMinimum_usage_days() {
        return minimum_usage_days;
    }


    /**
     * Sets the minimum_usage_days value for this Product_rec.
     * 
     * @param minimum_usage_days
     */
    public void setMinimum_usage_days(java.math.BigInteger minimum_usage_days) {
        this.minimum_usage_days = minimum_usage_days;
    }


    /**
     * Gets the minimum_balance value for this Product_rec.
     * 
     * @return minimum_balance
     */
    public java.math.BigInteger getMinimum_balance() {
        return minimum_balance;
    }


    /**
     * Sets the minimum_balance value for this Product_rec.
     * 
     * @param minimum_balance
     */
    public void setMinimum_balance(java.math.BigInteger minimum_balance) {
        this.minimum_balance = minimum_balance;
    }


    /**
     * Gets the minimum_balance_percent value for this Product_rec.
     * 
     * @return minimum_balance_percent
     */
    public java.math.BigInteger getMinimum_balance_percent() {
        return minimum_balance_percent;
    }


    /**
     * Sets the minimum_balance_percent value for this Product_rec.
     * 
     * @param minimum_balance_percent
     */
    public void setMinimum_balance_percent(java.math.BigInteger minimum_balance_percent) {
        this.minimum_balance_percent = minimum_balance_percent;
    }


    /**
     * Gets the balance_notice value for this Product_rec.
     * 
     * @return balance_notice
     */
    public boolean isBalance_notice() {
        return balance_notice;
    }


    /**
     * Sets the balance_notice value for this Product_rec.
     * 
     * @param balance_notice
     */
    public void setBalance_notice(boolean balance_notice) {
        this.balance_notice = balance_notice;
    }


    /**
     * Gets the reference_price value for this Product_rec.
     * 
     * @return reference_price
     */
    public java.lang.String getReference_price() {
        return reference_price;
    }


    /**
     * Sets the reference_price value for this Product_rec.
     * 
     * @param reference_price
     */
    public void setReference_price(java.lang.String reference_price) {
        this.reference_price = reference_price;
    }


    /**
     * Gets the currency_id value for this Product_rec.
     * 
     * @return currency_id
     */
    public int getCurrency_id() {
        return currency_id;
    }


    /**
     * Sets the currency_id value for this Product_rec.
     * 
     * @param currency_id
     */
    public void setCurrency_id(int currency_id) {
        this.currency_id = currency_id;
    }


    /**
     * Gets the reference_price_source value for this Product_rec.
     * 
     * @return reference_price_source
     */
    public java.lang.String getReference_price_source() {
        return reference_price_source;
    }


    /**
     * Sets the reference_price_source value for this Product_rec.
     * 
     * @param reference_price_source
     */
    public void setReference_price_source(java.lang.String reference_price_source) {
        this.reference_price_source = reference_price_source;
    }


    /**
     * Gets the charging_price value for this Product_rec.
     * 
     * @return charging_price
     */
    public java.lang.String getCharging_price() {
        return charging_price;
    }


    /**
     * Sets the charging_price value for this Product_rec.
     * 
     * @param charging_price
     */
    public void setCharging_price(java.lang.String charging_price) {
        this.charging_price = charging_price;
    }


    /**
     * Gets the charging_currency_id value for this Product_rec.
     * 
     * @return charging_currency_id
     */
    public int getCharging_currency_id() {
        return charging_currency_id;
    }


    /**
     * Sets the charging_currency_id value for this Product_rec.
     * 
     * @param charging_currency_id
     */
    public void setCharging_currency_id(int charging_currency_id) {
        this.charging_currency_id = charging_currency_id;
    }


    /**
     * Gets the product_status_id value for this Product_rec.
     * 
     * @return product_status_id
     */
    public int getProduct_status_id() {
        return product_status_id;
    }


    /**
     * Sets the product_status_id value for this Product_rec.
     * 
     * @param product_status_id
     */
    public void setProduct_status_id(int product_status_id) {
        this.product_status_id = product_status_id;
    }


    /**
     * Gets the remarks value for this Product_rec.
     * 
     * @return remarks
     */
    public java.lang.String getRemarks() {
        return remarks;
    }


    /**
     * Sets the remarks value for this Product_rec.
     * 
     * @param remarks
     */
    public void setRemarks(java.lang.String remarks) {
        this.remarks = remarks;
    }


    /**
     * Gets the long_description value for this Product_rec.
     * 
     * @return long_description
     */
    public java.lang.String getLong_description() {
        return long_description;
    }


    /**
     * Sets the long_description value for this Product_rec.
     * 
     * @param long_description
     */
    public void setLong_description(java.lang.String long_description) {
        this.long_description = long_description;
    }


    /**
     * Gets the software_class_id value for this Product_rec.
     * 
     * @return software_class_id
     */
    public int getSoftware_class_id() {
        return software_class_id;
    }


    /**
     * Sets the software_class_id value for this Product_rec.
     * 
     * @param software_class_id
     */
    public void setSoftware_class_id(int software_class_id) {
        this.software_class_id = software_class_id;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Product_rec)) return false;
        Product_rec other = (Product_rec) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            this.product_id == other.getProduct_id() &&
            ((this.import_id==null && other.getImport_id()==null) || 
             (this.import_id!=null &&
              this.import_id.equals(other.getImport_id()))) &&
            this.data_source_id == other.getData_source_id() &&
            this.product_family_id == other.getProduct_family_id() &&
            ((this.description==null && other.getDescription()==null) || 
             (this.description!=null &&
              this.description.equals(other.getDescription()))) &&
            this.prod_manager_id == other.getProd_manager_id() &&
            this.act_version == other.isAct_version() &&
            this.versionless == other.isVersionless() &&
            ((this.release_date==null && other.getRelease_date()==null) || 
             (this.release_date!=null &&
              this.release_date.equals(other.getRelease_date()))) &&
            ((this.end_of_life==null && other.getEnd_of_life()==null) || 
             (this.end_of_life!=null &&
              this.end_of_life.equals(other.getEnd_of_life()))) &&
            this.no_license_required == other.isNo_license_required() &&
            this.true_up == other.isTrue_up() &&
            this.allow_secondary_copy == other.isAllow_secondary_copy() &&
            this.license_metric_id == other.getLicense_metric_id() &&
            this.is_enabled == other.isIs_enabled() &&
            this.license_key_required == other.isLicense_key_required() &&
            this.early_install_possible == other.isEarly_install_possible() &&
            ((this.minimum_usage_days==null && other.getMinimum_usage_days()==null) || 
             (this.minimum_usage_days!=null &&
              this.minimum_usage_days.equals(other.getMinimum_usage_days()))) &&
            ((this.minimum_balance==null && other.getMinimum_balance()==null) || 
             (this.minimum_balance!=null &&
              this.minimum_balance.equals(other.getMinimum_balance()))) &&
            ((this.minimum_balance_percent==null && other.getMinimum_balance_percent()==null) || 
             (this.minimum_balance_percent!=null &&
              this.minimum_balance_percent.equals(other.getMinimum_balance_percent()))) &&
            this.balance_notice == other.isBalance_notice() &&
            ((this.reference_price==null && other.getReference_price()==null) || 
             (this.reference_price!=null &&
              this.reference_price.equals(other.getReference_price()))) &&
            this.currency_id == other.getCurrency_id() &&
            ((this.reference_price_source==null && other.getReference_price_source()==null) || 
             (this.reference_price_source!=null &&
              this.reference_price_source.equals(other.getReference_price_source()))) &&
            ((this.charging_price==null && other.getCharging_price()==null) || 
             (this.charging_price!=null &&
              this.charging_price.equals(other.getCharging_price()))) &&
            this.charging_currency_id == other.getCharging_currency_id() &&
            this.product_status_id == other.getProduct_status_id() &&
            ((this.remarks==null && other.getRemarks()==null) || 
             (this.remarks!=null &&
              this.remarks.equals(other.getRemarks()))) &&
            ((this.long_description==null && other.getLong_description()==null) || 
             (this.long_description!=null &&
              this.long_description.equals(other.getLong_description()))) &&
            this.software_class_id == other.getSoftware_class_id();
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        _hashCode += getProduct_id();
        if (getImport_id() != null) {
            _hashCode += getImport_id().hashCode();
        }
        _hashCode += getData_source_id();
        _hashCode += getProduct_family_id();
        if (getDescription() != null) {
            _hashCode += getDescription().hashCode();
        }
        _hashCode += getProd_manager_id();
        _hashCode += (isAct_version() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        _hashCode += (isVersionless() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        if (getRelease_date() != null) {
            _hashCode += getRelease_date().hashCode();
        }
        if (getEnd_of_life() != null) {
            _hashCode += getEnd_of_life().hashCode();
        }
        _hashCode += (isNo_license_required() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        _hashCode += (isTrue_up() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        _hashCode += (isAllow_secondary_copy() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        _hashCode += getLicense_metric_id();
        _hashCode += (isIs_enabled() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        _hashCode += (isLicense_key_required() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        _hashCode += (isEarly_install_possible() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        if (getMinimum_usage_days() != null) {
            _hashCode += getMinimum_usage_days().hashCode();
        }
        if (getMinimum_balance() != null) {
            _hashCode += getMinimum_balance().hashCode();
        }
        if (getMinimum_balance_percent() != null) {
            _hashCode += getMinimum_balance_percent().hashCode();
        }
        _hashCode += (isBalance_notice() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        if (getReference_price() != null) {
            _hashCode += getReference_price().hashCode();
        }
        _hashCode += getCurrency_id();
        if (getReference_price_source() != null) {
            _hashCode += getReference_price_source().hashCode();
        }
        if (getCharging_price() != null) {
            _hashCode += getCharging_price().hashCode();
        }
        _hashCode += getCharging_currency_id();
        _hashCode += getProduct_status_id();
        if (getRemarks() != null) {
            _hashCode += getRemarks().hashCode();
        }
        if (getLong_description() != null) {
            _hashCode += getLong_description().hashCode();
        }
        _hashCode += getSoftware_class_id();
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Product_rec.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://aspera.com/wsdl/", "product_rec"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("product_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "product_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("import_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "import_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("data_source_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "data_source_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("product_family_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "product_family_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("description");
        elemField.setXmlName(new javax.xml.namespace.QName("", "description"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("prod_manager_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "prod_manager_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("act_version");
        elemField.setXmlName(new javax.xml.namespace.QName("", "act_version"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("versionless");
        elemField.setXmlName(new javax.xml.namespace.QName("", "versionless"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("release_date");
        elemField.setXmlName(new javax.xml.namespace.QName("", "release_date"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("end_of_life");
        elemField.setXmlName(new javax.xml.namespace.QName("", "end_of_life"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("no_license_required");
        elemField.setXmlName(new javax.xml.namespace.QName("", "no_license_required"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("true_up");
        elemField.setXmlName(new javax.xml.namespace.QName("", "true_up"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("allow_secondary_copy");
        elemField.setXmlName(new javax.xml.namespace.QName("", "allow_secondary_copy"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("license_metric_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "license_metric_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("is_enabled");
        elemField.setXmlName(new javax.xml.namespace.QName("", "is_enabled"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("license_key_required");
        elemField.setXmlName(new javax.xml.namespace.QName("", "license_key_required"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("early_install_possible");
        elemField.setXmlName(new javax.xml.namespace.QName("", "early_install_possible"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("minimum_usage_days");
        elemField.setXmlName(new javax.xml.namespace.QName("", "minimum_usage_days"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("minimum_balance");
        elemField.setXmlName(new javax.xml.namespace.QName("", "minimum_balance"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("minimum_balance_percent");
        elemField.setXmlName(new javax.xml.namespace.QName("", "minimum_balance_percent"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("balance_notice");
        elemField.setXmlName(new javax.xml.namespace.QName("", "balance_notice"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("reference_price");
        elemField.setXmlName(new javax.xml.namespace.QName("", "reference_price"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("currency_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "currency_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("reference_price_source");
        elemField.setXmlName(new javax.xml.namespace.QName("", "reference_price_source"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("charging_price");
        elemField.setXmlName(new javax.xml.namespace.QName("", "charging_price"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("charging_currency_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "charging_currency_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("product_status_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "product_status_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("remarks");
        elemField.setXmlName(new javax.xml.namespace.QName("", "remarks"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("long_description");
        elemField.setXmlName(new javax.xml.namespace.QName("", "long_description"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("software_class_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "software_class_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}

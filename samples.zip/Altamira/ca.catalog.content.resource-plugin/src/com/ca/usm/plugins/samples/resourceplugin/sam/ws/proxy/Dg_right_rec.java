/**
 * Dg_right_rec.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ca.usm.plugins.samples.resourceplugin.sam.ws.proxy;

public class Dg_right_rec  implements java.io.Serializable {
    private int dg_right_id;

    private java.lang.String import_id;

    private int data_source_id;

    private int from_dg_path_member_id;

    private int to_dg_path_member_id;

    public Dg_right_rec() {
    }

    public Dg_right_rec(
           int dg_right_id,
           java.lang.String import_id,
           int data_source_id,
           int from_dg_path_member_id,
           int to_dg_path_member_id) {
           this.dg_right_id = dg_right_id;
           this.import_id = import_id;
           this.data_source_id = data_source_id;
           this.from_dg_path_member_id = from_dg_path_member_id;
           this.to_dg_path_member_id = to_dg_path_member_id;
    }


    /**
     * Gets the dg_right_id value for this Dg_right_rec.
     * 
     * @return dg_right_id
     */
    public int getDg_right_id() {
        return dg_right_id;
    }


    /**
     * Sets the dg_right_id value for this Dg_right_rec.
     * 
     * @param dg_right_id
     */
    public void setDg_right_id(int dg_right_id) {
        this.dg_right_id = dg_right_id;
    }


    /**
     * Gets the import_id value for this Dg_right_rec.
     * 
     * @return import_id
     */
    public java.lang.String getImport_id() {
        return import_id;
    }


    /**
     * Sets the import_id value for this Dg_right_rec.
     * 
     * @param import_id
     */
    public void setImport_id(java.lang.String import_id) {
        this.import_id = import_id;
    }


    /**
     * Gets the data_source_id value for this Dg_right_rec.
     * 
     * @return data_source_id
     */
    public int getData_source_id() {
        return data_source_id;
    }


    /**
     * Sets the data_source_id value for this Dg_right_rec.
     * 
     * @param data_source_id
     */
    public void setData_source_id(int data_source_id) {
        this.data_source_id = data_source_id;
    }


    /**
     * Gets the from_dg_path_member_id value for this Dg_right_rec.
     * 
     * @return from_dg_path_member_id
     */
    public int getFrom_dg_path_member_id() {
        return from_dg_path_member_id;
    }


    /**
     * Sets the from_dg_path_member_id value for this Dg_right_rec.
     * 
     * @param from_dg_path_member_id
     */
    public void setFrom_dg_path_member_id(int from_dg_path_member_id) {
        this.from_dg_path_member_id = from_dg_path_member_id;
    }


    /**
     * Gets the to_dg_path_member_id value for this Dg_right_rec.
     * 
     * @return to_dg_path_member_id
     */
    public int getTo_dg_path_member_id() {
        return to_dg_path_member_id;
    }


    /**
     * Sets the to_dg_path_member_id value for this Dg_right_rec.
     * 
     * @param to_dg_path_member_id
     */
    public void setTo_dg_path_member_id(int to_dg_path_member_id) {
        this.to_dg_path_member_id = to_dg_path_member_id;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Dg_right_rec)) return false;
        Dg_right_rec other = (Dg_right_rec) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            this.dg_right_id == other.getDg_right_id() &&
            ((this.import_id==null && other.getImport_id()==null) || 
             (this.import_id!=null &&
              this.import_id.equals(other.getImport_id()))) &&
            this.data_source_id == other.getData_source_id() &&
            this.from_dg_path_member_id == other.getFrom_dg_path_member_id() &&
            this.to_dg_path_member_id == other.getTo_dg_path_member_id();
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        _hashCode += getDg_right_id();
        if (getImport_id() != null) {
            _hashCode += getImport_id().hashCode();
        }
        _hashCode += getData_source_id();
        _hashCode += getFrom_dg_path_member_id();
        _hashCode += getTo_dg_path_member_id();
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Dg_right_rec.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://aspera.com/wsdl/", "dg_right_rec"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dg_right_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "dg_right_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("import_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "import_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("data_source_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "data_source_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("from_dg_path_member_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "from_dg_path_member_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("to_dg_path_member_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "to_dg_path_member_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}

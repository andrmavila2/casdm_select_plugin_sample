/**
 * Inv_raw_file_rec.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ca.usm.plugins.samples.resourceplugin.sam.ws.proxy;

public class Inv_raw_file_rec  implements java.io.Serializable {
    private int inv_raw_file_id;

    private java.lang.String import_id;

    private int data_source_id;

    private java.lang.String file_name;

    private java.lang.String file_size;

    private java.lang.String file_path;

    private java.lang.String publisher;

    private java.lang.String product;

    private java.lang.String product_version;

    private int device_id;

    private java.lang.String installation_date;

    private java.lang.String last_usage;

    private int last_usage_account_id;

    private java.math.BigInteger usage_frequency_month;

    public Inv_raw_file_rec() {
    }

    public Inv_raw_file_rec(
           int inv_raw_file_id,
           java.lang.String import_id,
           int data_source_id,
           java.lang.String file_name,
           java.lang.String file_size,
           java.lang.String file_path,
           java.lang.String publisher,
           java.lang.String product,
           java.lang.String product_version,
           int device_id,
           java.lang.String installation_date,
           java.lang.String last_usage,
           int last_usage_account_id,
           java.math.BigInteger usage_frequency_month) {
           this.inv_raw_file_id = inv_raw_file_id;
           this.import_id = import_id;
           this.data_source_id = data_source_id;
           this.file_name = file_name;
           this.file_size = file_size;
           this.file_path = file_path;
           this.publisher = publisher;
           this.product = product;
           this.product_version = product_version;
           this.device_id = device_id;
           this.installation_date = installation_date;
           this.last_usage = last_usage;
           this.last_usage_account_id = last_usage_account_id;
           this.usage_frequency_month = usage_frequency_month;
    }


    /**
     * Gets the inv_raw_file_id value for this Inv_raw_file_rec.
     * 
     * @return inv_raw_file_id
     */
    public int getInv_raw_file_id() {
        return inv_raw_file_id;
    }


    /**
     * Sets the inv_raw_file_id value for this Inv_raw_file_rec.
     * 
     * @param inv_raw_file_id
     */
    public void setInv_raw_file_id(int inv_raw_file_id) {
        this.inv_raw_file_id = inv_raw_file_id;
    }


    /**
     * Gets the import_id value for this Inv_raw_file_rec.
     * 
     * @return import_id
     */
    public java.lang.String getImport_id() {
        return import_id;
    }


    /**
     * Sets the import_id value for this Inv_raw_file_rec.
     * 
     * @param import_id
     */
    public void setImport_id(java.lang.String import_id) {
        this.import_id = import_id;
    }


    /**
     * Gets the data_source_id value for this Inv_raw_file_rec.
     * 
     * @return data_source_id
     */
    public int getData_source_id() {
        return data_source_id;
    }


    /**
     * Sets the data_source_id value for this Inv_raw_file_rec.
     * 
     * @param data_source_id
     */
    public void setData_source_id(int data_source_id) {
        this.data_source_id = data_source_id;
    }


    /**
     * Gets the file_name value for this Inv_raw_file_rec.
     * 
     * @return file_name
     */
    public java.lang.String getFile_name() {
        return file_name;
    }


    /**
     * Sets the file_name value for this Inv_raw_file_rec.
     * 
     * @param file_name
     */
    public void setFile_name(java.lang.String file_name) {
        this.file_name = file_name;
    }


    /**
     * Gets the file_size value for this Inv_raw_file_rec.
     * 
     * @return file_size
     */
    public java.lang.String getFile_size() {
        return file_size;
    }


    /**
     * Sets the file_size value for this Inv_raw_file_rec.
     * 
     * @param file_size
     */
    public void setFile_size(java.lang.String file_size) {
        this.file_size = file_size;
    }


    /**
     * Gets the file_path value for this Inv_raw_file_rec.
     * 
     * @return file_path
     */
    public java.lang.String getFile_path() {
        return file_path;
    }


    /**
     * Sets the file_path value for this Inv_raw_file_rec.
     * 
     * @param file_path
     */
    public void setFile_path(java.lang.String file_path) {
        this.file_path = file_path;
    }


    /**
     * Gets the publisher value for this Inv_raw_file_rec.
     * 
     * @return publisher
     */
    public java.lang.String getPublisher() {
        return publisher;
    }


    /**
     * Sets the publisher value for this Inv_raw_file_rec.
     * 
     * @param publisher
     */
    public void setPublisher(java.lang.String publisher) {
        this.publisher = publisher;
    }


    /**
     * Gets the product value for this Inv_raw_file_rec.
     * 
     * @return product
     */
    public java.lang.String getProduct() {
        return product;
    }


    /**
     * Sets the product value for this Inv_raw_file_rec.
     * 
     * @param product
     */
    public void setProduct(java.lang.String product) {
        this.product = product;
    }


    /**
     * Gets the product_version value for this Inv_raw_file_rec.
     * 
     * @return product_version
     */
    public java.lang.String getProduct_version() {
        return product_version;
    }


    /**
     * Sets the product_version value for this Inv_raw_file_rec.
     * 
     * @param product_version
     */
    public void setProduct_version(java.lang.String product_version) {
        this.product_version = product_version;
    }


    /**
     * Gets the device_id value for this Inv_raw_file_rec.
     * 
     * @return device_id
     */
    public int getDevice_id() {
        return device_id;
    }


    /**
     * Sets the device_id value for this Inv_raw_file_rec.
     * 
     * @param device_id
     */
    public void setDevice_id(int device_id) {
        this.device_id = device_id;
    }


    /**
     * Gets the installation_date value for this Inv_raw_file_rec.
     * 
     * @return installation_date
     */
    public java.lang.String getInstallation_date() {
        return installation_date;
    }


    /**
     * Sets the installation_date value for this Inv_raw_file_rec.
     * 
     * @param installation_date
     */
    public void setInstallation_date(java.lang.String installation_date) {
        this.installation_date = installation_date;
    }


    /**
     * Gets the last_usage value for this Inv_raw_file_rec.
     * 
     * @return last_usage
     */
    public java.lang.String getLast_usage() {
        return last_usage;
    }


    /**
     * Sets the last_usage value for this Inv_raw_file_rec.
     * 
     * @param last_usage
     */
    public void setLast_usage(java.lang.String last_usage) {
        this.last_usage = last_usage;
    }


    /**
     * Gets the last_usage_account_id value for this Inv_raw_file_rec.
     * 
     * @return last_usage_account_id
     */
    public int getLast_usage_account_id() {
        return last_usage_account_id;
    }


    /**
     * Sets the last_usage_account_id value for this Inv_raw_file_rec.
     * 
     * @param last_usage_account_id
     */
    public void setLast_usage_account_id(int last_usage_account_id) {
        this.last_usage_account_id = last_usage_account_id;
    }


    /**
     * Gets the usage_frequency_month value for this Inv_raw_file_rec.
     * 
     * @return usage_frequency_month
     */
    public java.math.BigInteger getUsage_frequency_month() {
        return usage_frequency_month;
    }


    /**
     * Sets the usage_frequency_month value for this Inv_raw_file_rec.
     * 
     * @param usage_frequency_month
     */
    public void setUsage_frequency_month(java.math.BigInteger usage_frequency_month) {
        this.usage_frequency_month = usage_frequency_month;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Inv_raw_file_rec)) return false;
        Inv_raw_file_rec other = (Inv_raw_file_rec) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            this.inv_raw_file_id == other.getInv_raw_file_id() &&
            ((this.import_id==null && other.getImport_id()==null) || 
             (this.import_id!=null &&
              this.import_id.equals(other.getImport_id()))) &&
            this.data_source_id == other.getData_source_id() &&
            ((this.file_name==null && other.getFile_name()==null) || 
             (this.file_name!=null &&
              this.file_name.equals(other.getFile_name()))) &&
            ((this.file_size==null && other.getFile_size()==null) || 
             (this.file_size!=null &&
              this.file_size.equals(other.getFile_size()))) &&
            ((this.file_path==null && other.getFile_path()==null) || 
             (this.file_path!=null &&
              this.file_path.equals(other.getFile_path()))) &&
            ((this.publisher==null && other.getPublisher()==null) || 
             (this.publisher!=null &&
              this.publisher.equals(other.getPublisher()))) &&
            ((this.product==null && other.getProduct()==null) || 
             (this.product!=null &&
              this.product.equals(other.getProduct()))) &&
            ((this.product_version==null && other.getProduct_version()==null) || 
             (this.product_version!=null &&
              this.product_version.equals(other.getProduct_version()))) &&
            this.device_id == other.getDevice_id() &&
            ((this.installation_date==null && other.getInstallation_date()==null) || 
             (this.installation_date!=null &&
              this.installation_date.equals(other.getInstallation_date()))) &&
            ((this.last_usage==null && other.getLast_usage()==null) || 
             (this.last_usage!=null &&
              this.last_usage.equals(other.getLast_usage()))) &&
            this.last_usage_account_id == other.getLast_usage_account_id() &&
            ((this.usage_frequency_month==null && other.getUsage_frequency_month()==null) || 
             (this.usage_frequency_month!=null &&
              this.usage_frequency_month.equals(other.getUsage_frequency_month())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        _hashCode += getInv_raw_file_id();
        if (getImport_id() != null) {
            _hashCode += getImport_id().hashCode();
        }
        _hashCode += getData_source_id();
        if (getFile_name() != null) {
            _hashCode += getFile_name().hashCode();
        }
        if (getFile_size() != null) {
            _hashCode += getFile_size().hashCode();
        }
        if (getFile_path() != null) {
            _hashCode += getFile_path().hashCode();
        }
        if (getPublisher() != null) {
            _hashCode += getPublisher().hashCode();
        }
        if (getProduct() != null) {
            _hashCode += getProduct().hashCode();
        }
        if (getProduct_version() != null) {
            _hashCode += getProduct_version().hashCode();
        }
        _hashCode += getDevice_id();
        if (getInstallation_date() != null) {
            _hashCode += getInstallation_date().hashCode();
        }
        if (getLast_usage() != null) {
            _hashCode += getLast_usage().hashCode();
        }
        _hashCode += getLast_usage_account_id();
        if (getUsage_frequency_month() != null) {
            _hashCode += getUsage_frequency_month().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Inv_raw_file_rec.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://aspera.com/wsdl/", "inv_raw_file_rec"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("inv_raw_file_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "inv_raw_file_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("import_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "import_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("data_source_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "data_source_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("file_name");
        elemField.setXmlName(new javax.xml.namespace.QName("", "file_name"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("file_size");
        elemField.setXmlName(new javax.xml.namespace.QName("", "file_size"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("file_path");
        elemField.setXmlName(new javax.xml.namespace.QName("", "file_path"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("publisher");
        elemField.setXmlName(new javax.xml.namespace.QName("", "publisher"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("product");
        elemField.setXmlName(new javax.xml.namespace.QName("", "product"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("product_version");
        elemField.setXmlName(new javax.xml.namespace.QName("", "product_version"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("device_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "device_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("installation_date");
        elemField.setXmlName(new javax.xml.namespace.QName("", "installation_date"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("last_usage");
        elemField.setXmlName(new javax.xml.namespace.QName("", "last_usage"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("last_usage_account_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "last_usage_account_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("usage_frequency_month");
        elemField.setXmlName(new javax.xml.namespace.QName("", "usage_frequency_month"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}

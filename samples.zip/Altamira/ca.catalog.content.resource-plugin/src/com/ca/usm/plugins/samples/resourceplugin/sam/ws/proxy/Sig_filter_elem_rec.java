/**
 * Sig_filter_elem_rec.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ca.usm.plugins.samples.resourceplugin.sam.ws.proxy;

public class Sig_filter_elem_rec  implements java.io.Serializable {
    private int sig_filter_elem_id;

    private java.lang.String import_id;

    private int data_source_id;

    private int sig_filter_id;

    private java.lang.String col;

    private java.lang.String value;

    public Sig_filter_elem_rec() {
    }

    public Sig_filter_elem_rec(
           int sig_filter_elem_id,
           java.lang.String import_id,
           int data_source_id,
           int sig_filter_id,
           java.lang.String col,
           java.lang.String value) {
           this.sig_filter_elem_id = sig_filter_elem_id;
           this.import_id = import_id;
           this.data_source_id = data_source_id;
           this.sig_filter_id = sig_filter_id;
           this.col = col;
           this.value = value;
    }


    /**
     * Gets the sig_filter_elem_id value for this Sig_filter_elem_rec.
     * 
     * @return sig_filter_elem_id
     */
    public int getSig_filter_elem_id() {
        return sig_filter_elem_id;
    }


    /**
     * Sets the sig_filter_elem_id value for this Sig_filter_elem_rec.
     * 
     * @param sig_filter_elem_id
     */
    public void setSig_filter_elem_id(int sig_filter_elem_id) {
        this.sig_filter_elem_id = sig_filter_elem_id;
    }


    /**
     * Gets the import_id value for this Sig_filter_elem_rec.
     * 
     * @return import_id
     */
    public java.lang.String getImport_id() {
        return import_id;
    }


    /**
     * Sets the import_id value for this Sig_filter_elem_rec.
     * 
     * @param import_id
     */
    public void setImport_id(java.lang.String import_id) {
        this.import_id = import_id;
    }


    /**
     * Gets the data_source_id value for this Sig_filter_elem_rec.
     * 
     * @return data_source_id
     */
    public int getData_source_id() {
        return data_source_id;
    }


    /**
     * Sets the data_source_id value for this Sig_filter_elem_rec.
     * 
     * @param data_source_id
     */
    public void setData_source_id(int data_source_id) {
        this.data_source_id = data_source_id;
    }


    /**
     * Gets the sig_filter_id value for this Sig_filter_elem_rec.
     * 
     * @return sig_filter_id
     */
    public int getSig_filter_id() {
        return sig_filter_id;
    }


    /**
     * Sets the sig_filter_id value for this Sig_filter_elem_rec.
     * 
     * @param sig_filter_id
     */
    public void setSig_filter_id(int sig_filter_id) {
        this.sig_filter_id = sig_filter_id;
    }


    /**
     * Gets the col value for this Sig_filter_elem_rec.
     * 
     * @return col
     */
    public java.lang.String getCol() {
        return col;
    }


    /**
     * Sets the col value for this Sig_filter_elem_rec.
     * 
     * @param col
     */
    public void setCol(java.lang.String col) {
        this.col = col;
    }


    /**
     * Gets the value value for this Sig_filter_elem_rec.
     * 
     * @return value
     */
    public java.lang.String getValue() {
        return value;
    }


    /**
     * Sets the value value for this Sig_filter_elem_rec.
     * 
     * @param value
     */
    public void setValue(java.lang.String value) {
        this.value = value;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Sig_filter_elem_rec)) return false;
        Sig_filter_elem_rec other = (Sig_filter_elem_rec) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            this.sig_filter_elem_id == other.getSig_filter_elem_id() &&
            ((this.import_id==null && other.getImport_id()==null) || 
             (this.import_id!=null &&
              this.import_id.equals(other.getImport_id()))) &&
            this.data_source_id == other.getData_source_id() &&
            this.sig_filter_id == other.getSig_filter_id() &&
            ((this.col==null && other.getCol()==null) || 
             (this.col!=null &&
              this.col.equals(other.getCol()))) &&
            ((this.value==null && other.getValue()==null) || 
             (this.value!=null &&
              this.value.equals(other.getValue())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        _hashCode += getSig_filter_elem_id();
        if (getImport_id() != null) {
            _hashCode += getImport_id().hashCode();
        }
        _hashCode += getData_source_id();
        _hashCode += getSig_filter_id();
        if (getCol() != null) {
            _hashCode += getCol().hashCode();
        }
        if (getValue() != null) {
            _hashCode += getValue().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Sig_filter_elem_rec.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://aspera.com/wsdl/", "sig_filter_elem_rec"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("sig_filter_elem_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "sig_filter_elem_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("import_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "import_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("data_source_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "data_source_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("sig_filter_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "sig_filter_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("col");
        elemField.setXmlName(new javax.xml.namespace.QName("", "col"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("value");
        elemField.setXmlName(new javax.xml.namespace.QName("", "value"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}

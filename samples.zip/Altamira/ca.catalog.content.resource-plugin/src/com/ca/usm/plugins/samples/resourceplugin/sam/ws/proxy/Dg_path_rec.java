/**
 * Dg_path_rec.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ca.usm.plugins.samples.resourceplugin.sam.ws.proxy;

public class Dg_path_rec  implements java.io.Serializable {
    private int dg_path_id;

    private java.lang.String import_id;

    private int data_source_id;

    private java.lang.String name;

    private boolean active;

    private boolean force_downgrade;

    private boolean allow_parallel_usage;

    private boolean restrict_parallel_usage;

    private java.lang.String remarks;

    public Dg_path_rec() {
    }

    public Dg_path_rec(
           int dg_path_id,
           java.lang.String import_id,
           int data_source_id,
           java.lang.String name,
           boolean active,
           boolean force_downgrade,
           boolean allow_parallel_usage,
           boolean restrict_parallel_usage,
           java.lang.String remarks) {
           this.dg_path_id = dg_path_id;
           this.import_id = import_id;
           this.data_source_id = data_source_id;
           this.name = name;
           this.active = active;
           this.force_downgrade = force_downgrade;
           this.allow_parallel_usage = allow_parallel_usage;
           this.restrict_parallel_usage = restrict_parallel_usage;
           this.remarks = remarks;
    }


    /**
     * Gets the dg_path_id value for this Dg_path_rec.
     * 
     * @return dg_path_id
     */
    public int getDg_path_id() {
        return dg_path_id;
    }


    /**
     * Sets the dg_path_id value for this Dg_path_rec.
     * 
     * @param dg_path_id
     */
    public void setDg_path_id(int dg_path_id) {
        this.dg_path_id = dg_path_id;
    }


    /**
     * Gets the import_id value for this Dg_path_rec.
     * 
     * @return import_id
     */
    public java.lang.String getImport_id() {
        return import_id;
    }


    /**
     * Sets the import_id value for this Dg_path_rec.
     * 
     * @param import_id
     */
    public void setImport_id(java.lang.String import_id) {
        this.import_id = import_id;
    }


    /**
     * Gets the data_source_id value for this Dg_path_rec.
     * 
     * @return data_source_id
     */
    public int getData_source_id() {
        return data_source_id;
    }


    /**
     * Sets the data_source_id value for this Dg_path_rec.
     * 
     * @param data_source_id
     */
    public void setData_source_id(int data_source_id) {
        this.data_source_id = data_source_id;
    }


    /**
     * Gets the name value for this Dg_path_rec.
     * 
     * @return name
     */
    public java.lang.String getName() {
        return name;
    }


    /**
     * Sets the name value for this Dg_path_rec.
     * 
     * @param name
     */
    public void setName(java.lang.String name) {
        this.name = name;
    }


    /**
     * Gets the active value for this Dg_path_rec.
     * 
     * @return active
     */
    public boolean isActive() {
        return active;
    }


    /**
     * Sets the active value for this Dg_path_rec.
     * 
     * @param active
     */
    public void setActive(boolean active) {
        this.active = active;
    }


    /**
     * Gets the force_downgrade value for this Dg_path_rec.
     * 
     * @return force_downgrade
     */
    public boolean isForce_downgrade() {
        return force_downgrade;
    }


    /**
     * Sets the force_downgrade value for this Dg_path_rec.
     * 
     * @param force_downgrade
     */
    public void setForce_downgrade(boolean force_downgrade) {
        this.force_downgrade = force_downgrade;
    }


    /**
     * Gets the allow_parallel_usage value for this Dg_path_rec.
     * 
     * @return allow_parallel_usage
     */
    public boolean isAllow_parallel_usage() {
        return allow_parallel_usage;
    }


    /**
     * Sets the allow_parallel_usage value for this Dg_path_rec.
     * 
     * @param allow_parallel_usage
     */
    public void setAllow_parallel_usage(boolean allow_parallel_usage) {
        this.allow_parallel_usage = allow_parallel_usage;
    }


    /**
     * Gets the restrict_parallel_usage value for this Dg_path_rec.
     * 
     * @return restrict_parallel_usage
     */
    public boolean isRestrict_parallel_usage() {
        return restrict_parallel_usage;
    }


    /**
     * Sets the restrict_parallel_usage value for this Dg_path_rec.
     * 
     * @param restrict_parallel_usage
     */
    public void setRestrict_parallel_usage(boolean restrict_parallel_usage) {
        this.restrict_parallel_usage = restrict_parallel_usage;
    }


    /**
     * Gets the remarks value for this Dg_path_rec.
     * 
     * @return remarks
     */
    public java.lang.String getRemarks() {
        return remarks;
    }


    /**
     * Sets the remarks value for this Dg_path_rec.
     * 
     * @param remarks
     */
    public void setRemarks(java.lang.String remarks) {
        this.remarks = remarks;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Dg_path_rec)) return false;
        Dg_path_rec other = (Dg_path_rec) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            this.dg_path_id == other.getDg_path_id() &&
            ((this.import_id==null && other.getImport_id()==null) || 
             (this.import_id!=null &&
              this.import_id.equals(other.getImport_id()))) &&
            this.data_source_id == other.getData_source_id() &&
            ((this.name==null && other.getName()==null) || 
             (this.name!=null &&
              this.name.equals(other.getName()))) &&
            this.active == other.isActive() &&
            this.force_downgrade == other.isForce_downgrade() &&
            this.allow_parallel_usage == other.isAllow_parallel_usage() &&
            this.restrict_parallel_usage == other.isRestrict_parallel_usage() &&
            ((this.remarks==null && other.getRemarks()==null) || 
             (this.remarks!=null &&
              this.remarks.equals(other.getRemarks())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        _hashCode += getDg_path_id();
        if (getImport_id() != null) {
            _hashCode += getImport_id().hashCode();
        }
        _hashCode += getData_source_id();
        if (getName() != null) {
            _hashCode += getName().hashCode();
        }
        _hashCode += (isActive() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        _hashCode += (isForce_downgrade() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        _hashCode += (isAllow_parallel_usage() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        _hashCode += (isRestrict_parallel_usage() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        if (getRemarks() != null) {
            _hashCode += getRemarks().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Dg_path_rec.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://aspera.com/wsdl/", "dg_path_rec"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dg_path_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "dg_path_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("import_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "import_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("data_source_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "data_source_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("name");
        elemField.setXmlName(new javax.xml.namespace.QName("", "name"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("active");
        elemField.setXmlName(new javax.xml.namespace.QName("", "active"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("force_downgrade");
        elemField.setXmlName(new javax.xml.namespace.QName("", "force_downgrade"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("allow_parallel_usage");
        elemField.setXmlName(new javax.xml.namespace.QName("", "allow_parallel_usage"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("restrict_parallel_usage");
        elemField.setXmlName(new javax.xml.namespace.QName("", "restrict_parallel_usage"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("remarks");
        elemField.setXmlName(new javax.xml.namespace.QName("", "remarks"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}

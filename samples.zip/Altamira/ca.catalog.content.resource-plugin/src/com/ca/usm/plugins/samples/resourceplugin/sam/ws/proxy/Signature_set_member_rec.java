/**
 * Signature_set_member_rec.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ca.usm.plugins.samples.resourceplugin.sam.ws.proxy;

public class Signature_set_member_rec  implements java.io.Serializable {
    private int signature_set_member_id;

    private java.lang.String import_id;

    private int data_source_id;

    private int signature_arp_id;

    private int signature_file_id;

    private int signature_generic_id;

    private int signature_msi_id;

    private int signature_tag_id;

    private int signature_set_id;

    private java.lang.String operator;

    public Signature_set_member_rec() {
    }

    public Signature_set_member_rec(
           int signature_set_member_id,
           java.lang.String import_id,
           int data_source_id,
           int signature_arp_id,
           int signature_file_id,
           int signature_generic_id,
           int signature_msi_id,
           int signature_tag_id,
           int signature_set_id,
           java.lang.String operator) {
           this.signature_set_member_id = signature_set_member_id;
           this.import_id = import_id;
           this.data_source_id = data_source_id;
           this.signature_arp_id = signature_arp_id;
           this.signature_file_id = signature_file_id;
           this.signature_generic_id = signature_generic_id;
           this.signature_msi_id = signature_msi_id;
           this.signature_tag_id = signature_tag_id;
           this.signature_set_id = signature_set_id;
           this.operator = operator;
    }


    /**
     * Gets the signature_set_member_id value for this Signature_set_member_rec.
     * 
     * @return signature_set_member_id
     */
    public int getSignature_set_member_id() {
        return signature_set_member_id;
    }


    /**
     * Sets the signature_set_member_id value for this Signature_set_member_rec.
     * 
     * @param signature_set_member_id
     */
    public void setSignature_set_member_id(int signature_set_member_id) {
        this.signature_set_member_id = signature_set_member_id;
    }


    /**
     * Gets the import_id value for this Signature_set_member_rec.
     * 
     * @return import_id
     */
    public java.lang.String getImport_id() {
        return import_id;
    }


    /**
     * Sets the import_id value for this Signature_set_member_rec.
     * 
     * @param import_id
     */
    public void setImport_id(java.lang.String import_id) {
        this.import_id = import_id;
    }


    /**
     * Gets the data_source_id value for this Signature_set_member_rec.
     * 
     * @return data_source_id
     */
    public int getData_source_id() {
        return data_source_id;
    }


    /**
     * Sets the data_source_id value for this Signature_set_member_rec.
     * 
     * @param data_source_id
     */
    public void setData_source_id(int data_source_id) {
        this.data_source_id = data_source_id;
    }


    /**
     * Gets the signature_arp_id value for this Signature_set_member_rec.
     * 
     * @return signature_arp_id
     */
    public int getSignature_arp_id() {
        return signature_arp_id;
    }


    /**
     * Sets the signature_arp_id value for this Signature_set_member_rec.
     * 
     * @param signature_arp_id
     */
    public void setSignature_arp_id(int signature_arp_id) {
        this.signature_arp_id = signature_arp_id;
    }


    /**
     * Gets the signature_file_id value for this Signature_set_member_rec.
     * 
     * @return signature_file_id
     */
    public int getSignature_file_id() {
        return signature_file_id;
    }


    /**
     * Sets the signature_file_id value for this Signature_set_member_rec.
     * 
     * @param signature_file_id
     */
    public void setSignature_file_id(int signature_file_id) {
        this.signature_file_id = signature_file_id;
    }


    /**
     * Gets the signature_generic_id value for this Signature_set_member_rec.
     * 
     * @return signature_generic_id
     */
    public int getSignature_generic_id() {
        return signature_generic_id;
    }


    /**
     * Sets the signature_generic_id value for this Signature_set_member_rec.
     * 
     * @param signature_generic_id
     */
    public void setSignature_generic_id(int signature_generic_id) {
        this.signature_generic_id = signature_generic_id;
    }


    /**
     * Gets the signature_msi_id value for this Signature_set_member_rec.
     * 
     * @return signature_msi_id
     */
    public int getSignature_msi_id() {
        return signature_msi_id;
    }


    /**
     * Sets the signature_msi_id value for this Signature_set_member_rec.
     * 
     * @param signature_msi_id
     */
    public void setSignature_msi_id(int signature_msi_id) {
        this.signature_msi_id = signature_msi_id;
    }


    /**
     * Gets the signature_tag_id value for this Signature_set_member_rec.
     * 
     * @return signature_tag_id
     */
    public int getSignature_tag_id() {
        return signature_tag_id;
    }


    /**
     * Sets the signature_tag_id value for this Signature_set_member_rec.
     * 
     * @param signature_tag_id
     */
    public void setSignature_tag_id(int signature_tag_id) {
        this.signature_tag_id = signature_tag_id;
    }


    /**
     * Gets the signature_set_id value for this Signature_set_member_rec.
     * 
     * @return signature_set_id
     */
    public int getSignature_set_id() {
        return signature_set_id;
    }


    /**
     * Sets the signature_set_id value for this Signature_set_member_rec.
     * 
     * @param signature_set_id
     */
    public void setSignature_set_id(int signature_set_id) {
        this.signature_set_id = signature_set_id;
    }


    /**
     * Gets the operator value for this Signature_set_member_rec.
     * 
     * @return operator
     */
    public java.lang.String getOperator() {
        return operator;
    }


    /**
     * Sets the operator value for this Signature_set_member_rec.
     * 
     * @param operator
     */
    public void setOperator(java.lang.String operator) {
        this.operator = operator;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Signature_set_member_rec)) return false;
        Signature_set_member_rec other = (Signature_set_member_rec) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            this.signature_set_member_id == other.getSignature_set_member_id() &&
            ((this.import_id==null && other.getImport_id()==null) || 
             (this.import_id!=null &&
              this.import_id.equals(other.getImport_id()))) &&
            this.data_source_id == other.getData_source_id() &&
            this.signature_arp_id == other.getSignature_arp_id() &&
            this.signature_file_id == other.getSignature_file_id() &&
            this.signature_generic_id == other.getSignature_generic_id() &&
            this.signature_msi_id == other.getSignature_msi_id() &&
            this.signature_tag_id == other.getSignature_tag_id() &&
            this.signature_set_id == other.getSignature_set_id() &&
            ((this.operator==null && other.getOperator()==null) || 
             (this.operator!=null &&
              this.operator.equals(other.getOperator())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        _hashCode += getSignature_set_member_id();
        if (getImport_id() != null) {
            _hashCode += getImport_id().hashCode();
        }
        _hashCode += getData_source_id();
        _hashCode += getSignature_arp_id();
        _hashCode += getSignature_file_id();
        _hashCode += getSignature_generic_id();
        _hashCode += getSignature_msi_id();
        _hashCode += getSignature_tag_id();
        _hashCode += getSignature_set_id();
        if (getOperator() != null) {
            _hashCode += getOperator().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Signature_set_member_rec.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://aspera.com/wsdl/", "signature_set_member_rec"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("signature_set_member_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "signature_set_member_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("import_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "import_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("data_source_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "data_source_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("signature_arp_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "signature_arp_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("signature_file_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "signature_file_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("signature_generic_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "signature_generic_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("signature_msi_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "signature_msi_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("signature_tag_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "signature_tag_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("signature_set_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "signature_set_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("operator");
        elemField.setXmlName(new javax.xml.namespace.QName("", "operator"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}

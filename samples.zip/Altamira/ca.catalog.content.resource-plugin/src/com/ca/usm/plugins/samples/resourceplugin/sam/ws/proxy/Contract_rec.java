/**
 * Contract_rec.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ca.usm.plugins.samples.resourceplugin.sam.ws.proxy;

public class Contract_rec  implements java.io.Serializable {
    private int contract_id;

    private java.lang.String import_id;

    private int data_source_id;

    private int manufacturer_id;

    private int manufacturer_contact_id;

    private int org_level_0_id;

    private int org_level_1_id;

    private int org_level_2_id;

    private int customer_contact_id;

    private int customer_contact_tech_id;

    private int customer_contact_con_id;

    private int supplier_id;

    private int supplier_contact_id;

    private java.lang.String description;

    private java.lang.String contract_number;

    private java.lang.String contract_number_supplier;

    private java.lang.String contract_number_internal;

    private java.lang.String signed_date;

    private java.lang.String long_description;

    private int country_id;

    private int contract_status_id;

    private int contract_type_id;

    private int contract_class_id;

    private int language_id;

    private java.lang.String translations;

    private boolean outsourcing_allowed;

    private int contract_tf_id;

    private java.lang.String valid_from;

    private java.lang.String valid_until;

    private java.math.BigInteger expiration_notice_days;

    private java.lang.String expiration_notice;

    private boolean auto_renewal;

    private java.math.BigInteger renewal_month;

    private java.math.BigInteger cancellation_period;

    private java.lang.String canc_notice;

    private java.math.BigInteger canc_notice_days;

    private java.math.BigInteger maintenance;

    private java.lang.String maintenance_until;

    private java.math.BigInteger maint_notice_days;

    private java.lang.String maint_notice;

    private java.lang.String maintenance_percent;

    private java.lang.String maintenance_pa;

    private int currency_id;

    private java.lang.String remarks;

    private int contract_pay_term_id;

    private java.lang.String expend_limit;

    private int expend_limit_curr_id;

    private java.lang.String delivery_terms;

    public Contract_rec() {
    }

    public Contract_rec(
           int contract_id,
           java.lang.String import_id,
           int data_source_id,
           int manufacturer_id,
           int manufacturer_contact_id,
           int org_level_0_id,
           int org_level_1_id,
           int org_level_2_id,
           int customer_contact_id,
           int customer_contact_tech_id,
           int customer_contact_con_id,
           int supplier_id,
           int supplier_contact_id,
           java.lang.String description,
           java.lang.String contract_number,
           java.lang.String contract_number_supplier,
           java.lang.String contract_number_internal,
           java.lang.String signed_date,
           java.lang.String long_description,
           int country_id,
           int contract_status_id,
           int contract_type_id,
           int contract_class_id,
           int language_id,
           java.lang.String translations,
           boolean outsourcing_allowed,
           int contract_tf_id,
           java.lang.String valid_from,
           java.lang.String valid_until,
           java.math.BigInteger expiration_notice_days,
           java.lang.String expiration_notice,
           boolean auto_renewal,
           java.math.BigInteger renewal_month,
           java.math.BigInteger cancellation_period,
           java.lang.String canc_notice,
           java.math.BigInteger canc_notice_days,
           java.math.BigInteger maintenance,
           java.lang.String maintenance_until,
           java.math.BigInteger maint_notice_days,
           java.lang.String maint_notice,
           java.lang.String maintenance_percent,
           java.lang.String maintenance_pa,
           int currency_id,
           java.lang.String remarks,
           int contract_pay_term_id,
           java.lang.String expend_limit,
           int expend_limit_curr_id,
           java.lang.String delivery_terms) {
           this.contract_id = contract_id;
           this.import_id = import_id;
           this.data_source_id = data_source_id;
           this.manufacturer_id = manufacturer_id;
           this.manufacturer_contact_id = manufacturer_contact_id;
           this.org_level_0_id = org_level_0_id;
           this.org_level_1_id = org_level_1_id;
           this.org_level_2_id = org_level_2_id;
           this.customer_contact_id = customer_contact_id;
           this.customer_contact_tech_id = customer_contact_tech_id;
           this.customer_contact_con_id = customer_contact_con_id;
           this.supplier_id = supplier_id;
           this.supplier_contact_id = supplier_contact_id;
           this.description = description;
           this.contract_number = contract_number;
           this.contract_number_supplier = contract_number_supplier;
           this.contract_number_internal = contract_number_internal;
           this.signed_date = signed_date;
           this.long_description = long_description;
           this.country_id = country_id;
           this.contract_status_id = contract_status_id;
           this.contract_type_id = contract_type_id;
           this.contract_class_id = contract_class_id;
           this.language_id = language_id;
           this.translations = translations;
           this.outsourcing_allowed = outsourcing_allowed;
           this.contract_tf_id = contract_tf_id;
           this.valid_from = valid_from;
           this.valid_until = valid_until;
           this.expiration_notice_days = expiration_notice_days;
           this.expiration_notice = expiration_notice;
           this.auto_renewal = auto_renewal;
           this.renewal_month = renewal_month;
           this.cancellation_period = cancellation_period;
           this.canc_notice = canc_notice;
           this.canc_notice_days = canc_notice_days;
           this.maintenance = maintenance;
           this.maintenance_until = maintenance_until;
           this.maint_notice_days = maint_notice_days;
           this.maint_notice = maint_notice;
           this.maintenance_percent = maintenance_percent;
           this.maintenance_pa = maintenance_pa;
           this.currency_id = currency_id;
           this.remarks = remarks;
           this.contract_pay_term_id = contract_pay_term_id;
           this.expend_limit = expend_limit;
           this.expend_limit_curr_id = expend_limit_curr_id;
           this.delivery_terms = delivery_terms;
    }


    /**
     * Gets the contract_id value for this Contract_rec.
     * 
     * @return contract_id
     */
    public int getContract_id() {
        return contract_id;
    }


    /**
     * Sets the contract_id value for this Contract_rec.
     * 
     * @param contract_id
     */
    public void setContract_id(int contract_id) {
        this.contract_id = contract_id;
    }


    /**
     * Gets the import_id value for this Contract_rec.
     * 
     * @return import_id
     */
    public java.lang.String getImport_id() {
        return import_id;
    }


    /**
     * Sets the import_id value for this Contract_rec.
     * 
     * @param import_id
     */
    public void setImport_id(java.lang.String import_id) {
        this.import_id = import_id;
    }


    /**
     * Gets the data_source_id value for this Contract_rec.
     * 
     * @return data_source_id
     */
    public int getData_source_id() {
        return data_source_id;
    }


    /**
     * Sets the data_source_id value for this Contract_rec.
     * 
     * @param data_source_id
     */
    public void setData_source_id(int data_source_id) {
        this.data_source_id = data_source_id;
    }


    /**
     * Gets the manufacturer_id value for this Contract_rec.
     * 
     * @return manufacturer_id
     */
    public int getManufacturer_id() {
        return manufacturer_id;
    }


    /**
     * Sets the manufacturer_id value for this Contract_rec.
     * 
     * @param manufacturer_id
     */
    public void setManufacturer_id(int manufacturer_id) {
        this.manufacturer_id = manufacturer_id;
    }


    /**
     * Gets the manufacturer_contact_id value for this Contract_rec.
     * 
     * @return manufacturer_contact_id
     */
    public int getManufacturer_contact_id() {
        return manufacturer_contact_id;
    }


    /**
     * Sets the manufacturer_contact_id value for this Contract_rec.
     * 
     * @param manufacturer_contact_id
     */
    public void setManufacturer_contact_id(int manufacturer_contact_id) {
        this.manufacturer_contact_id = manufacturer_contact_id;
    }


    /**
     * Gets the org_level_0_id value for this Contract_rec.
     * 
     * @return org_level_0_id
     */
    public int getOrg_level_0_id() {
        return org_level_0_id;
    }


    /**
     * Sets the org_level_0_id value for this Contract_rec.
     * 
     * @param org_level_0_id
     */
    public void setOrg_level_0_id(int org_level_0_id) {
        this.org_level_0_id = org_level_0_id;
    }


    /**
     * Gets the org_level_1_id value for this Contract_rec.
     * 
     * @return org_level_1_id
     */
    public int getOrg_level_1_id() {
        return org_level_1_id;
    }


    /**
     * Sets the org_level_1_id value for this Contract_rec.
     * 
     * @param org_level_1_id
     */
    public void setOrg_level_1_id(int org_level_1_id) {
        this.org_level_1_id = org_level_1_id;
    }


    /**
     * Gets the org_level_2_id value for this Contract_rec.
     * 
     * @return org_level_2_id
     */
    public int getOrg_level_2_id() {
        return org_level_2_id;
    }


    /**
     * Sets the org_level_2_id value for this Contract_rec.
     * 
     * @param org_level_2_id
     */
    public void setOrg_level_2_id(int org_level_2_id) {
        this.org_level_2_id = org_level_2_id;
    }


    /**
     * Gets the customer_contact_id value for this Contract_rec.
     * 
     * @return customer_contact_id
     */
    public int getCustomer_contact_id() {
        return customer_contact_id;
    }


    /**
     * Sets the customer_contact_id value for this Contract_rec.
     * 
     * @param customer_contact_id
     */
    public void setCustomer_contact_id(int customer_contact_id) {
        this.customer_contact_id = customer_contact_id;
    }


    /**
     * Gets the customer_contact_tech_id value for this Contract_rec.
     * 
     * @return customer_contact_tech_id
     */
    public int getCustomer_contact_tech_id() {
        return customer_contact_tech_id;
    }


    /**
     * Sets the customer_contact_tech_id value for this Contract_rec.
     * 
     * @param customer_contact_tech_id
     */
    public void setCustomer_contact_tech_id(int customer_contact_tech_id) {
        this.customer_contact_tech_id = customer_contact_tech_id;
    }


    /**
     * Gets the customer_contact_con_id value for this Contract_rec.
     * 
     * @return customer_contact_con_id
     */
    public int getCustomer_contact_con_id() {
        return customer_contact_con_id;
    }


    /**
     * Sets the customer_contact_con_id value for this Contract_rec.
     * 
     * @param customer_contact_con_id
     */
    public void setCustomer_contact_con_id(int customer_contact_con_id) {
        this.customer_contact_con_id = customer_contact_con_id;
    }


    /**
     * Gets the supplier_id value for this Contract_rec.
     * 
     * @return supplier_id
     */
    public int getSupplier_id() {
        return supplier_id;
    }


    /**
     * Sets the supplier_id value for this Contract_rec.
     * 
     * @param supplier_id
     */
    public void setSupplier_id(int supplier_id) {
        this.supplier_id = supplier_id;
    }


    /**
     * Gets the supplier_contact_id value for this Contract_rec.
     * 
     * @return supplier_contact_id
     */
    public int getSupplier_contact_id() {
        return supplier_contact_id;
    }


    /**
     * Sets the supplier_contact_id value for this Contract_rec.
     * 
     * @param supplier_contact_id
     */
    public void setSupplier_contact_id(int supplier_contact_id) {
        this.supplier_contact_id = supplier_contact_id;
    }


    /**
     * Gets the description value for this Contract_rec.
     * 
     * @return description
     */
    public java.lang.String getDescription() {
        return description;
    }


    /**
     * Sets the description value for this Contract_rec.
     * 
     * @param description
     */
    public void setDescription(java.lang.String description) {
        this.description = description;
    }


    /**
     * Gets the contract_number value for this Contract_rec.
     * 
     * @return contract_number
     */
    public java.lang.String getContract_number() {
        return contract_number;
    }


    /**
     * Sets the contract_number value for this Contract_rec.
     * 
     * @param contract_number
     */
    public void setContract_number(java.lang.String contract_number) {
        this.contract_number = contract_number;
    }


    /**
     * Gets the contract_number_supplier value for this Contract_rec.
     * 
     * @return contract_number_supplier
     */
    public java.lang.String getContract_number_supplier() {
        return contract_number_supplier;
    }


    /**
     * Sets the contract_number_supplier value for this Contract_rec.
     * 
     * @param contract_number_supplier
     */
    public void setContract_number_supplier(java.lang.String contract_number_supplier) {
        this.contract_number_supplier = contract_number_supplier;
    }


    /**
     * Gets the contract_number_internal value for this Contract_rec.
     * 
     * @return contract_number_internal
     */
    public java.lang.String getContract_number_internal() {
        return contract_number_internal;
    }


    /**
     * Sets the contract_number_internal value for this Contract_rec.
     * 
     * @param contract_number_internal
     */
    public void setContract_number_internal(java.lang.String contract_number_internal) {
        this.contract_number_internal = contract_number_internal;
    }


    /**
     * Gets the signed_date value for this Contract_rec.
     * 
     * @return signed_date
     */
    public java.lang.String getSigned_date() {
        return signed_date;
    }


    /**
     * Sets the signed_date value for this Contract_rec.
     * 
     * @param signed_date
     */
    public void setSigned_date(java.lang.String signed_date) {
        this.signed_date = signed_date;
    }


    /**
     * Gets the long_description value for this Contract_rec.
     * 
     * @return long_description
     */
    public java.lang.String getLong_description() {
        return long_description;
    }


    /**
     * Sets the long_description value for this Contract_rec.
     * 
     * @param long_description
     */
    public void setLong_description(java.lang.String long_description) {
        this.long_description = long_description;
    }


    /**
     * Gets the country_id value for this Contract_rec.
     * 
     * @return country_id
     */
    public int getCountry_id() {
        return country_id;
    }


    /**
     * Sets the country_id value for this Contract_rec.
     * 
     * @param country_id
     */
    public void setCountry_id(int country_id) {
        this.country_id = country_id;
    }


    /**
     * Gets the contract_status_id value for this Contract_rec.
     * 
     * @return contract_status_id
     */
    public int getContract_status_id() {
        return contract_status_id;
    }


    /**
     * Sets the contract_status_id value for this Contract_rec.
     * 
     * @param contract_status_id
     */
    public void setContract_status_id(int contract_status_id) {
        this.contract_status_id = contract_status_id;
    }


    /**
     * Gets the contract_type_id value for this Contract_rec.
     * 
     * @return contract_type_id
     */
    public int getContract_type_id() {
        return contract_type_id;
    }


    /**
     * Sets the contract_type_id value for this Contract_rec.
     * 
     * @param contract_type_id
     */
    public void setContract_type_id(int contract_type_id) {
        this.contract_type_id = contract_type_id;
    }


    /**
     * Gets the contract_class_id value for this Contract_rec.
     * 
     * @return contract_class_id
     */
    public int getContract_class_id() {
        return contract_class_id;
    }


    /**
     * Sets the contract_class_id value for this Contract_rec.
     * 
     * @param contract_class_id
     */
    public void setContract_class_id(int contract_class_id) {
        this.contract_class_id = contract_class_id;
    }


    /**
     * Gets the language_id value for this Contract_rec.
     * 
     * @return language_id
     */
    public int getLanguage_id() {
        return language_id;
    }


    /**
     * Sets the language_id value for this Contract_rec.
     * 
     * @param language_id
     */
    public void setLanguage_id(int language_id) {
        this.language_id = language_id;
    }


    /**
     * Gets the translations value for this Contract_rec.
     * 
     * @return translations
     */
    public java.lang.String getTranslations() {
        return translations;
    }


    /**
     * Sets the translations value for this Contract_rec.
     * 
     * @param translations
     */
    public void setTranslations(java.lang.String translations) {
        this.translations = translations;
    }


    /**
     * Gets the outsourcing_allowed value for this Contract_rec.
     * 
     * @return outsourcing_allowed
     */
    public boolean isOutsourcing_allowed() {
        return outsourcing_allowed;
    }


    /**
     * Sets the outsourcing_allowed value for this Contract_rec.
     * 
     * @param outsourcing_allowed
     */
    public void setOutsourcing_allowed(boolean outsourcing_allowed) {
        this.outsourcing_allowed = outsourcing_allowed;
    }


    /**
     * Gets the contract_tf_id value for this Contract_rec.
     * 
     * @return contract_tf_id
     */
    public int getContract_tf_id() {
        return contract_tf_id;
    }


    /**
     * Sets the contract_tf_id value for this Contract_rec.
     * 
     * @param contract_tf_id
     */
    public void setContract_tf_id(int contract_tf_id) {
        this.contract_tf_id = contract_tf_id;
    }


    /**
     * Gets the valid_from value for this Contract_rec.
     * 
     * @return valid_from
     */
    public java.lang.String getValid_from() {
        return valid_from;
    }


    /**
     * Sets the valid_from value for this Contract_rec.
     * 
     * @param valid_from
     */
    public void setValid_from(java.lang.String valid_from) {
        this.valid_from = valid_from;
    }


    /**
     * Gets the valid_until value for this Contract_rec.
     * 
     * @return valid_until
     */
    public java.lang.String getValid_until() {
        return valid_until;
    }


    /**
     * Sets the valid_until value for this Contract_rec.
     * 
     * @param valid_until
     */
    public void setValid_until(java.lang.String valid_until) {
        this.valid_until = valid_until;
    }


    /**
     * Gets the expiration_notice_days value for this Contract_rec.
     * 
     * @return expiration_notice_days
     */
    public java.math.BigInteger getExpiration_notice_days() {
        return expiration_notice_days;
    }


    /**
     * Sets the expiration_notice_days value for this Contract_rec.
     * 
     * @param expiration_notice_days
     */
    public void setExpiration_notice_days(java.math.BigInteger expiration_notice_days) {
        this.expiration_notice_days = expiration_notice_days;
    }


    /**
     * Gets the expiration_notice value for this Contract_rec.
     * 
     * @return expiration_notice
     */
    public java.lang.String getExpiration_notice() {
        return expiration_notice;
    }


    /**
     * Sets the expiration_notice value for this Contract_rec.
     * 
     * @param expiration_notice
     */
    public void setExpiration_notice(java.lang.String expiration_notice) {
        this.expiration_notice = expiration_notice;
    }


    /**
     * Gets the auto_renewal value for this Contract_rec.
     * 
     * @return auto_renewal
     */
    public boolean isAuto_renewal() {
        return auto_renewal;
    }


    /**
     * Sets the auto_renewal value for this Contract_rec.
     * 
     * @param auto_renewal
     */
    public void setAuto_renewal(boolean auto_renewal) {
        this.auto_renewal = auto_renewal;
    }


    /**
     * Gets the renewal_month value for this Contract_rec.
     * 
     * @return renewal_month
     */
    public java.math.BigInteger getRenewal_month() {
        return renewal_month;
    }


    /**
     * Sets the renewal_month value for this Contract_rec.
     * 
     * @param renewal_month
     */
    public void setRenewal_month(java.math.BigInteger renewal_month) {
        this.renewal_month = renewal_month;
    }


    /**
     * Gets the cancellation_period value for this Contract_rec.
     * 
     * @return cancellation_period
     */
    public java.math.BigInteger getCancellation_period() {
        return cancellation_period;
    }


    /**
     * Sets the cancellation_period value for this Contract_rec.
     * 
     * @param cancellation_period
     */
    public void setCancellation_period(java.math.BigInteger cancellation_period) {
        this.cancellation_period = cancellation_period;
    }


    /**
     * Gets the canc_notice value for this Contract_rec.
     * 
     * @return canc_notice
     */
    public java.lang.String getCanc_notice() {
        return canc_notice;
    }


    /**
     * Sets the canc_notice value for this Contract_rec.
     * 
     * @param canc_notice
     */
    public void setCanc_notice(java.lang.String canc_notice) {
        this.canc_notice = canc_notice;
    }


    /**
     * Gets the canc_notice_days value for this Contract_rec.
     * 
     * @return canc_notice_days
     */
    public java.math.BigInteger getCanc_notice_days() {
        return canc_notice_days;
    }


    /**
     * Sets the canc_notice_days value for this Contract_rec.
     * 
     * @param canc_notice_days
     */
    public void setCanc_notice_days(java.math.BigInteger canc_notice_days) {
        this.canc_notice_days = canc_notice_days;
    }


    /**
     * Gets the maintenance value for this Contract_rec.
     * 
     * @return maintenance
     */
    public java.math.BigInteger getMaintenance() {
        return maintenance;
    }


    /**
     * Sets the maintenance value for this Contract_rec.
     * 
     * @param maintenance
     */
    public void setMaintenance(java.math.BigInteger maintenance) {
        this.maintenance = maintenance;
    }


    /**
     * Gets the maintenance_until value for this Contract_rec.
     * 
     * @return maintenance_until
     */
    public java.lang.String getMaintenance_until() {
        return maintenance_until;
    }


    /**
     * Sets the maintenance_until value for this Contract_rec.
     * 
     * @param maintenance_until
     */
    public void setMaintenance_until(java.lang.String maintenance_until) {
        this.maintenance_until = maintenance_until;
    }


    /**
     * Gets the maint_notice_days value for this Contract_rec.
     * 
     * @return maint_notice_days
     */
    public java.math.BigInteger getMaint_notice_days() {
        return maint_notice_days;
    }


    /**
     * Sets the maint_notice_days value for this Contract_rec.
     * 
     * @param maint_notice_days
     */
    public void setMaint_notice_days(java.math.BigInteger maint_notice_days) {
        this.maint_notice_days = maint_notice_days;
    }


    /**
     * Gets the maint_notice value for this Contract_rec.
     * 
     * @return maint_notice
     */
    public java.lang.String getMaint_notice() {
        return maint_notice;
    }


    /**
     * Sets the maint_notice value for this Contract_rec.
     * 
     * @param maint_notice
     */
    public void setMaint_notice(java.lang.String maint_notice) {
        this.maint_notice = maint_notice;
    }


    /**
     * Gets the maintenance_percent value for this Contract_rec.
     * 
     * @return maintenance_percent
     */
    public java.lang.String getMaintenance_percent() {
        return maintenance_percent;
    }


    /**
     * Sets the maintenance_percent value for this Contract_rec.
     * 
     * @param maintenance_percent
     */
    public void setMaintenance_percent(java.lang.String maintenance_percent) {
        this.maintenance_percent = maintenance_percent;
    }


    /**
     * Gets the maintenance_pa value for this Contract_rec.
     * 
     * @return maintenance_pa
     */
    public java.lang.String getMaintenance_pa() {
        return maintenance_pa;
    }


    /**
     * Sets the maintenance_pa value for this Contract_rec.
     * 
     * @param maintenance_pa
     */
    public void setMaintenance_pa(java.lang.String maintenance_pa) {
        this.maintenance_pa = maintenance_pa;
    }


    /**
     * Gets the currency_id value for this Contract_rec.
     * 
     * @return currency_id
     */
    public int getCurrency_id() {
        return currency_id;
    }


    /**
     * Sets the currency_id value for this Contract_rec.
     * 
     * @param currency_id
     */
    public void setCurrency_id(int currency_id) {
        this.currency_id = currency_id;
    }


    /**
     * Gets the remarks value for this Contract_rec.
     * 
     * @return remarks
     */
    public java.lang.String getRemarks() {
        return remarks;
    }


    /**
     * Sets the remarks value for this Contract_rec.
     * 
     * @param remarks
     */
    public void setRemarks(java.lang.String remarks) {
        this.remarks = remarks;
    }


    /**
     * Gets the contract_pay_term_id value for this Contract_rec.
     * 
     * @return contract_pay_term_id
     */
    public int getContract_pay_term_id() {
        return contract_pay_term_id;
    }


    /**
     * Sets the contract_pay_term_id value for this Contract_rec.
     * 
     * @param contract_pay_term_id
     */
    public void setContract_pay_term_id(int contract_pay_term_id) {
        this.contract_pay_term_id = contract_pay_term_id;
    }


    /**
     * Gets the expend_limit value for this Contract_rec.
     * 
     * @return expend_limit
     */
    public java.lang.String getExpend_limit() {
        return expend_limit;
    }


    /**
     * Sets the expend_limit value for this Contract_rec.
     * 
     * @param expend_limit
     */
    public void setExpend_limit(java.lang.String expend_limit) {
        this.expend_limit = expend_limit;
    }


    /**
     * Gets the expend_limit_curr_id value for this Contract_rec.
     * 
     * @return expend_limit_curr_id
     */
    public int getExpend_limit_curr_id() {
        return expend_limit_curr_id;
    }


    /**
     * Sets the expend_limit_curr_id value for this Contract_rec.
     * 
     * @param expend_limit_curr_id
     */
    public void setExpend_limit_curr_id(int expend_limit_curr_id) {
        this.expend_limit_curr_id = expend_limit_curr_id;
    }


    /**
     * Gets the delivery_terms value for this Contract_rec.
     * 
     * @return delivery_terms
     */
    public java.lang.String getDelivery_terms() {
        return delivery_terms;
    }


    /**
     * Sets the delivery_terms value for this Contract_rec.
     * 
     * @param delivery_terms
     */
    public void setDelivery_terms(java.lang.String delivery_terms) {
        this.delivery_terms = delivery_terms;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Contract_rec)) return false;
        Contract_rec other = (Contract_rec) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            this.contract_id == other.getContract_id() &&
            ((this.import_id==null && other.getImport_id()==null) || 
             (this.import_id!=null &&
              this.import_id.equals(other.getImport_id()))) &&
            this.data_source_id == other.getData_source_id() &&
            this.manufacturer_id == other.getManufacturer_id() &&
            this.manufacturer_contact_id == other.getManufacturer_contact_id() &&
            this.org_level_0_id == other.getOrg_level_0_id() &&
            this.org_level_1_id == other.getOrg_level_1_id() &&
            this.org_level_2_id == other.getOrg_level_2_id() &&
            this.customer_contact_id == other.getCustomer_contact_id() &&
            this.customer_contact_tech_id == other.getCustomer_contact_tech_id() &&
            this.customer_contact_con_id == other.getCustomer_contact_con_id() &&
            this.supplier_id == other.getSupplier_id() &&
            this.supplier_contact_id == other.getSupplier_contact_id() &&
            ((this.description==null && other.getDescription()==null) || 
             (this.description!=null &&
              this.description.equals(other.getDescription()))) &&
            ((this.contract_number==null && other.getContract_number()==null) || 
             (this.contract_number!=null &&
              this.contract_number.equals(other.getContract_number()))) &&
            ((this.contract_number_supplier==null && other.getContract_number_supplier()==null) || 
             (this.contract_number_supplier!=null &&
              this.contract_number_supplier.equals(other.getContract_number_supplier()))) &&
            ((this.contract_number_internal==null && other.getContract_number_internal()==null) || 
             (this.contract_number_internal!=null &&
              this.contract_number_internal.equals(other.getContract_number_internal()))) &&
            ((this.signed_date==null && other.getSigned_date()==null) || 
             (this.signed_date!=null &&
              this.signed_date.equals(other.getSigned_date()))) &&
            ((this.long_description==null && other.getLong_description()==null) || 
             (this.long_description!=null &&
              this.long_description.equals(other.getLong_description()))) &&
            this.country_id == other.getCountry_id() &&
            this.contract_status_id == other.getContract_status_id() &&
            this.contract_type_id == other.getContract_type_id() &&
            this.contract_class_id == other.getContract_class_id() &&
            this.language_id == other.getLanguage_id() &&
            ((this.translations==null && other.getTranslations()==null) || 
             (this.translations!=null &&
              this.translations.equals(other.getTranslations()))) &&
            this.outsourcing_allowed == other.isOutsourcing_allowed() &&
            this.contract_tf_id == other.getContract_tf_id() &&
            ((this.valid_from==null && other.getValid_from()==null) || 
             (this.valid_from!=null &&
              this.valid_from.equals(other.getValid_from()))) &&
            ((this.valid_until==null && other.getValid_until()==null) || 
             (this.valid_until!=null &&
              this.valid_until.equals(other.getValid_until()))) &&
            ((this.expiration_notice_days==null && other.getExpiration_notice_days()==null) || 
             (this.expiration_notice_days!=null &&
              this.expiration_notice_days.equals(other.getExpiration_notice_days()))) &&
            ((this.expiration_notice==null && other.getExpiration_notice()==null) || 
             (this.expiration_notice!=null &&
              this.expiration_notice.equals(other.getExpiration_notice()))) &&
            this.auto_renewal == other.isAuto_renewal() &&
            ((this.renewal_month==null && other.getRenewal_month()==null) || 
             (this.renewal_month!=null &&
              this.renewal_month.equals(other.getRenewal_month()))) &&
            ((this.cancellation_period==null && other.getCancellation_period()==null) || 
             (this.cancellation_period!=null &&
              this.cancellation_period.equals(other.getCancellation_period()))) &&
            ((this.canc_notice==null && other.getCanc_notice()==null) || 
             (this.canc_notice!=null &&
              this.canc_notice.equals(other.getCanc_notice()))) &&
            ((this.canc_notice_days==null && other.getCanc_notice_days()==null) || 
             (this.canc_notice_days!=null &&
              this.canc_notice_days.equals(other.getCanc_notice_days()))) &&
            ((this.maintenance==null && other.getMaintenance()==null) || 
             (this.maintenance!=null &&
              this.maintenance.equals(other.getMaintenance()))) &&
            ((this.maintenance_until==null && other.getMaintenance_until()==null) || 
             (this.maintenance_until!=null &&
              this.maintenance_until.equals(other.getMaintenance_until()))) &&
            ((this.maint_notice_days==null && other.getMaint_notice_days()==null) || 
             (this.maint_notice_days!=null &&
              this.maint_notice_days.equals(other.getMaint_notice_days()))) &&
            ((this.maint_notice==null && other.getMaint_notice()==null) || 
             (this.maint_notice!=null &&
              this.maint_notice.equals(other.getMaint_notice()))) &&
            ((this.maintenance_percent==null && other.getMaintenance_percent()==null) || 
             (this.maintenance_percent!=null &&
              this.maintenance_percent.equals(other.getMaintenance_percent()))) &&
            ((this.maintenance_pa==null && other.getMaintenance_pa()==null) || 
             (this.maintenance_pa!=null &&
              this.maintenance_pa.equals(other.getMaintenance_pa()))) &&
            this.currency_id == other.getCurrency_id() &&
            ((this.remarks==null && other.getRemarks()==null) || 
             (this.remarks!=null &&
              this.remarks.equals(other.getRemarks()))) &&
            this.contract_pay_term_id == other.getContract_pay_term_id() &&
            ((this.expend_limit==null && other.getExpend_limit()==null) || 
             (this.expend_limit!=null &&
              this.expend_limit.equals(other.getExpend_limit()))) &&
            this.expend_limit_curr_id == other.getExpend_limit_curr_id() &&
            ((this.delivery_terms==null && other.getDelivery_terms()==null) || 
             (this.delivery_terms!=null &&
              this.delivery_terms.equals(other.getDelivery_terms())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        _hashCode += getContract_id();
        if (getImport_id() != null) {
            _hashCode += getImport_id().hashCode();
        }
        _hashCode += getData_source_id();
        _hashCode += getManufacturer_id();
        _hashCode += getManufacturer_contact_id();
        _hashCode += getOrg_level_0_id();
        _hashCode += getOrg_level_1_id();
        _hashCode += getOrg_level_2_id();
        _hashCode += getCustomer_contact_id();
        _hashCode += getCustomer_contact_tech_id();
        _hashCode += getCustomer_contact_con_id();
        _hashCode += getSupplier_id();
        _hashCode += getSupplier_contact_id();
        if (getDescription() != null) {
            _hashCode += getDescription().hashCode();
        }
        if (getContract_number() != null) {
            _hashCode += getContract_number().hashCode();
        }
        if (getContract_number_supplier() != null) {
            _hashCode += getContract_number_supplier().hashCode();
        }
        if (getContract_number_internal() != null) {
            _hashCode += getContract_number_internal().hashCode();
        }
        if (getSigned_date() != null) {
            _hashCode += getSigned_date().hashCode();
        }
        if (getLong_description() != null) {
            _hashCode += getLong_description().hashCode();
        }
        _hashCode += getCountry_id();
        _hashCode += getContract_status_id();
        _hashCode += getContract_type_id();
        _hashCode += getContract_class_id();
        _hashCode += getLanguage_id();
        if (getTranslations() != null) {
            _hashCode += getTranslations().hashCode();
        }
        _hashCode += (isOutsourcing_allowed() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        _hashCode += getContract_tf_id();
        if (getValid_from() != null) {
            _hashCode += getValid_from().hashCode();
        }
        if (getValid_until() != null) {
            _hashCode += getValid_until().hashCode();
        }
        if (getExpiration_notice_days() != null) {
            _hashCode += getExpiration_notice_days().hashCode();
        }
        if (getExpiration_notice() != null) {
            _hashCode += getExpiration_notice().hashCode();
        }
        _hashCode += (isAuto_renewal() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        if (getRenewal_month() != null) {
            _hashCode += getRenewal_month().hashCode();
        }
        if (getCancellation_period() != null) {
            _hashCode += getCancellation_period().hashCode();
        }
        if (getCanc_notice() != null) {
            _hashCode += getCanc_notice().hashCode();
        }
        if (getCanc_notice_days() != null) {
            _hashCode += getCanc_notice_days().hashCode();
        }
        if (getMaintenance() != null) {
            _hashCode += getMaintenance().hashCode();
        }
        if (getMaintenance_until() != null) {
            _hashCode += getMaintenance_until().hashCode();
        }
        if (getMaint_notice_days() != null) {
            _hashCode += getMaint_notice_days().hashCode();
        }
        if (getMaint_notice() != null) {
            _hashCode += getMaint_notice().hashCode();
        }
        if (getMaintenance_percent() != null) {
            _hashCode += getMaintenance_percent().hashCode();
        }
        if (getMaintenance_pa() != null) {
            _hashCode += getMaintenance_pa().hashCode();
        }
        _hashCode += getCurrency_id();
        if (getRemarks() != null) {
            _hashCode += getRemarks().hashCode();
        }
        _hashCode += getContract_pay_term_id();
        if (getExpend_limit() != null) {
            _hashCode += getExpend_limit().hashCode();
        }
        _hashCode += getExpend_limit_curr_id();
        if (getDelivery_terms() != null) {
            _hashCode += getDelivery_terms().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Contract_rec.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://aspera.com/wsdl/", "contract_rec"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("contract_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "contract_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("import_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "import_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("data_source_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "data_source_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("manufacturer_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "manufacturer_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("manufacturer_contact_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "manufacturer_contact_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("org_level_0_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "org_level_0_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("org_level_1_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "org_level_1_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("org_level_2_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "org_level_2_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("customer_contact_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "customer_contact_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("customer_contact_tech_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "customer_contact_tech_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("customer_contact_con_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "customer_contact_con_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("supplier_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "supplier_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("supplier_contact_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "supplier_contact_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("description");
        elemField.setXmlName(new javax.xml.namespace.QName("", "description"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("contract_number");
        elemField.setXmlName(new javax.xml.namespace.QName("", "contract_number"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("contract_number_supplier");
        elemField.setXmlName(new javax.xml.namespace.QName("", "contract_number_supplier"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("contract_number_internal");
        elemField.setXmlName(new javax.xml.namespace.QName("", "contract_number_internal"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("signed_date");
        elemField.setXmlName(new javax.xml.namespace.QName("", "signed_date"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("long_description");
        elemField.setXmlName(new javax.xml.namespace.QName("", "long_description"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("country_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "country_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("contract_status_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "contract_status_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("contract_type_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "contract_type_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("contract_class_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "contract_class_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("language_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "language_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("translations");
        elemField.setXmlName(new javax.xml.namespace.QName("", "translations"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("outsourcing_allowed");
        elemField.setXmlName(new javax.xml.namespace.QName("", "outsourcing_allowed"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("contract_tf_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "contract_tf_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("valid_from");
        elemField.setXmlName(new javax.xml.namespace.QName("", "valid_from"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("valid_until");
        elemField.setXmlName(new javax.xml.namespace.QName("", "valid_until"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("expiration_notice_days");
        elemField.setXmlName(new javax.xml.namespace.QName("", "expiration_notice_days"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("expiration_notice");
        elemField.setXmlName(new javax.xml.namespace.QName("", "expiration_notice"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("auto_renewal");
        elemField.setXmlName(new javax.xml.namespace.QName("", "auto_renewal"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("renewal_month");
        elemField.setXmlName(new javax.xml.namespace.QName("", "renewal_month"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("cancellation_period");
        elemField.setXmlName(new javax.xml.namespace.QName("", "cancellation_period"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("canc_notice");
        elemField.setXmlName(new javax.xml.namespace.QName("", "canc_notice"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("canc_notice_days");
        elemField.setXmlName(new javax.xml.namespace.QName("", "canc_notice_days"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("maintenance");
        elemField.setXmlName(new javax.xml.namespace.QName("", "maintenance"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("maintenance_until");
        elemField.setXmlName(new javax.xml.namespace.QName("", "maintenance_until"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("maint_notice_days");
        elemField.setXmlName(new javax.xml.namespace.QName("", "maint_notice_days"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("maint_notice");
        elemField.setXmlName(new javax.xml.namespace.QName("", "maint_notice"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("maintenance_percent");
        elemField.setXmlName(new javax.xml.namespace.QName("", "maintenance_percent"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("maintenance_pa");
        elemField.setXmlName(new javax.xml.namespace.QName("", "maintenance_pa"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("currency_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "currency_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("remarks");
        elemField.setXmlName(new javax.xml.namespace.QName("", "remarks"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("contract_pay_term_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "contract_pay_term_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("expend_limit");
        elemField.setXmlName(new javax.xml.namespace.QName("", "expend_limit"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("expend_limit_curr_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "expend_limit_curr_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("delivery_terms");
        elemField.setXmlName(new javax.xml.namespace.QName("", "delivery_terms"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}

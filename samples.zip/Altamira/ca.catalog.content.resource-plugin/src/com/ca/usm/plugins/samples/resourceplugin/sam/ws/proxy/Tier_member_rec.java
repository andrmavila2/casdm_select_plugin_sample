/**
 * Tier_member_rec.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ca.usm.plugins.samples.resourceplugin.sam.ws.proxy;

public class Tier_member_rec  implements java.io.Serializable {
    private int tier_member_id;

    private java.lang.String import_id;

    private int data_source_id;

    private int tier_id;

    private java.math.BigInteger range_min;

    private java.math.BigInteger range_max;

    private java.lang.String base;

    private java.lang.String factor;

    private int product_id;

    private java.lang.String description;

    public Tier_member_rec() {
    }

    public Tier_member_rec(
           int tier_member_id,
           java.lang.String import_id,
           int data_source_id,
           int tier_id,
           java.math.BigInteger range_min,
           java.math.BigInteger range_max,
           java.lang.String base,
           java.lang.String factor,
           int product_id,
           java.lang.String description) {
           this.tier_member_id = tier_member_id;
           this.import_id = import_id;
           this.data_source_id = data_source_id;
           this.tier_id = tier_id;
           this.range_min = range_min;
           this.range_max = range_max;
           this.base = base;
           this.factor = factor;
           this.product_id = product_id;
           this.description = description;
    }


    /**
     * Gets the tier_member_id value for this Tier_member_rec.
     * 
     * @return tier_member_id
     */
    public int getTier_member_id() {
        return tier_member_id;
    }


    /**
     * Sets the tier_member_id value for this Tier_member_rec.
     * 
     * @param tier_member_id
     */
    public void setTier_member_id(int tier_member_id) {
        this.tier_member_id = tier_member_id;
    }


    /**
     * Gets the import_id value for this Tier_member_rec.
     * 
     * @return import_id
     */
    public java.lang.String getImport_id() {
        return import_id;
    }


    /**
     * Sets the import_id value for this Tier_member_rec.
     * 
     * @param import_id
     */
    public void setImport_id(java.lang.String import_id) {
        this.import_id = import_id;
    }


    /**
     * Gets the data_source_id value for this Tier_member_rec.
     * 
     * @return data_source_id
     */
    public int getData_source_id() {
        return data_source_id;
    }


    /**
     * Sets the data_source_id value for this Tier_member_rec.
     * 
     * @param data_source_id
     */
    public void setData_source_id(int data_source_id) {
        this.data_source_id = data_source_id;
    }


    /**
     * Gets the tier_id value for this Tier_member_rec.
     * 
     * @return tier_id
     */
    public int getTier_id() {
        return tier_id;
    }


    /**
     * Sets the tier_id value for this Tier_member_rec.
     * 
     * @param tier_id
     */
    public void setTier_id(int tier_id) {
        this.tier_id = tier_id;
    }


    /**
     * Gets the range_min value for this Tier_member_rec.
     * 
     * @return range_min
     */
    public java.math.BigInteger getRange_min() {
        return range_min;
    }


    /**
     * Sets the range_min value for this Tier_member_rec.
     * 
     * @param range_min
     */
    public void setRange_min(java.math.BigInteger range_min) {
        this.range_min = range_min;
    }


    /**
     * Gets the range_max value for this Tier_member_rec.
     * 
     * @return range_max
     */
    public java.math.BigInteger getRange_max() {
        return range_max;
    }


    /**
     * Sets the range_max value for this Tier_member_rec.
     * 
     * @param range_max
     */
    public void setRange_max(java.math.BigInteger range_max) {
        this.range_max = range_max;
    }


    /**
     * Gets the base value for this Tier_member_rec.
     * 
     * @return base
     */
    public java.lang.String getBase() {
        return base;
    }


    /**
     * Sets the base value for this Tier_member_rec.
     * 
     * @param base
     */
    public void setBase(java.lang.String base) {
        this.base = base;
    }


    /**
     * Gets the factor value for this Tier_member_rec.
     * 
     * @return factor
     */
    public java.lang.String getFactor() {
        return factor;
    }


    /**
     * Sets the factor value for this Tier_member_rec.
     * 
     * @param factor
     */
    public void setFactor(java.lang.String factor) {
        this.factor = factor;
    }


    /**
     * Gets the product_id value for this Tier_member_rec.
     * 
     * @return product_id
     */
    public int getProduct_id() {
        return product_id;
    }


    /**
     * Sets the product_id value for this Tier_member_rec.
     * 
     * @param product_id
     */
    public void setProduct_id(int product_id) {
        this.product_id = product_id;
    }


    /**
     * Gets the description value for this Tier_member_rec.
     * 
     * @return description
     */
    public java.lang.String getDescription() {
        return description;
    }


    /**
     * Sets the description value for this Tier_member_rec.
     * 
     * @param description
     */
    public void setDescription(java.lang.String description) {
        this.description = description;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Tier_member_rec)) return false;
        Tier_member_rec other = (Tier_member_rec) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            this.tier_member_id == other.getTier_member_id() &&
            ((this.import_id==null && other.getImport_id()==null) || 
             (this.import_id!=null &&
              this.import_id.equals(other.getImport_id()))) &&
            this.data_source_id == other.getData_source_id() &&
            this.tier_id == other.getTier_id() &&
            ((this.range_min==null && other.getRange_min()==null) || 
             (this.range_min!=null &&
              this.range_min.equals(other.getRange_min()))) &&
            ((this.range_max==null && other.getRange_max()==null) || 
             (this.range_max!=null &&
              this.range_max.equals(other.getRange_max()))) &&
            ((this.base==null && other.getBase()==null) || 
             (this.base!=null &&
              this.base.equals(other.getBase()))) &&
            ((this.factor==null && other.getFactor()==null) || 
             (this.factor!=null &&
              this.factor.equals(other.getFactor()))) &&
            this.product_id == other.getProduct_id() &&
            ((this.description==null && other.getDescription()==null) || 
             (this.description!=null &&
              this.description.equals(other.getDescription())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        _hashCode += getTier_member_id();
        if (getImport_id() != null) {
            _hashCode += getImport_id().hashCode();
        }
        _hashCode += getData_source_id();
        _hashCode += getTier_id();
        if (getRange_min() != null) {
            _hashCode += getRange_min().hashCode();
        }
        if (getRange_max() != null) {
            _hashCode += getRange_max().hashCode();
        }
        if (getBase() != null) {
            _hashCode += getBase().hashCode();
        }
        if (getFactor() != null) {
            _hashCode += getFactor().hashCode();
        }
        _hashCode += getProduct_id();
        if (getDescription() != null) {
            _hashCode += getDescription().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Tier_member_rec.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://aspera.com/wsdl/", "tier_member_rec"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("tier_member_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "tier_member_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("import_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "import_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("data_source_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "data_source_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("tier_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "tier_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("range_min");
        elemField.setXmlName(new javax.xml.namespace.QName("", "range_min"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("range_max");
        elemField.setXmlName(new javax.xml.namespace.QName("", "range_max"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("base");
        elemField.setXmlName(new javax.xml.namespace.QName("", "base"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("factor");
        elemField.setXmlName(new javax.xml.namespace.QName("", "factor"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("product_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "product_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("description");
        elemField.setXmlName(new javax.xml.namespace.QName("", "description"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}

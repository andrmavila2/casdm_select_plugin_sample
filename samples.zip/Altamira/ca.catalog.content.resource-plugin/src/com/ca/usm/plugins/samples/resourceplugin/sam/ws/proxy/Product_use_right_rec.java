/**
 * Product_use_right_rec.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ca.usm.plugins.samples.resourceplugin.sam.ws.proxy;

public class Product_use_right_rec  implements java.io.Serializable {
    private int product_use_right_id;

    private java.lang.String import_id;

    private int data_source_id;

    private int product_id;

    private int article_id;

    private java.math.BigInteger quantity;

    private boolean maint_contract;

    private java.math.BigInteger maintenance;

    private boolean maint_notice;

    private java.math.BigInteger maint_notice_days;

    private boolean auto_renewal;

    private java.math.BigInteger cancellation_period;

    private boolean canc_notice;

    private java.math.BigInteger canc_notice_days;

    private java.math.BigInteger expires_after;

    private boolean expiration_notice;

    private java.math.BigInteger expiration_notice_days;

    private boolean exp_contract;

    private boolean is_update;

    private boolean is_maintenance;

    private boolean ur_unlimited;

    private boolean ur_contract_scope;

    private boolean ur_contract_scope_lim;

    private boolean downgrade;

    private java.lang.String remarks;

    public Product_use_right_rec() {
    }

    public Product_use_right_rec(
           int product_use_right_id,
           java.lang.String import_id,
           int data_source_id,
           int product_id,
           int article_id,
           java.math.BigInteger quantity,
           boolean maint_contract,
           java.math.BigInteger maintenance,
           boolean maint_notice,
           java.math.BigInteger maint_notice_days,
           boolean auto_renewal,
           java.math.BigInteger cancellation_period,
           boolean canc_notice,
           java.math.BigInteger canc_notice_days,
           java.math.BigInteger expires_after,
           boolean expiration_notice,
           java.math.BigInteger expiration_notice_days,
           boolean exp_contract,
           boolean is_update,
           boolean is_maintenance,
           boolean ur_unlimited,
           boolean ur_contract_scope,
           boolean ur_contract_scope_lim,
           boolean downgrade,
           java.lang.String remarks) {
           this.product_use_right_id = product_use_right_id;
           this.import_id = import_id;
           this.data_source_id = data_source_id;
           this.product_id = product_id;
           this.article_id = article_id;
           this.quantity = quantity;
           this.maint_contract = maint_contract;
           this.maintenance = maintenance;
           this.maint_notice = maint_notice;
           this.maint_notice_days = maint_notice_days;
           this.auto_renewal = auto_renewal;
           this.cancellation_period = cancellation_period;
           this.canc_notice = canc_notice;
           this.canc_notice_days = canc_notice_days;
           this.expires_after = expires_after;
           this.expiration_notice = expiration_notice;
           this.expiration_notice_days = expiration_notice_days;
           this.exp_contract = exp_contract;
           this.is_update = is_update;
           this.is_maintenance = is_maintenance;
           this.ur_unlimited = ur_unlimited;
           this.ur_contract_scope = ur_contract_scope;
           this.ur_contract_scope_lim = ur_contract_scope_lim;
           this.downgrade = downgrade;
           this.remarks = remarks;
    }


    /**
     * Gets the product_use_right_id value for this Product_use_right_rec.
     * 
     * @return product_use_right_id
     */
    public int getProduct_use_right_id() {
        return product_use_right_id;
    }


    /**
     * Sets the product_use_right_id value for this Product_use_right_rec.
     * 
     * @param product_use_right_id
     */
    public void setProduct_use_right_id(int product_use_right_id) {
        this.product_use_right_id = product_use_right_id;
    }


    /**
     * Gets the import_id value for this Product_use_right_rec.
     * 
     * @return import_id
     */
    public java.lang.String getImport_id() {
        return import_id;
    }


    /**
     * Sets the import_id value for this Product_use_right_rec.
     * 
     * @param import_id
     */
    public void setImport_id(java.lang.String import_id) {
        this.import_id = import_id;
    }


    /**
     * Gets the data_source_id value for this Product_use_right_rec.
     * 
     * @return data_source_id
     */
    public int getData_source_id() {
        return data_source_id;
    }


    /**
     * Sets the data_source_id value for this Product_use_right_rec.
     * 
     * @param data_source_id
     */
    public void setData_source_id(int data_source_id) {
        this.data_source_id = data_source_id;
    }


    /**
     * Gets the product_id value for this Product_use_right_rec.
     * 
     * @return product_id
     */
    public int getProduct_id() {
        return product_id;
    }


    /**
     * Sets the product_id value for this Product_use_right_rec.
     * 
     * @param product_id
     */
    public void setProduct_id(int product_id) {
        this.product_id = product_id;
    }


    /**
     * Gets the article_id value for this Product_use_right_rec.
     * 
     * @return article_id
     */
    public int getArticle_id() {
        return article_id;
    }


    /**
     * Sets the article_id value for this Product_use_right_rec.
     * 
     * @param article_id
     */
    public void setArticle_id(int article_id) {
        this.article_id = article_id;
    }


    /**
     * Gets the quantity value for this Product_use_right_rec.
     * 
     * @return quantity
     */
    public java.math.BigInteger getQuantity() {
        return quantity;
    }


    /**
     * Sets the quantity value for this Product_use_right_rec.
     * 
     * @param quantity
     */
    public void setQuantity(java.math.BigInteger quantity) {
        this.quantity = quantity;
    }


    /**
     * Gets the maint_contract value for this Product_use_right_rec.
     * 
     * @return maint_contract
     */
    public boolean isMaint_contract() {
        return maint_contract;
    }


    /**
     * Sets the maint_contract value for this Product_use_right_rec.
     * 
     * @param maint_contract
     */
    public void setMaint_contract(boolean maint_contract) {
        this.maint_contract = maint_contract;
    }


    /**
     * Gets the maintenance value for this Product_use_right_rec.
     * 
     * @return maintenance
     */
    public java.math.BigInteger getMaintenance() {
        return maintenance;
    }


    /**
     * Sets the maintenance value for this Product_use_right_rec.
     * 
     * @param maintenance
     */
    public void setMaintenance(java.math.BigInteger maintenance) {
        this.maintenance = maintenance;
    }


    /**
     * Gets the maint_notice value for this Product_use_right_rec.
     * 
     * @return maint_notice
     */
    public boolean isMaint_notice() {
        return maint_notice;
    }


    /**
     * Sets the maint_notice value for this Product_use_right_rec.
     * 
     * @param maint_notice
     */
    public void setMaint_notice(boolean maint_notice) {
        this.maint_notice = maint_notice;
    }


    /**
     * Gets the maint_notice_days value for this Product_use_right_rec.
     * 
     * @return maint_notice_days
     */
    public java.math.BigInteger getMaint_notice_days() {
        return maint_notice_days;
    }


    /**
     * Sets the maint_notice_days value for this Product_use_right_rec.
     * 
     * @param maint_notice_days
     */
    public void setMaint_notice_days(java.math.BigInteger maint_notice_days) {
        this.maint_notice_days = maint_notice_days;
    }


    /**
     * Gets the auto_renewal value for this Product_use_right_rec.
     * 
     * @return auto_renewal
     */
    public boolean isAuto_renewal() {
        return auto_renewal;
    }


    /**
     * Sets the auto_renewal value for this Product_use_right_rec.
     * 
     * @param auto_renewal
     */
    public void setAuto_renewal(boolean auto_renewal) {
        this.auto_renewal = auto_renewal;
    }


    /**
     * Gets the cancellation_period value for this Product_use_right_rec.
     * 
     * @return cancellation_period
     */
    public java.math.BigInteger getCancellation_period() {
        return cancellation_period;
    }


    /**
     * Sets the cancellation_period value for this Product_use_right_rec.
     * 
     * @param cancellation_period
     */
    public void setCancellation_period(java.math.BigInteger cancellation_period) {
        this.cancellation_period = cancellation_period;
    }


    /**
     * Gets the canc_notice value for this Product_use_right_rec.
     * 
     * @return canc_notice
     */
    public boolean isCanc_notice() {
        return canc_notice;
    }


    /**
     * Sets the canc_notice value for this Product_use_right_rec.
     * 
     * @param canc_notice
     */
    public void setCanc_notice(boolean canc_notice) {
        this.canc_notice = canc_notice;
    }


    /**
     * Gets the canc_notice_days value for this Product_use_right_rec.
     * 
     * @return canc_notice_days
     */
    public java.math.BigInteger getCanc_notice_days() {
        return canc_notice_days;
    }


    /**
     * Sets the canc_notice_days value for this Product_use_right_rec.
     * 
     * @param canc_notice_days
     */
    public void setCanc_notice_days(java.math.BigInteger canc_notice_days) {
        this.canc_notice_days = canc_notice_days;
    }


    /**
     * Gets the expires_after value for this Product_use_right_rec.
     * 
     * @return expires_after
     */
    public java.math.BigInteger getExpires_after() {
        return expires_after;
    }


    /**
     * Sets the expires_after value for this Product_use_right_rec.
     * 
     * @param expires_after
     */
    public void setExpires_after(java.math.BigInteger expires_after) {
        this.expires_after = expires_after;
    }


    /**
     * Gets the expiration_notice value for this Product_use_right_rec.
     * 
     * @return expiration_notice
     */
    public boolean isExpiration_notice() {
        return expiration_notice;
    }


    /**
     * Sets the expiration_notice value for this Product_use_right_rec.
     * 
     * @param expiration_notice
     */
    public void setExpiration_notice(boolean expiration_notice) {
        this.expiration_notice = expiration_notice;
    }


    /**
     * Gets the expiration_notice_days value for this Product_use_right_rec.
     * 
     * @return expiration_notice_days
     */
    public java.math.BigInteger getExpiration_notice_days() {
        return expiration_notice_days;
    }


    /**
     * Sets the expiration_notice_days value for this Product_use_right_rec.
     * 
     * @param expiration_notice_days
     */
    public void setExpiration_notice_days(java.math.BigInteger expiration_notice_days) {
        this.expiration_notice_days = expiration_notice_days;
    }


    /**
     * Gets the exp_contract value for this Product_use_right_rec.
     * 
     * @return exp_contract
     */
    public boolean isExp_contract() {
        return exp_contract;
    }


    /**
     * Sets the exp_contract value for this Product_use_right_rec.
     * 
     * @param exp_contract
     */
    public void setExp_contract(boolean exp_contract) {
        this.exp_contract = exp_contract;
    }


    /**
     * Gets the is_update value for this Product_use_right_rec.
     * 
     * @return is_update
     */
    public boolean isIs_update() {
        return is_update;
    }


    /**
     * Sets the is_update value for this Product_use_right_rec.
     * 
     * @param is_update
     */
    public void setIs_update(boolean is_update) {
        this.is_update = is_update;
    }


    /**
     * Gets the is_maintenance value for this Product_use_right_rec.
     * 
     * @return is_maintenance
     */
    public boolean isIs_maintenance() {
        return is_maintenance;
    }


    /**
     * Sets the is_maintenance value for this Product_use_right_rec.
     * 
     * @param is_maintenance
     */
    public void setIs_maintenance(boolean is_maintenance) {
        this.is_maintenance = is_maintenance;
    }


    /**
     * Gets the ur_unlimited value for this Product_use_right_rec.
     * 
     * @return ur_unlimited
     */
    public boolean isUr_unlimited() {
        return ur_unlimited;
    }


    /**
     * Sets the ur_unlimited value for this Product_use_right_rec.
     * 
     * @param ur_unlimited
     */
    public void setUr_unlimited(boolean ur_unlimited) {
        this.ur_unlimited = ur_unlimited;
    }


    /**
     * Gets the ur_contract_scope value for this Product_use_right_rec.
     * 
     * @return ur_contract_scope
     */
    public boolean isUr_contract_scope() {
        return ur_contract_scope;
    }


    /**
     * Sets the ur_contract_scope value for this Product_use_right_rec.
     * 
     * @param ur_contract_scope
     */
    public void setUr_contract_scope(boolean ur_contract_scope) {
        this.ur_contract_scope = ur_contract_scope;
    }


    /**
     * Gets the ur_contract_scope_lim value for this Product_use_right_rec.
     * 
     * @return ur_contract_scope_lim
     */
    public boolean isUr_contract_scope_lim() {
        return ur_contract_scope_lim;
    }


    /**
     * Sets the ur_contract_scope_lim value for this Product_use_right_rec.
     * 
     * @param ur_contract_scope_lim
     */
    public void setUr_contract_scope_lim(boolean ur_contract_scope_lim) {
        this.ur_contract_scope_lim = ur_contract_scope_lim;
    }


    /**
     * Gets the downgrade value for this Product_use_right_rec.
     * 
     * @return downgrade
     */
    public boolean isDowngrade() {
        return downgrade;
    }


    /**
     * Sets the downgrade value for this Product_use_right_rec.
     * 
     * @param downgrade
     */
    public void setDowngrade(boolean downgrade) {
        this.downgrade = downgrade;
    }


    /**
     * Gets the remarks value for this Product_use_right_rec.
     * 
     * @return remarks
     */
    public java.lang.String getRemarks() {
        return remarks;
    }


    /**
     * Sets the remarks value for this Product_use_right_rec.
     * 
     * @param remarks
     */
    public void setRemarks(java.lang.String remarks) {
        this.remarks = remarks;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Product_use_right_rec)) return false;
        Product_use_right_rec other = (Product_use_right_rec) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            this.product_use_right_id == other.getProduct_use_right_id() &&
            ((this.import_id==null && other.getImport_id()==null) || 
             (this.import_id!=null &&
              this.import_id.equals(other.getImport_id()))) &&
            this.data_source_id == other.getData_source_id() &&
            this.product_id == other.getProduct_id() &&
            this.article_id == other.getArticle_id() &&
            ((this.quantity==null && other.getQuantity()==null) || 
             (this.quantity!=null &&
              this.quantity.equals(other.getQuantity()))) &&
            this.maint_contract == other.isMaint_contract() &&
            ((this.maintenance==null && other.getMaintenance()==null) || 
             (this.maintenance!=null &&
              this.maintenance.equals(other.getMaintenance()))) &&
            this.maint_notice == other.isMaint_notice() &&
            ((this.maint_notice_days==null && other.getMaint_notice_days()==null) || 
             (this.maint_notice_days!=null &&
              this.maint_notice_days.equals(other.getMaint_notice_days()))) &&
            this.auto_renewal == other.isAuto_renewal() &&
            ((this.cancellation_period==null && other.getCancellation_period()==null) || 
             (this.cancellation_period!=null &&
              this.cancellation_period.equals(other.getCancellation_period()))) &&
            this.canc_notice == other.isCanc_notice() &&
            ((this.canc_notice_days==null && other.getCanc_notice_days()==null) || 
             (this.canc_notice_days!=null &&
              this.canc_notice_days.equals(other.getCanc_notice_days()))) &&
            ((this.expires_after==null && other.getExpires_after()==null) || 
             (this.expires_after!=null &&
              this.expires_after.equals(other.getExpires_after()))) &&
            this.expiration_notice == other.isExpiration_notice() &&
            ((this.expiration_notice_days==null && other.getExpiration_notice_days()==null) || 
             (this.expiration_notice_days!=null &&
              this.expiration_notice_days.equals(other.getExpiration_notice_days()))) &&
            this.exp_contract == other.isExp_contract() &&
            this.is_update == other.isIs_update() &&
            this.is_maintenance == other.isIs_maintenance() &&
            this.ur_unlimited == other.isUr_unlimited() &&
            this.ur_contract_scope == other.isUr_contract_scope() &&
            this.ur_contract_scope_lim == other.isUr_contract_scope_lim() &&
            this.downgrade == other.isDowngrade() &&
            ((this.remarks==null && other.getRemarks()==null) || 
             (this.remarks!=null &&
              this.remarks.equals(other.getRemarks())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        _hashCode += getProduct_use_right_id();
        if (getImport_id() != null) {
            _hashCode += getImport_id().hashCode();
        }
        _hashCode += getData_source_id();
        _hashCode += getProduct_id();
        _hashCode += getArticle_id();
        if (getQuantity() != null) {
            _hashCode += getQuantity().hashCode();
        }
        _hashCode += (isMaint_contract() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        if (getMaintenance() != null) {
            _hashCode += getMaintenance().hashCode();
        }
        _hashCode += (isMaint_notice() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        if (getMaint_notice_days() != null) {
            _hashCode += getMaint_notice_days().hashCode();
        }
        _hashCode += (isAuto_renewal() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        if (getCancellation_period() != null) {
            _hashCode += getCancellation_period().hashCode();
        }
        _hashCode += (isCanc_notice() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        if (getCanc_notice_days() != null) {
            _hashCode += getCanc_notice_days().hashCode();
        }
        if (getExpires_after() != null) {
            _hashCode += getExpires_after().hashCode();
        }
        _hashCode += (isExpiration_notice() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        if (getExpiration_notice_days() != null) {
            _hashCode += getExpiration_notice_days().hashCode();
        }
        _hashCode += (isExp_contract() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        _hashCode += (isIs_update() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        _hashCode += (isIs_maintenance() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        _hashCode += (isUr_unlimited() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        _hashCode += (isUr_contract_scope() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        _hashCode += (isUr_contract_scope_lim() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        _hashCode += (isDowngrade() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        if (getRemarks() != null) {
            _hashCode += getRemarks().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Product_use_right_rec.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://aspera.com/wsdl/", "product_use_right_rec"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("product_use_right_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "product_use_right_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("import_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "import_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("data_source_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "data_source_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("product_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "product_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("article_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "article_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("quantity");
        elemField.setXmlName(new javax.xml.namespace.QName("", "quantity"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("maint_contract");
        elemField.setXmlName(new javax.xml.namespace.QName("", "maint_contract"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("maintenance");
        elemField.setXmlName(new javax.xml.namespace.QName("", "maintenance"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("maint_notice");
        elemField.setXmlName(new javax.xml.namespace.QName("", "maint_notice"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("maint_notice_days");
        elemField.setXmlName(new javax.xml.namespace.QName("", "maint_notice_days"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("auto_renewal");
        elemField.setXmlName(new javax.xml.namespace.QName("", "auto_renewal"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("cancellation_period");
        elemField.setXmlName(new javax.xml.namespace.QName("", "cancellation_period"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("canc_notice");
        elemField.setXmlName(new javax.xml.namespace.QName("", "canc_notice"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("canc_notice_days");
        elemField.setXmlName(new javax.xml.namespace.QName("", "canc_notice_days"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("expires_after");
        elemField.setXmlName(new javax.xml.namespace.QName("", "expires_after"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("expiration_notice");
        elemField.setXmlName(new javax.xml.namespace.QName("", "expiration_notice"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("expiration_notice_days");
        elemField.setXmlName(new javax.xml.namespace.QName("", "expiration_notice_days"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("exp_contract");
        elemField.setXmlName(new javax.xml.namespace.QName("", "exp_contract"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("is_update");
        elemField.setXmlName(new javax.xml.namespace.QName("", "is_update"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("is_maintenance");
        elemField.setXmlName(new javax.xml.namespace.QName("", "is_maintenance"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ur_unlimited");
        elemField.setXmlName(new javax.xml.namespace.QName("", "ur_unlimited"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ur_contract_scope");
        elemField.setXmlName(new javax.xml.namespace.QName("", "ur_contract_scope"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ur_contract_scope_lim");
        elemField.setXmlName(new javax.xml.namespace.QName("", "ur_contract_scope_lim"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("downgrade");
        elemField.setXmlName(new javax.xml.namespace.QName("", "downgrade"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("remarks");
        elemField.setXmlName(new javax.xml.namespace.QName("", "remarks"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}

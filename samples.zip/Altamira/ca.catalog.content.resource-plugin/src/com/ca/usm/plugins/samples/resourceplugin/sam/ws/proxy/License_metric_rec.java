/**
 * License_metric_rec.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ca.usm.plugins.samples.resourceplugin.sam.ws.proxy;

public class License_metric_rec  implements java.io.Serializable {
    private int license_metric_id;

    private java.lang.String import_id;

    private int data_source_id;

    private java.lang.String description;

    private java.lang.String remarks;

    private java.lang.String ref;

    private java.lang.String metric_engine;

    private java.lang.String engine_param_0;

    private java.lang.String engine_param_1;

    private java.lang.String engine_param_2;

    private java.lang.String engine_param_3;

    private java.lang.String engine_param_4;

    private int tier_id;

    public License_metric_rec() {
    }

    public License_metric_rec(
           int license_metric_id,
           java.lang.String import_id,
           int data_source_id,
           java.lang.String description,
           java.lang.String remarks,
           java.lang.String ref,
           java.lang.String metric_engine,
           java.lang.String engine_param_0,
           java.lang.String engine_param_1,
           java.lang.String engine_param_2,
           java.lang.String engine_param_3,
           java.lang.String engine_param_4,
           int tier_id) {
           this.license_metric_id = license_metric_id;
           this.import_id = import_id;
           this.data_source_id = data_source_id;
           this.description = description;
           this.remarks = remarks;
           this.ref = ref;
           this.metric_engine = metric_engine;
           this.engine_param_0 = engine_param_0;
           this.engine_param_1 = engine_param_1;
           this.engine_param_2 = engine_param_2;
           this.engine_param_3 = engine_param_3;
           this.engine_param_4 = engine_param_4;
           this.tier_id = tier_id;
    }


    /**
     * Gets the license_metric_id value for this License_metric_rec.
     * 
     * @return license_metric_id
     */
    public int getLicense_metric_id() {
        return license_metric_id;
    }


    /**
     * Sets the license_metric_id value for this License_metric_rec.
     * 
     * @param license_metric_id
     */
    public void setLicense_metric_id(int license_metric_id) {
        this.license_metric_id = license_metric_id;
    }


    /**
     * Gets the import_id value for this License_metric_rec.
     * 
     * @return import_id
     */
    public java.lang.String getImport_id() {
        return import_id;
    }


    /**
     * Sets the import_id value for this License_metric_rec.
     * 
     * @param import_id
     */
    public void setImport_id(java.lang.String import_id) {
        this.import_id = import_id;
    }


    /**
     * Gets the data_source_id value for this License_metric_rec.
     * 
     * @return data_source_id
     */
    public int getData_source_id() {
        return data_source_id;
    }


    /**
     * Sets the data_source_id value for this License_metric_rec.
     * 
     * @param data_source_id
     */
    public void setData_source_id(int data_source_id) {
        this.data_source_id = data_source_id;
    }


    /**
     * Gets the description value for this License_metric_rec.
     * 
     * @return description
     */
    public java.lang.String getDescription() {
        return description;
    }


    /**
     * Sets the description value for this License_metric_rec.
     * 
     * @param description
     */
    public void setDescription(java.lang.String description) {
        this.description = description;
    }


    /**
     * Gets the remarks value for this License_metric_rec.
     * 
     * @return remarks
     */
    public java.lang.String getRemarks() {
        return remarks;
    }


    /**
     * Sets the remarks value for this License_metric_rec.
     * 
     * @param remarks
     */
    public void setRemarks(java.lang.String remarks) {
        this.remarks = remarks;
    }


    /**
     * Gets the ref value for this License_metric_rec.
     * 
     * @return ref
     */
    public java.lang.String getRef() {
        return ref;
    }


    /**
     * Sets the ref value for this License_metric_rec.
     * 
     * @param ref
     */
    public void setRef(java.lang.String ref) {
        this.ref = ref;
    }


    /**
     * Gets the metric_engine value for this License_metric_rec.
     * 
     * @return metric_engine
     */
    public java.lang.String getMetric_engine() {
        return metric_engine;
    }


    /**
     * Sets the metric_engine value for this License_metric_rec.
     * 
     * @param metric_engine
     */
    public void setMetric_engine(java.lang.String metric_engine) {
        this.metric_engine = metric_engine;
    }


    /**
     * Gets the engine_param_0 value for this License_metric_rec.
     * 
     * @return engine_param_0
     */
    public java.lang.String getEngine_param_0() {
        return engine_param_0;
    }


    /**
     * Sets the engine_param_0 value for this License_metric_rec.
     * 
     * @param engine_param_0
     */
    public void setEngine_param_0(java.lang.String engine_param_0) {
        this.engine_param_0 = engine_param_0;
    }


    /**
     * Gets the engine_param_1 value for this License_metric_rec.
     * 
     * @return engine_param_1
     */
    public java.lang.String getEngine_param_1() {
        return engine_param_1;
    }


    /**
     * Sets the engine_param_1 value for this License_metric_rec.
     * 
     * @param engine_param_1
     */
    public void setEngine_param_1(java.lang.String engine_param_1) {
        this.engine_param_1 = engine_param_1;
    }


    /**
     * Gets the engine_param_2 value for this License_metric_rec.
     * 
     * @return engine_param_2
     */
    public java.lang.String getEngine_param_2() {
        return engine_param_2;
    }


    /**
     * Sets the engine_param_2 value for this License_metric_rec.
     * 
     * @param engine_param_2
     */
    public void setEngine_param_2(java.lang.String engine_param_2) {
        this.engine_param_2 = engine_param_2;
    }


    /**
     * Gets the engine_param_3 value for this License_metric_rec.
     * 
     * @return engine_param_3
     */
    public java.lang.String getEngine_param_3() {
        return engine_param_3;
    }


    /**
     * Sets the engine_param_3 value for this License_metric_rec.
     * 
     * @param engine_param_3
     */
    public void setEngine_param_3(java.lang.String engine_param_3) {
        this.engine_param_3 = engine_param_3;
    }


    /**
     * Gets the engine_param_4 value for this License_metric_rec.
     * 
     * @return engine_param_4
     */
    public java.lang.String getEngine_param_4() {
        return engine_param_4;
    }


    /**
     * Sets the engine_param_4 value for this License_metric_rec.
     * 
     * @param engine_param_4
     */
    public void setEngine_param_4(java.lang.String engine_param_4) {
        this.engine_param_4 = engine_param_4;
    }


    /**
     * Gets the tier_id value for this License_metric_rec.
     * 
     * @return tier_id
     */
    public int getTier_id() {
        return tier_id;
    }


    /**
     * Sets the tier_id value for this License_metric_rec.
     * 
     * @param tier_id
     */
    public void setTier_id(int tier_id) {
        this.tier_id = tier_id;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof License_metric_rec)) return false;
        License_metric_rec other = (License_metric_rec) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            this.license_metric_id == other.getLicense_metric_id() &&
            ((this.import_id==null && other.getImport_id()==null) || 
             (this.import_id!=null &&
              this.import_id.equals(other.getImport_id()))) &&
            this.data_source_id == other.getData_source_id() &&
            ((this.description==null && other.getDescription()==null) || 
             (this.description!=null &&
              this.description.equals(other.getDescription()))) &&
            ((this.remarks==null && other.getRemarks()==null) || 
             (this.remarks!=null &&
              this.remarks.equals(other.getRemarks()))) &&
            ((this.ref==null && other.getRef()==null) || 
             (this.ref!=null &&
              this.ref.equals(other.getRef()))) &&
            ((this.metric_engine==null && other.getMetric_engine()==null) || 
             (this.metric_engine!=null &&
              this.metric_engine.equals(other.getMetric_engine()))) &&
            ((this.engine_param_0==null && other.getEngine_param_0()==null) || 
             (this.engine_param_0!=null &&
              this.engine_param_0.equals(other.getEngine_param_0()))) &&
            ((this.engine_param_1==null && other.getEngine_param_1()==null) || 
             (this.engine_param_1!=null &&
              this.engine_param_1.equals(other.getEngine_param_1()))) &&
            ((this.engine_param_2==null && other.getEngine_param_2()==null) || 
             (this.engine_param_2!=null &&
              this.engine_param_2.equals(other.getEngine_param_2()))) &&
            ((this.engine_param_3==null && other.getEngine_param_3()==null) || 
             (this.engine_param_3!=null &&
              this.engine_param_3.equals(other.getEngine_param_3()))) &&
            ((this.engine_param_4==null && other.getEngine_param_4()==null) || 
             (this.engine_param_4!=null &&
              this.engine_param_4.equals(other.getEngine_param_4()))) &&
            this.tier_id == other.getTier_id();
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        _hashCode += getLicense_metric_id();
        if (getImport_id() != null) {
            _hashCode += getImport_id().hashCode();
        }
        _hashCode += getData_source_id();
        if (getDescription() != null) {
            _hashCode += getDescription().hashCode();
        }
        if (getRemarks() != null) {
            _hashCode += getRemarks().hashCode();
        }
        if (getRef() != null) {
            _hashCode += getRef().hashCode();
        }
        if (getMetric_engine() != null) {
            _hashCode += getMetric_engine().hashCode();
        }
        if (getEngine_param_0() != null) {
            _hashCode += getEngine_param_0().hashCode();
        }
        if (getEngine_param_1() != null) {
            _hashCode += getEngine_param_1().hashCode();
        }
        if (getEngine_param_2() != null) {
            _hashCode += getEngine_param_2().hashCode();
        }
        if (getEngine_param_3() != null) {
            _hashCode += getEngine_param_3().hashCode();
        }
        if (getEngine_param_4() != null) {
            _hashCode += getEngine_param_4().hashCode();
        }
        _hashCode += getTier_id();
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(License_metric_rec.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://aspera.com/wsdl/", "license_metric_rec"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("license_metric_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "license_metric_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("import_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "import_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("data_source_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "data_source_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("description");
        elemField.setXmlName(new javax.xml.namespace.QName("", "description"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("remarks");
        elemField.setXmlName(new javax.xml.namespace.QName("", "remarks"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ref");
        elemField.setXmlName(new javax.xml.namespace.QName("", "ref"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("metric_engine");
        elemField.setXmlName(new javax.xml.namespace.QName("", "metric_engine"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("engine_param_0");
        elemField.setXmlName(new javax.xml.namespace.QName("", "engine_param_0"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("engine_param_1");
        elemField.setXmlName(new javax.xml.namespace.QName("", "engine_param_1"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("engine_param_2");
        elemField.setXmlName(new javax.xml.namespace.QName("", "engine_param_2"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("engine_param_3");
        elemField.setXmlName(new javax.xml.namespace.QName("", "engine_param_3"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("engine_param_4");
        elemField.setXmlName(new javax.xml.namespace.QName("", "engine_param_4"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("tier_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "tier_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}

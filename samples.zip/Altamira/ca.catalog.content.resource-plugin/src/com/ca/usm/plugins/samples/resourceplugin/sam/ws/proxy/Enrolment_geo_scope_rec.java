/**
 * Enrolment_geo_scope_rec.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ca.usm.plugins.samples.resourceplugin.sam.ws.proxy;

public class Enrolment_geo_scope_rec  implements java.io.Serializable {
    private int enrolment_geo_scope_id;

    private java.lang.String import_id;

    private int data_source_id;

    private int enrolment_id;

    private int region_id;

    private int country_id;

    private int location_id;

    public Enrolment_geo_scope_rec() {
    }

    public Enrolment_geo_scope_rec(
           int enrolment_geo_scope_id,
           java.lang.String import_id,
           int data_source_id,
           int enrolment_id,
           int region_id,
           int country_id,
           int location_id) {
           this.enrolment_geo_scope_id = enrolment_geo_scope_id;
           this.import_id = import_id;
           this.data_source_id = data_source_id;
           this.enrolment_id = enrolment_id;
           this.region_id = region_id;
           this.country_id = country_id;
           this.location_id = location_id;
    }


    /**
     * Gets the enrolment_geo_scope_id value for this Enrolment_geo_scope_rec.
     * 
     * @return enrolment_geo_scope_id
     */
    public int getEnrolment_geo_scope_id() {
        return enrolment_geo_scope_id;
    }


    /**
     * Sets the enrolment_geo_scope_id value for this Enrolment_geo_scope_rec.
     * 
     * @param enrolment_geo_scope_id
     */
    public void setEnrolment_geo_scope_id(int enrolment_geo_scope_id) {
        this.enrolment_geo_scope_id = enrolment_geo_scope_id;
    }


    /**
     * Gets the import_id value for this Enrolment_geo_scope_rec.
     * 
     * @return import_id
     */
    public java.lang.String getImport_id() {
        return import_id;
    }


    /**
     * Sets the import_id value for this Enrolment_geo_scope_rec.
     * 
     * @param import_id
     */
    public void setImport_id(java.lang.String import_id) {
        this.import_id = import_id;
    }


    /**
     * Gets the data_source_id value for this Enrolment_geo_scope_rec.
     * 
     * @return data_source_id
     */
    public int getData_source_id() {
        return data_source_id;
    }


    /**
     * Sets the data_source_id value for this Enrolment_geo_scope_rec.
     * 
     * @param data_source_id
     */
    public void setData_source_id(int data_source_id) {
        this.data_source_id = data_source_id;
    }


    /**
     * Gets the enrolment_id value for this Enrolment_geo_scope_rec.
     * 
     * @return enrolment_id
     */
    public int getEnrolment_id() {
        return enrolment_id;
    }


    /**
     * Sets the enrolment_id value for this Enrolment_geo_scope_rec.
     * 
     * @param enrolment_id
     */
    public void setEnrolment_id(int enrolment_id) {
        this.enrolment_id = enrolment_id;
    }


    /**
     * Gets the region_id value for this Enrolment_geo_scope_rec.
     * 
     * @return region_id
     */
    public int getRegion_id() {
        return region_id;
    }


    /**
     * Sets the region_id value for this Enrolment_geo_scope_rec.
     * 
     * @param region_id
     */
    public void setRegion_id(int region_id) {
        this.region_id = region_id;
    }


    /**
     * Gets the country_id value for this Enrolment_geo_scope_rec.
     * 
     * @return country_id
     */
    public int getCountry_id() {
        return country_id;
    }


    /**
     * Sets the country_id value for this Enrolment_geo_scope_rec.
     * 
     * @param country_id
     */
    public void setCountry_id(int country_id) {
        this.country_id = country_id;
    }


    /**
     * Gets the location_id value for this Enrolment_geo_scope_rec.
     * 
     * @return location_id
     */
    public int getLocation_id() {
        return location_id;
    }


    /**
     * Sets the location_id value for this Enrolment_geo_scope_rec.
     * 
     * @param location_id
     */
    public void setLocation_id(int location_id) {
        this.location_id = location_id;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Enrolment_geo_scope_rec)) return false;
        Enrolment_geo_scope_rec other = (Enrolment_geo_scope_rec) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            this.enrolment_geo_scope_id == other.getEnrolment_geo_scope_id() &&
            ((this.import_id==null && other.getImport_id()==null) || 
             (this.import_id!=null &&
              this.import_id.equals(other.getImport_id()))) &&
            this.data_source_id == other.getData_source_id() &&
            this.enrolment_id == other.getEnrolment_id() &&
            this.region_id == other.getRegion_id() &&
            this.country_id == other.getCountry_id() &&
            this.location_id == other.getLocation_id();
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        _hashCode += getEnrolment_geo_scope_id();
        if (getImport_id() != null) {
            _hashCode += getImport_id().hashCode();
        }
        _hashCode += getData_source_id();
        _hashCode += getEnrolment_id();
        _hashCode += getRegion_id();
        _hashCode += getCountry_id();
        _hashCode += getLocation_id();
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Enrolment_geo_scope_rec.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://aspera.com/wsdl/", "enrolment_geo_scope_rec"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("enrolment_geo_scope_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "enrolment_geo_scope_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("import_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "import_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("data_source_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "data_source_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("enrolment_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "enrolment_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("region_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "region_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("country_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "country_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("location_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "location_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}

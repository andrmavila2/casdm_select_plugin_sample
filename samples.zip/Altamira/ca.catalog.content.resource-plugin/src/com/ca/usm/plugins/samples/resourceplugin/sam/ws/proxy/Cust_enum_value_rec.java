/**
 * Cust_enum_value_rec.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ca.usm.plugins.samples.resourceplugin.sam.ws.proxy;

public class Cust_enum_value_rec  implements java.io.Serializable {
    private int cust_enum_value_id;

    private java.lang.String import_id;

    private int data_source_id;

    private java.lang.String table_name;

    private java.lang.String cust_col_name;

    private java.lang.String enum_value;

    private java.lang.String enum_descr;

    public Cust_enum_value_rec() {
    }

    public Cust_enum_value_rec(
           int cust_enum_value_id,
           java.lang.String import_id,
           int data_source_id,
           java.lang.String table_name,
           java.lang.String cust_col_name,
           java.lang.String enum_value,
           java.lang.String enum_descr) {
           this.cust_enum_value_id = cust_enum_value_id;
           this.import_id = import_id;
           this.data_source_id = data_source_id;
           this.table_name = table_name;
           this.cust_col_name = cust_col_name;
           this.enum_value = enum_value;
           this.enum_descr = enum_descr;
    }


    /**
     * Gets the cust_enum_value_id value for this Cust_enum_value_rec.
     * 
     * @return cust_enum_value_id
     */
    public int getCust_enum_value_id() {
        return cust_enum_value_id;
    }


    /**
     * Sets the cust_enum_value_id value for this Cust_enum_value_rec.
     * 
     * @param cust_enum_value_id
     */
    public void setCust_enum_value_id(int cust_enum_value_id) {
        this.cust_enum_value_id = cust_enum_value_id;
    }


    /**
     * Gets the import_id value for this Cust_enum_value_rec.
     * 
     * @return import_id
     */
    public java.lang.String getImport_id() {
        return import_id;
    }


    /**
     * Sets the import_id value for this Cust_enum_value_rec.
     * 
     * @param import_id
     */
    public void setImport_id(java.lang.String import_id) {
        this.import_id = import_id;
    }


    /**
     * Gets the data_source_id value for this Cust_enum_value_rec.
     * 
     * @return data_source_id
     */
    public int getData_source_id() {
        return data_source_id;
    }


    /**
     * Sets the data_source_id value for this Cust_enum_value_rec.
     * 
     * @param data_source_id
     */
    public void setData_source_id(int data_source_id) {
        this.data_source_id = data_source_id;
    }


    /**
     * Gets the table_name value for this Cust_enum_value_rec.
     * 
     * @return table_name
     */
    public java.lang.String getTable_name() {
        return table_name;
    }


    /**
     * Sets the table_name value for this Cust_enum_value_rec.
     * 
     * @param table_name
     */
    public void setTable_name(java.lang.String table_name) {
        this.table_name = table_name;
    }


    /**
     * Gets the cust_col_name value for this Cust_enum_value_rec.
     * 
     * @return cust_col_name
     */
    public java.lang.String getCust_col_name() {
        return cust_col_name;
    }


    /**
     * Sets the cust_col_name value for this Cust_enum_value_rec.
     * 
     * @param cust_col_name
     */
    public void setCust_col_name(java.lang.String cust_col_name) {
        this.cust_col_name = cust_col_name;
    }


    /**
     * Gets the enum_value value for this Cust_enum_value_rec.
     * 
     * @return enum_value
     */
    public java.lang.String getEnum_value() {
        return enum_value;
    }


    /**
     * Sets the enum_value value for this Cust_enum_value_rec.
     * 
     * @param enum_value
     */
    public void setEnum_value(java.lang.String enum_value) {
        this.enum_value = enum_value;
    }


    /**
     * Gets the enum_descr value for this Cust_enum_value_rec.
     * 
     * @return enum_descr
     */
    public java.lang.String getEnum_descr() {
        return enum_descr;
    }


    /**
     * Sets the enum_descr value for this Cust_enum_value_rec.
     * 
     * @param enum_descr
     */
    public void setEnum_descr(java.lang.String enum_descr) {
        this.enum_descr = enum_descr;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Cust_enum_value_rec)) return false;
        Cust_enum_value_rec other = (Cust_enum_value_rec) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            this.cust_enum_value_id == other.getCust_enum_value_id() &&
            ((this.import_id==null && other.getImport_id()==null) || 
             (this.import_id!=null &&
              this.import_id.equals(other.getImport_id()))) &&
            this.data_source_id == other.getData_source_id() &&
            ((this.table_name==null && other.getTable_name()==null) || 
             (this.table_name!=null &&
              this.table_name.equals(other.getTable_name()))) &&
            ((this.cust_col_name==null && other.getCust_col_name()==null) || 
             (this.cust_col_name!=null &&
              this.cust_col_name.equals(other.getCust_col_name()))) &&
            ((this.enum_value==null && other.getEnum_value()==null) || 
             (this.enum_value!=null &&
              this.enum_value.equals(other.getEnum_value()))) &&
            ((this.enum_descr==null && other.getEnum_descr()==null) || 
             (this.enum_descr!=null &&
              this.enum_descr.equals(other.getEnum_descr())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        _hashCode += getCust_enum_value_id();
        if (getImport_id() != null) {
            _hashCode += getImport_id().hashCode();
        }
        _hashCode += getData_source_id();
        if (getTable_name() != null) {
            _hashCode += getTable_name().hashCode();
        }
        if (getCust_col_name() != null) {
            _hashCode += getCust_col_name().hashCode();
        }
        if (getEnum_value() != null) {
            _hashCode += getEnum_value().hashCode();
        }
        if (getEnum_descr() != null) {
            _hashCode += getEnum_descr().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Cust_enum_value_rec.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://aspera.com/wsdl/", "cust_enum_value_rec"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("cust_enum_value_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "cust_enum_value_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("import_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "import_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("data_source_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "data_source_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("table_name");
        elemField.setXmlName(new javax.xml.namespace.QName("", "table_name"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("cust_col_name");
        elemField.setXmlName(new javax.xml.namespace.QName("", "cust_col_name"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("enum_value");
        elemField.setXmlName(new javax.xml.namespace.QName("", "enum_value"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("enum_descr");
        elemField.setXmlName(new javax.xml.namespace.QName("", "enum_descr"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}

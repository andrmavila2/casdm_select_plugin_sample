/**
 * License_type_rec.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ca.usm.plugins.samples.resourceplugin.sam.ws.proxy;

public class License_type_rec  implements java.io.Serializable {
    private int license_type_id;

    private java.lang.String import_id;

    private int data_source_id;

    private java.lang.String description;

    private java.lang.String remarks;

    private boolean oem;

    public License_type_rec() {
    }

    public License_type_rec(
           int license_type_id,
           java.lang.String import_id,
           int data_source_id,
           java.lang.String description,
           java.lang.String remarks,
           boolean oem) {
           this.license_type_id = license_type_id;
           this.import_id = import_id;
           this.data_source_id = data_source_id;
           this.description = description;
           this.remarks = remarks;
           this.oem = oem;
    }


    /**
     * Gets the license_type_id value for this License_type_rec.
     * 
     * @return license_type_id
     */
    public int getLicense_type_id() {
        return license_type_id;
    }


    /**
     * Sets the license_type_id value for this License_type_rec.
     * 
     * @param license_type_id
     */
    public void setLicense_type_id(int license_type_id) {
        this.license_type_id = license_type_id;
    }


    /**
     * Gets the import_id value for this License_type_rec.
     * 
     * @return import_id
     */
    public java.lang.String getImport_id() {
        return import_id;
    }


    /**
     * Sets the import_id value for this License_type_rec.
     * 
     * @param import_id
     */
    public void setImport_id(java.lang.String import_id) {
        this.import_id = import_id;
    }


    /**
     * Gets the data_source_id value for this License_type_rec.
     * 
     * @return data_source_id
     */
    public int getData_source_id() {
        return data_source_id;
    }


    /**
     * Sets the data_source_id value for this License_type_rec.
     * 
     * @param data_source_id
     */
    public void setData_source_id(int data_source_id) {
        this.data_source_id = data_source_id;
    }


    /**
     * Gets the description value for this License_type_rec.
     * 
     * @return description
     */
    public java.lang.String getDescription() {
        return description;
    }


    /**
     * Sets the description value for this License_type_rec.
     * 
     * @param description
     */
    public void setDescription(java.lang.String description) {
        this.description = description;
    }


    /**
     * Gets the remarks value for this License_type_rec.
     * 
     * @return remarks
     */
    public java.lang.String getRemarks() {
        return remarks;
    }


    /**
     * Sets the remarks value for this License_type_rec.
     * 
     * @param remarks
     */
    public void setRemarks(java.lang.String remarks) {
        this.remarks = remarks;
    }


    /**
     * Gets the oem value for this License_type_rec.
     * 
     * @return oem
     */
    public boolean isOem() {
        return oem;
    }


    /**
     * Sets the oem value for this License_type_rec.
     * 
     * @param oem
     */
    public void setOem(boolean oem) {
        this.oem = oem;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof License_type_rec)) return false;
        License_type_rec other = (License_type_rec) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            this.license_type_id == other.getLicense_type_id() &&
            ((this.import_id==null && other.getImport_id()==null) || 
             (this.import_id!=null &&
              this.import_id.equals(other.getImport_id()))) &&
            this.data_source_id == other.getData_source_id() &&
            ((this.description==null && other.getDescription()==null) || 
             (this.description!=null &&
              this.description.equals(other.getDescription()))) &&
            ((this.remarks==null && other.getRemarks()==null) || 
             (this.remarks!=null &&
              this.remarks.equals(other.getRemarks()))) &&
            this.oem == other.isOem();
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        _hashCode += getLicense_type_id();
        if (getImport_id() != null) {
            _hashCode += getImport_id().hashCode();
        }
        _hashCode += getData_source_id();
        if (getDescription() != null) {
            _hashCode += getDescription().hashCode();
        }
        if (getRemarks() != null) {
            _hashCode += getRemarks().hashCode();
        }
        _hashCode += (isOem() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(License_type_rec.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://aspera.com/wsdl/", "license_type_rec"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("license_type_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "license_type_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("import_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "import_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("data_source_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "data_source_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("description");
        elemField.setXmlName(new javax.xml.namespace.QName("", "description"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("remarks");
        elemField.setXmlName(new javax.xml.namespace.QName("", "remarks"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("oem");
        elemField.setXmlName(new javax.xml.namespace.QName("", "oem"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}

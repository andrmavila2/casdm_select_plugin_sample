/**
 * Enrolment_rec.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ca.usm.plugins.samples.resourceplugin.sam.ws.proxy;

public class Enrolment_rec  implements java.io.Serializable {
    private int enrolment_id;

    private java.lang.String import_id;

    private int data_source_id;

    private int contract_id;

    private java.lang.String enrolment_number;

    private int org_level_0_id;

    private int org_level_1_id;

    private int org_level_2_id;

    private int customer_contact_id;

    private int supplier_id;

    private int supplier_contact_id;

    private int contract_status_id;

    private java.lang.String signed_date;

    private java.lang.String valid_from;

    private java.lang.String valid_until;

    private java.lang.String remarks;

    public Enrolment_rec() {
    }

    public Enrolment_rec(
           int enrolment_id,
           java.lang.String import_id,
           int data_source_id,
           int contract_id,
           java.lang.String enrolment_number,
           int org_level_0_id,
           int org_level_1_id,
           int org_level_2_id,
           int customer_contact_id,
           int supplier_id,
           int supplier_contact_id,
           int contract_status_id,
           java.lang.String signed_date,
           java.lang.String valid_from,
           java.lang.String valid_until,
           java.lang.String remarks) {
           this.enrolment_id = enrolment_id;
           this.import_id = import_id;
           this.data_source_id = data_source_id;
           this.contract_id = contract_id;
           this.enrolment_number = enrolment_number;
           this.org_level_0_id = org_level_0_id;
           this.org_level_1_id = org_level_1_id;
           this.org_level_2_id = org_level_2_id;
           this.customer_contact_id = customer_contact_id;
           this.supplier_id = supplier_id;
           this.supplier_contact_id = supplier_contact_id;
           this.contract_status_id = contract_status_id;
           this.signed_date = signed_date;
           this.valid_from = valid_from;
           this.valid_until = valid_until;
           this.remarks = remarks;
    }


    /**
     * Gets the enrolment_id value for this Enrolment_rec.
     * 
     * @return enrolment_id
     */
    public int getEnrolment_id() {
        return enrolment_id;
    }


    /**
     * Sets the enrolment_id value for this Enrolment_rec.
     * 
     * @param enrolment_id
     */
    public void setEnrolment_id(int enrolment_id) {
        this.enrolment_id = enrolment_id;
    }


    /**
     * Gets the import_id value for this Enrolment_rec.
     * 
     * @return import_id
     */
    public java.lang.String getImport_id() {
        return import_id;
    }


    /**
     * Sets the import_id value for this Enrolment_rec.
     * 
     * @param import_id
     */
    public void setImport_id(java.lang.String import_id) {
        this.import_id = import_id;
    }


    /**
     * Gets the data_source_id value for this Enrolment_rec.
     * 
     * @return data_source_id
     */
    public int getData_source_id() {
        return data_source_id;
    }


    /**
     * Sets the data_source_id value for this Enrolment_rec.
     * 
     * @param data_source_id
     */
    public void setData_source_id(int data_source_id) {
        this.data_source_id = data_source_id;
    }


    /**
     * Gets the contract_id value for this Enrolment_rec.
     * 
     * @return contract_id
     */
    public int getContract_id() {
        return contract_id;
    }


    /**
     * Sets the contract_id value for this Enrolment_rec.
     * 
     * @param contract_id
     */
    public void setContract_id(int contract_id) {
        this.contract_id = contract_id;
    }


    /**
     * Gets the enrolment_number value for this Enrolment_rec.
     * 
     * @return enrolment_number
     */
    public java.lang.String getEnrolment_number() {
        return enrolment_number;
    }


    /**
     * Sets the enrolment_number value for this Enrolment_rec.
     * 
     * @param enrolment_number
     */
    public void setEnrolment_number(java.lang.String enrolment_number) {
        this.enrolment_number = enrolment_number;
    }


    /**
     * Gets the org_level_0_id value for this Enrolment_rec.
     * 
     * @return org_level_0_id
     */
    public int getOrg_level_0_id() {
        return org_level_0_id;
    }


    /**
     * Sets the org_level_0_id value for this Enrolment_rec.
     * 
     * @param org_level_0_id
     */
    public void setOrg_level_0_id(int org_level_0_id) {
        this.org_level_0_id = org_level_0_id;
    }


    /**
     * Gets the org_level_1_id value for this Enrolment_rec.
     * 
     * @return org_level_1_id
     */
    public int getOrg_level_1_id() {
        return org_level_1_id;
    }


    /**
     * Sets the org_level_1_id value for this Enrolment_rec.
     * 
     * @param org_level_1_id
     */
    public void setOrg_level_1_id(int org_level_1_id) {
        this.org_level_1_id = org_level_1_id;
    }


    /**
     * Gets the org_level_2_id value for this Enrolment_rec.
     * 
     * @return org_level_2_id
     */
    public int getOrg_level_2_id() {
        return org_level_2_id;
    }


    /**
     * Sets the org_level_2_id value for this Enrolment_rec.
     * 
     * @param org_level_2_id
     */
    public void setOrg_level_2_id(int org_level_2_id) {
        this.org_level_2_id = org_level_2_id;
    }


    /**
     * Gets the customer_contact_id value for this Enrolment_rec.
     * 
     * @return customer_contact_id
     */
    public int getCustomer_contact_id() {
        return customer_contact_id;
    }


    /**
     * Sets the customer_contact_id value for this Enrolment_rec.
     * 
     * @param customer_contact_id
     */
    public void setCustomer_contact_id(int customer_contact_id) {
        this.customer_contact_id = customer_contact_id;
    }


    /**
     * Gets the supplier_id value for this Enrolment_rec.
     * 
     * @return supplier_id
     */
    public int getSupplier_id() {
        return supplier_id;
    }


    /**
     * Sets the supplier_id value for this Enrolment_rec.
     * 
     * @param supplier_id
     */
    public void setSupplier_id(int supplier_id) {
        this.supplier_id = supplier_id;
    }


    /**
     * Gets the supplier_contact_id value for this Enrolment_rec.
     * 
     * @return supplier_contact_id
     */
    public int getSupplier_contact_id() {
        return supplier_contact_id;
    }


    /**
     * Sets the supplier_contact_id value for this Enrolment_rec.
     * 
     * @param supplier_contact_id
     */
    public void setSupplier_contact_id(int supplier_contact_id) {
        this.supplier_contact_id = supplier_contact_id;
    }


    /**
     * Gets the contract_status_id value for this Enrolment_rec.
     * 
     * @return contract_status_id
     */
    public int getContract_status_id() {
        return contract_status_id;
    }


    /**
     * Sets the contract_status_id value for this Enrolment_rec.
     * 
     * @param contract_status_id
     */
    public void setContract_status_id(int contract_status_id) {
        this.contract_status_id = contract_status_id;
    }


    /**
     * Gets the signed_date value for this Enrolment_rec.
     * 
     * @return signed_date
     */
    public java.lang.String getSigned_date() {
        return signed_date;
    }


    /**
     * Sets the signed_date value for this Enrolment_rec.
     * 
     * @param signed_date
     */
    public void setSigned_date(java.lang.String signed_date) {
        this.signed_date = signed_date;
    }


    /**
     * Gets the valid_from value for this Enrolment_rec.
     * 
     * @return valid_from
     */
    public java.lang.String getValid_from() {
        return valid_from;
    }


    /**
     * Sets the valid_from value for this Enrolment_rec.
     * 
     * @param valid_from
     */
    public void setValid_from(java.lang.String valid_from) {
        this.valid_from = valid_from;
    }


    /**
     * Gets the valid_until value for this Enrolment_rec.
     * 
     * @return valid_until
     */
    public java.lang.String getValid_until() {
        return valid_until;
    }


    /**
     * Sets the valid_until value for this Enrolment_rec.
     * 
     * @param valid_until
     */
    public void setValid_until(java.lang.String valid_until) {
        this.valid_until = valid_until;
    }


    /**
     * Gets the remarks value for this Enrolment_rec.
     * 
     * @return remarks
     */
    public java.lang.String getRemarks() {
        return remarks;
    }


    /**
     * Sets the remarks value for this Enrolment_rec.
     * 
     * @param remarks
     */
    public void setRemarks(java.lang.String remarks) {
        this.remarks = remarks;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Enrolment_rec)) return false;
        Enrolment_rec other = (Enrolment_rec) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            this.enrolment_id == other.getEnrolment_id() &&
            ((this.import_id==null && other.getImport_id()==null) || 
             (this.import_id!=null &&
              this.import_id.equals(other.getImport_id()))) &&
            this.data_source_id == other.getData_source_id() &&
            this.contract_id == other.getContract_id() &&
            ((this.enrolment_number==null && other.getEnrolment_number()==null) || 
             (this.enrolment_number!=null &&
              this.enrolment_number.equals(other.getEnrolment_number()))) &&
            this.org_level_0_id == other.getOrg_level_0_id() &&
            this.org_level_1_id == other.getOrg_level_1_id() &&
            this.org_level_2_id == other.getOrg_level_2_id() &&
            this.customer_contact_id == other.getCustomer_contact_id() &&
            this.supplier_id == other.getSupplier_id() &&
            this.supplier_contact_id == other.getSupplier_contact_id() &&
            this.contract_status_id == other.getContract_status_id() &&
            ((this.signed_date==null && other.getSigned_date()==null) || 
             (this.signed_date!=null &&
              this.signed_date.equals(other.getSigned_date()))) &&
            ((this.valid_from==null && other.getValid_from()==null) || 
             (this.valid_from!=null &&
              this.valid_from.equals(other.getValid_from()))) &&
            ((this.valid_until==null && other.getValid_until()==null) || 
             (this.valid_until!=null &&
              this.valid_until.equals(other.getValid_until()))) &&
            ((this.remarks==null && other.getRemarks()==null) || 
             (this.remarks!=null &&
              this.remarks.equals(other.getRemarks())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        _hashCode += getEnrolment_id();
        if (getImport_id() != null) {
            _hashCode += getImport_id().hashCode();
        }
        _hashCode += getData_source_id();
        _hashCode += getContract_id();
        if (getEnrolment_number() != null) {
            _hashCode += getEnrolment_number().hashCode();
        }
        _hashCode += getOrg_level_0_id();
        _hashCode += getOrg_level_1_id();
        _hashCode += getOrg_level_2_id();
        _hashCode += getCustomer_contact_id();
        _hashCode += getSupplier_id();
        _hashCode += getSupplier_contact_id();
        _hashCode += getContract_status_id();
        if (getSigned_date() != null) {
            _hashCode += getSigned_date().hashCode();
        }
        if (getValid_from() != null) {
            _hashCode += getValid_from().hashCode();
        }
        if (getValid_until() != null) {
            _hashCode += getValid_until().hashCode();
        }
        if (getRemarks() != null) {
            _hashCode += getRemarks().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Enrolment_rec.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://aspera.com/wsdl/", "enrolment_rec"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("enrolment_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "enrolment_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("import_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "import_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("data_source_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "data_source_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("contract_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "contract_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("enrolment_number");
        elemField.setXmlName(new javax.xml.namespace.QName("", "enrolment_number"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("org_level_0_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "org_level_0_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("org_level_1_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "org_level_1_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("org_level_2_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "org_level_2_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("customer_contact_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "customer_contact_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("supplier_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "supplier_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("supplier_contact_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "supplier_contact_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("contract_status_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "contract_status_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("signed_date");
        elemField.setXmlName(new javax.xml.namespace.QName("", "signed_date"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("valid_from");
        elemField.setXmlName(new javax.xml.namespace.QName("", "valid_from"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("valid_until");
        elemField.setXmlName(new javax.xml.namespace.QName("", "valid_until"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("remarks");
        elemField.setXmlName(new javax.xml.namespace.QName("", "remarks"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}

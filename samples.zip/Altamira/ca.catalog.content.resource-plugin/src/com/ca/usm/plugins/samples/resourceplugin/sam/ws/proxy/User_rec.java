/**
 * User_rec.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ca.usm.plugins.samples.resourceplugin.sam.ws.proxy;

public class User_rec  implements java.io.Serializable {
    private int user_id;

    private java.lang.String import_id;

    private int data_source_id;

    private java.lang.String login;

    private int level_2_id;

    private int location_id;

    private java.lang.String last_name;

    private java.lang.String first_name;

    private java.lang.String email;

    private java.lang.String password;

    private java.lang.String password_changed;

    private boolean is_active;

    private boolean is_st_user;

    private boolean is_superuser;

    private java.lang.String startmail_send;

    private java.lang.String language;

    private java.lang.String timezone;

    private java.lang.String date_format;

    private java.lang.String remarks;

    public User_rec() {
    }

    public User_rec(
           int user_id,
           java.lang.String import_id,
           int data_source_id,
           java.lang.String login,
           int level_2_id,
           int location_id,
           java.lang.String last_name,
           java.lang.String first_name,
           java.lang.String email,
           java.lang.String password,
           java.lang.String password_changed,
           boolean is_active,
           boolean is_st_user,
           boolean is_superuser,
           java.lang.String startmail_send,
           java.lang.String language,
           java.lang.String timezone,
           java.lang.String date_format,
           java.lang.String remarks) {
           this.user_id = user_id;
           this.import_id = import_id;
           this.data_source_id = data_source_id;
           this.login = login;
           this.level_2_id = level_2_id;
           this.location_id = location_id;
           this.last_name = last_name;
           this.first_name = first_name;
           this.email = email;
           this.password = password;
           this.password_changed = password_changed;
           this.is_active = is_active;
           this.is_st_user = is_st_user;
           this.is_superuser = is_superuser;
           this.startmail_send = startmail_send;
           this.language = language;
           this.timezone = timezone;
           this.date_format = date_format;
           this.remarks = remarks;
    }


    /**
     * Gets the user_id value for this User_rec.
     * 
     * @return user_id
     */
    public int getUser_id() {
        return user_id;
    }


    /**
     * Sets the user_id value for this User_rec.
     * 
     * @param user_id
     */
    public void setUser_id(int user_id) {
        this.user_id = user_id;
    }


    /**
     * Gets the import_id value for this User_rec.
     * 
     * @return import_id
     */
    public java.lang.String getImport_id() {
        return import_id;
    }


    /**
     * Sets the import_id value for this User_rec.
     * 
     * @param import_id
     */
    public void setImport_id(java.lang.String import_id) {
        this.import_id = import_id;
    }


    /**
     * Gets the data_source_id value for this User_rec.
     * 
     * @return data_source_id
     */
    public int getData_source_id() {
        return data_source_id;
    }


    /**
     * Sets the data_source_id value for this User_rec.
     * 
     * @param data_source_id
     */
    public void setData_source_id(int data_source_id) {
        this.data_source_id = data_source_id;
    }


    /**
     * Gets the login value for this User_rec.
     * 
     * @return login
     */
    public java.lang.String getLogin() {
        return login;
    }


    /**
     * Sets the login value for this User_rec.
     * 
     * @param login
     */
    public void setLogin(java.lang.String login) {
        this.login = login;
    }


    /**
     * Gets the level_2_id value for this User_rec.
     * 
     * @return level_2_id
     */
    public int getLevel_2_id() {
        return level_2_id;
    }


    /**
     * Sets the level_2_id value for this User_rec.
     * 
     * @param level_2_id
     */
    public void setLevel_2_id(int level_2_id) {
        this.level_2_id = level_2_id;
    }


    /**
     * Gets the location_id value for this User_rec.
     * 
     * @return location_id
     */
    public int getLocation_id() {
        return location_id;
    }


    /**
     * Sets the location_id value for this User_rec.
     * 
     * @param location_id
     */
    public void setLocation_id(int location_id) {
        this.location_id = location_id;
    }


    /**
     * Gets the last_name value for this User_rec.
     * 
     * @return last_name
     */
    public java.lang.String getLast_name() {
        return last_name;
    }


    /**
     * Sets the last_name value for this User_rec.
     * 
     * @param last_name
     */
    public void setLast_name(java.lang.String last_name) {
        this.last_name = last_name;
    }


    /**
     * Gets the first_name value for this User_rec.
     * 
     * @return first_name
     */
    public java.lang.String getFirst_name() {
        return first_name;
    }


    /**
     * Sets the first_name value for this User_rec.
     * 
     * @param first_name
     */
    public void setFirst_name(java.lang.String first_name) {
        this.first_name = first_name;
    }


    /**
     * Gets the email value for this User_rec.
     * 
     * @return email
     */
    public java.lang.String getEmail() {
        return email;
    }


    /**
     * Sets the email value for this User_rec.
     * 
     * @param email
     */
    public void setEmail(java.lang.String email) {
        this.email = email;
    }


    /**
     * Gets the password value for this User_rec.
     * 
     * @return password
     */
    public java.lang.String getPassword() {
        return password;
    }


    /**
     * Sets the password value for this User_rec.
     * 
     * @param password
     */
    public void setPassword(java.lang.String password) {
        this.password = password;
    }


    /**
     * Gets the password_changed value for this User_rec.
     * 
     * @return password_changed
     */
    public java.lang.String getPassword_changed() {
        return password_changed;
    }


    /**
     * Sets the password_changed value for this User_rec.
     * 
     * @param password_changed
     */
    public void setPassword_changed(java.lang.String password_changed) {
        this.password_changed = password_changed;
    }


    /**
     * Gets the is_active value for this User_rec.
     * 
     * @return is_active
     */
    public boolean isIs_active() {
        return is_active;
    }


    /**
     * Sets the is_active value for this User_rec.
     * 
     * @param is_active
     */
    public void setIs_active(boolean is_active) {
        this.is_active = is_active;
    }


    /**
     * Gets the is_st_user value for this User_rec.
     * 
     * @return is_st_user
     */
    public boolean isIs_st_user() {
        return is_st_user;
    }


    /**
     * Sets the is_st_user value for this User_rec.
     * 
     * @param is_st_user
     */
    public void setIs_st_user(boolean is_st_user) {
        this.is_st_user = is_st_user;
    }


    /**
     * Gets the is_superuser value for this User_rec.
     * 
     * @return is_superuser
     */
    public boolean isIs_superuser() {
        return is_superuser;
    }


    /**
     * Sets the is_superuser value for this User_rec.
     * 
     * @param is_superuser
     */
    public void setIs_superuser(boolean is_superuser) {
        this.is_superuser = is_superuser;
    }


    /**
     * Gets the startmail_send value for this User_rec.
     * 
     * @return startmail_send
     */
    public java.lang.String getStartmail_send() {
        return startmail_send;
    }


    /**
     * Sets the startmail_send value for this User_rec.
     * 
     * @param startmail_send
     */
    public void setStartmail_send(java.lang.String startmail_send) {
        this.startmail_send = startmail_send;
    }


    /**
     * Gets the language value for this User_rec.
     * 
     * @return language
     */
    public java.lang.String getLanguage() {
        return language;
    }


    /**
     * Sets the language value for this User_rec.
     * 
     * @param language
     */
    public void setLanguage(java.lang.String language) {
        this.language = language;
    }


    /**
     * Gets the timezone value for this User_rec.
     * 
     * @return timezone
     */
    public java.lang.String getTimezone() {
        return timezone;
    }


    /**
     * Sets the timezone value for this User_rec.
     * 
     * @param timezone
     */
    public void setTimezone(java.lang.String timezone) {
        this.timezone = timezone;
    }


    /**
     * Gets the date_format value for this User_rec.
     * 
     * @return date_format
     */
    public java.lang.String getDate_format() {
        return date_format;
    }


    /**
     * Sets the date_format value for this User_rec.
     * 
     * @param date_format
     */
    public void setDate_format(java.lang.String date_format) {
        this.date_format = date_format;
    }


    /**
     * Gets the remarks value for this User_rec.
     * 
     * @return remarks
     */
    public java.lang.String getRemarks() {
        return remarks;
    }


    /**
     * Sets the remarks value for this User_rec.
     * 
     * @param remarks
     */
    public void setRemarks(java.lang.String remarks) {
        this.remarks = remarks;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof User_rec)) return false;
        User_rec other = (User_rec) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            this.user_id == other.getUser_id() &&
            ((this.import_id==null && other.getImport_id()==null) || 
             (this.import_id!=null &&
              this.import_id.equals(other.getImport_id()))) &&
            this.data_source_id == other.getData_source_id() &&
            ((this.login==null && other.getLogin()==null) || 
             (this.login!=null &&
              this.login.equals(other.getLogin()))) &&
            this.level_2_id == other.getLevel_2_id() &&
            this.location_id == other.getLocation_id() &&
            ((this.last_name==null && other.getLast_name()==null) || 
             (this.last_name!=null &&
              this.last_name.equals(other.getLast_name()))) &&
            ((this.first_name==null && other.getFirst_name()==null) || 
             (this.first_name!=null &&
              this.first_name.equals(other.getFirst_name()))) &&
            ((this.email==null && other.getEmail()==null) || 
             (this.email!=null &&
              this.email.equals(other.getEmail()))) &&
            ((this.password==null && other.getPassword()==null) || 
             (this.password!=null &&
              this.password.equals(other.getPassword()))) &&
            ((this.password_changed==null && other.getPassword_changed()==null) || 
             (this.password_changed!=null &&
              this.password_changed.equals(other.getPassword_changed()))) &&
            this.is_active == other.isIs_active() &&
            this.is_st_user == other.isIs_st_user() &&
            this.is_superuser == other.isIs_superuser() &&
            ((this.startmail_send==null && other.getStartmail_send()==null) || 
             (this.startmail_send!=null &&
              this.startmail_send.equals(other.getStartmail_send()))) &&
            ((this.language==null && other.getLanguage()==null) || 
             (this.language!=null &&
              this.language.equals(other.getLanguage()))) &&
            ((this.timezone==null && other.getTimezone()==null) || 
             (this.timezone!=null &&
              this.timezone.equals(other.getTimezone()))) &&
            ((this.date_format==null && other.getDate_format()==null) || 
             (this.date_format!=null &&
              this.date_format.equals(other.getDate_format()))) &&
            ((this.remarks==null && other.getRemarks()==null) || 
             (this.remarks!=null &&
              this.remarks.equals(other.getRemarks())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        _hashCode += getUser_id();
        if (getImport_id() != null) {
            _hashCode += getImport_id().hashCode();
        }
        _hashCode += getData_source_id();
        if (getLogin() != null) {
            _hashCode += getLogin().hashCode();
        }
        _hashCode += getLevel_2_id();
        _hashCode += getLocation_id();
        if (getLast_name() != null) {
            _hashCode += getLast_name().hashCode();
        }
        if (getFirst_name() != null) {
            _hashCode += getFirst_name().hashCode();
        }
        if (getEmail() != null) {
            _hashCode += getEmail().hashCode();
        }
        if (getPassword() != null) {
            _hashCode += getPassword().hashCode();
        }
        if (getPassword_changed() != null) {
            _hashCode += getPassword_changed().hashCode();
        }
        _hashCode += (isIs_active() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        _hashCode += (isIs_st_user() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        _hashCode += (isIs_superuser() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        if (getStartmail_send() != null) {
            _hashCode += getStartmail_send().hashCode();
        }
        if (getLanguage() != null) {
            _hashCode += getLanguage().hashCode();
        }
        if (getTimezone() != null) {
            _hashCode += getTimezone().hashCode();
        }
        if (getDate_format() != null) {
            _hashCode += getDate_format().hashCode();
        }
        if (getRemarks() != null) {
            _hashCode += getRemarks().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(User_rec.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://aspera.com/wsdl/", "user_rec"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("user_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "user_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("import_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "import_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("data_source_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "data_source_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("login");
        elemField.setXmlName(new javax.xml.namespace.QName("", "login"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("level_2_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "level_2_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("location_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "location_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("last_name");
        elemField.setXmlName(new javax.xml.namespace.QName("", "last_name"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("first_name");
        elemField.setXmlName(new javax.xml.namespace.QName("", "first_name"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("email");
        elemField.setXmlName(new javax.xml.namespace.QName("", "email"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("password");
        elemField.setXmlName(new javax.xml.namespace.QName("", "password"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("password_changed");
        elemField.setXmlName(new javax.xml.namespace.QName("", "password_changed"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("is_active");
        elemField.setXmlName(new javax.xml.namespace.QName("", "is_active"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("is_st_user");
        elemField.setXmlName(new javax.xml.namespace.QName("", "is_st_user"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("is_superuser");
        elemField.setXmlName(new javax.xml.namespace.QName("", "is_superuser"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("startmail_send");
        elemField.setXmlName(new javax.xml.namespace.QName("", "startmail_send"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("language");
        elemField.setXmlName(new javax.xml.namespace.QName("", "language"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("timezone");
        elemField.setXmlName(new javax.xml.namespace.QName("", "timezone"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("date_format");
        elemField.setXmlName(new javax.xml.namespace.QName("", "date_format"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("remarks");
        elemField.setXmlName(new javax.xml.namespace.QName("", "remarks"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}

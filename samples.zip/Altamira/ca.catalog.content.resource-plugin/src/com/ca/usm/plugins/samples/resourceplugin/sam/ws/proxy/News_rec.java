/**
 * News_rec.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ca.usm.plugins.samples.resourceplugin.sam.ws.proxy;

public class News_rec  implements java.io.Serializable {
    private int news_id;

    private java.lang.String import_id;

    private int data_source_id;

    private java.lang.String news_type;

    private java.lang.String subject_de;

    private java.lang.String subject_en;

    private java.lang.String subject_es;

    private java.lang.String subject_fr;

    private java.lang.String subject_it;

    private java.lang.String subject_ja;

    private java.lang.String subject_pt;

    private java.lang.String text_de;

    private java.lang.String text_en;

    private java.lang.String text_es;

    private java.lang.String text_fr;

    private java.lang.String text_it;

    private java.lang.String text_ja;

    private java.lang.String text_pt;

    private java.lang.String valid_from;

    private java.lang.String valid_until;

    public News_rec() {
    }

    public News_rec(
           int news_id,
           java.lang.String import_id,
           int data_source_id,
           java.lang.String news_type,
           java.lang.String subject_de,
           java.lang.String subject_en,
           java.lang.String subject_es,
           java.lang.String subject_fr,
           java.lang.String subject_it,
           java.lang.String subject_ja,
           java.lang.String subject_pt,
           java.lang.String text_de,
           java.lang.String text_en,
           java.lang.String text_es,
           java.lang.String text_fr,
           java.lang.String text_it,
           java.lang.String text_ja,
           java.lang.String text_pt,
           java.lang.String valid_from,
           java.lang.String valid_until) {
           this.news_id = news_id;
           this.import_id = import_id;
           this.data_source_id = data_source_id;
           this.news_type = news_type;
           this.subject_de = subject_de;
           this.subject_en = subject_en;
           this.subject_es = subject_es;
           this.subject_fr = subject_fr;
           this.subject_it = subject_it;
           this.subject_ja = subject_ja;
           this.subject_pt = subject_pt;
           this.text_de = text_de;
           this.text_en = text_en;
           this.text_es = text_es;
           this.text_fr = text_fr;
           this.text_it = text_it;
           this.text_ja = text_ja;
           this.text_pt = text_pt;
           this.valid_from = valid_from;
           this.valid_until = valid_until;
    }


    /**
     * Gets the news_id value for this News_rec.
     * 
     * @return news_id
     */
    public int getNews_id() {
        return news_id;
    }


    /**
     * Sets the news_id value for this News_rec.
     * 
     * @param news_id
     */
    public void setNews_id(int news_id) {
        this.news_id = news_id;
    }


    /**
     * Gets the import_id value for this News_rec.
     * 
     * @return import_id
     */
    public java.lang.String getImport_id() {
        return import_id;
    }


    /**
     * Sets the import_id value for this News_rec.
     * 
     * @param import_id
     */
    public void setImport_id(java.lang.String import_id) {
        this.import_id = import_id;
    }


    /**
     * Gets the data_source_id value for this News_rec.
     * 
     * @return data_source_id
     */
    public int getData_source_id() {
        return data_source_id;
    }


    /**
     * Sets the data_source_id value for this News_rec.
     * 
     * @param data_source_id
     */
    public void setData_source_id(int data_source_id) {
        this.data_source_id = data_source_id;
    }


    /**
     * Gets the news_type value for this News_rec.
     * 
     * @return news_type
     */
    public java.lang.String getNews_type() {
        return news_type;
    }


    /**
     * Sets the news_type value for this News_rec.
     * 
     * @param news_type
     */
    public void setNews_type(java.lang.String news_type) {
        this.news_type = news_type;
    }


    /**
     * Gets the subject_de value for this News_rec.
     * 
     * @return subject_de
     */
    public java.lang.String getSubject_de() {
        return subject_de;
    }


    /**
     * Sets the subject_de value for this News_rec.
     * 
     * @param subject_de
     */
    public void setSubject_de(java.lang.String subject_de) {
        this.subject_de = subject_de;
    }


    /**
     * Gets the subject_en value for this News_rec.
     * 
     * @return subject_en
     */
    public java.lang.String getSubject_en() {
        return subject_en;
    }


    /**
     * Sets the subject_en value for this News_rec.
     * 
     * @param subject_en
     */
    public void setSubject_en(java.lang.String subject_en) {
        this.subject_en = subject_en;
    }


    /**
     * Gets the subject_es value for this News_rec.
     * 
     * @return subject_es
     */
    public java.lang.String getSubject_es() {
        return subject_es;
    }


    /**
     * Sets the subject_es value for this News_rec.
     * 
     * @param subject_es
     */
    public void setSubject_es(java.lang.String subject_es) {
        this.subject_es = subject_es;
    }


    /**
     * Gets the subject_fr value for this News_rec.
     * 
     * @return subject_fr
     */
    public java.lang.String getSubject_fr() {
        return subject_fr;
    }


    /**
     * Sets the subject_fr value for this News_rec.
     * 
     * @param subject_fr
     */
    public void setSubject_fr(java.lang.String subject_fr) {
        this.subject_fr = subject_fr;
    }


    /**
     * Gets the subject_it value for this News_rec.
     * 
     * @return subject_it
     */
    public java.lang.String getSubject_it() {
        return subject_it;
    }


    /**
     * Sets the subject_it value for this News_rec.
     * 
     * @param subject_it
     */
    public void setSubject_it(java.lang.String subject_it) {
        this.subject_it = subject_it;
    }


    /**
     * Gets the subject_ja value for this News_rec.
     * 
     * @return subject_ja
     */
    public java.lang.String getSubject_ja() {
        return subject_ja;
    }


    /**
     * Sets the subject_ja value for this News_rec.
     * 
     * @param subject_ja
     */
    public void setSubject_ja(java.lang.String subject_ja) {
        this.subject_ja = subject_ja;
    }


    /**
     * Gets the subject_pt value for this News_rec.
     * 
     * @return subject_pt
     */
    public java.lang.String getSubject_pt() {
        return subject_pt;
    }


    /**
     * Sets the subject_pt value for this News_rec.
     * 
     * @param subject_pt
     */
    public void setSubject_pt(java.lang.String subject_pt) {
        this.subject_pt = subject_pt;
    }


    /**
     * Gets the text_de value for this News_rec.
     * 
     * @return text_de
     */
    public java.lang.String getText_de() {
        return text_de;
    }


    /**
     * Sets the text_de value for this News_rec.
     * 
     * @param text_de
     */
    public void setText_de(java.lang.String text_de) {
        this.text_de = text_de;
    }


    /**
     * Gets the text_en value for this News_rec.
     * 
     * @return text_en
     */
    public java.lang.String getText_en() {
        return text_en;
    }


    /**
     * Sets the text_en value for this News_rec.
     * 
     * @param text_en
     */
    public void setText_en(java.lang.String text_en) {
        this.text_en = text_en;
    }


    /**
     * Gets the text_es value for this News_rec.
     * 
     * @return text_es
     */
    public java.lang.String getText_es() {
        return text_es;
    }


    /**
     * Sets the text_es value for this News_rec.
     * 
     * @param text_es
     */
    public void setText_es(java.lang.String text_es) {
        this.text_es = text_es;
    }


    /**
     * Gets the text_fr value for this News_rec.
     * 
     * @return text_fr
     */
    public java.lang.String getText_fr() {
        return text_fr;
    }


    /**
     * Sets the text_fr value for this News_rec.
     * 
     * @param text_fr
     */
    public void setText_fr(java.lang.String text_fr) {
        this.text_fr = text_fr;
    }


    /**
     * Gets the text_it value for this News_rec.
     * 
     * @return text_it
     */
    public java.lang.String getText_it() {
        return text_it;
    }


    /**
     * Sets the text_it value for this News_rec.
     * 
     * @param text_it
     */
    public void setText_it(java.lang.String text_it) {
        this.text_it = text_it;
    }


    /**
     * Gets the text_ja value for this News_rec.
     * 
     * @return text_ja
     */
    public java.lang.String getText_ja() {
        return text_ja;
    }


    /**
     * Sets the text_ja value for this News_rec.
     * 
     * @param text_ja
     */
    public void setText_ja(java.lang.String text_ja) {
        this.text_ja = text_ja;
    }


    /**
     * Gets the text_pt value for this News_rec.
     * 
     * @return text_pt
     */
    public java.lang.String getText_pt() {
        return text_pt;
    }


    /**
     * Sets the text_pt value for this News_rec.
     * 
     * @param text_pt
     */
    public void setText_pt(java.lang.String text_pt) {
        this.text_pt = text_pt;
    }


    /**
     * Gets the valid_from value for this News_rec.
     * 
     * @return valid_from
     */
    public java.lang.String getValid_from() {
        return valid_from;
    }


    /**
     * Sets the valid_from value for this News_rec.
     * 
     * @param valid_from
     */
    public void setValid_from(java.lang.String valid_from) {
        this.valid_from = valid_from;
    }


    /**
     * Gets the valid_until value for this News_rec.
     * 
     * @return valid_until
     */
    public java.lang.String getValid_until() {
        return valid_until;
    }


    /**
     * Sets the valid_until value for this News_rec.
     * 
     * @param valid_until
     */
    public void setValid_until(java.lang.String valid_until) {
        this.valid_until = valid_until;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof News_rec)) return false;
        News_rec other = (News_rec) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            this.news_id == other.getNews_id() &&
            ((this.import_id==null && other.getImport_id()==null) || 
             (this.import_id!=null &&
              this.import_id.equals(other.getImport_id()))) &&
            this.data_source_id == other.getData_source_id() &&
            ((this.news_type==null && other.getNews_type()==null) || 
             (this.news_type!=null &&
              this.news_type.equals(other.getNews_type()))) &&
            ((this.subject_de==null && other.getSubject_de()==null) || 
             (this.subject_de!=null &&
              this.subject_de.equals(other.getSubject_de()))) &&
            ((this.subject_en==null && other.getSubject_en()==null) || 
             (this.subject_en!=null &&
              this.subject_en.equals(other.getSubject_en()))) &&
            ((this.subject_es==null && other.getSubject_es()==null) || 
             (this.subject_es!=null &&
              this.subject_es.equals(other.getSubject_es()))) &&
            ((this.subject_fr==null && other.getSubject_fr()==null) || 
             (this.subject_fr!=null &&
              this.subject_fr.equals(other.getSubject_fr()))) &&
            ((this.subject_it==null && other.getSubject_it()==null) || 
             (this.subject_it!=null &&
              this.subject_it.equals(other.getSubject_it()))) &&
            ((this.subject_ja==null && other.getSubject_ja()==null) || 
             (this.subject_ja!=null &&
              this.subject_ja.equals(other.getSubject_ja()))) &&
            ((this.subject_pt==null && other.getSubject_pt()==null) || 
             (this.subject_pt!=null &&
              this.subject_pt.equals(other.getSubject_pt()))) &&
            ((this.text_de==null && other.getText_de()==null) || 
             (this.text_de!=null &&
              this.text_de.equals(other.getText_de()))) &&
            ((this.text_en==null && other.getText_en()==null) || 
             (this.text_en!=null &&
              this.text_en.equals(other.getText_en()))) &&
            ((this.text_es==null && other.getText_es()==null) || 
             (this.text_es!=null &&
              this.text_es.equals(other.getText_es()))) &&
            ((this.text_fr==null && other.getText_fr()==null) || 
             (this.text_fr!=null &&
              this.text_fr.equals(other.getText_fr()))) &&
            ((this.text_it==null && other.getText_it()==null) || 
             (this.text_it!=null &&
              this.text_it.equals(other.getText_it()))) &&
            ((this.text_ja==null && other.getText_ja()==null) || 
             (this.text_ja!=null &&
              this.text_ja.equals(other.getText_ja()))) &&
            ((this.text_pt==null && other.getText_pt()==null) || 
             (this.text_pt!=null &&
              this.text_pt.equals(other.getText_pt()))) &&
            ((this.valid_from==null && other.getValid_from()==null) || 
             (this.valid_from!=null &&
              this.valid_from.equals(other.getValid_from()))) &&
            ((this.valid_until==null && other.getValid_until()==null) || 
             (this.valid_until!=null &&
              this.valid_until.equals(other.getValid_until())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        _hashCode += getNews_id();
        if (getImport_id() != null) {
            _hashCode += getImport_id().hashCode();
        }
        _hashCode += getData_source_id();
        if (getNews_type() != null) {
            _hashCode += getNews_type().hashCode();
        }
        if (getSubject_de() != null) {
            _hashCode += getSubject_de().hashCode();
        }
        if (getSubject_en() != null) {
            _hashCode += getSubject_en().hashCode();
        }
        if (getSubject_es() != null) {
            _hashCode += getSubject_es().hashCode();
        }
        if (getSubject_fr() != null) {
            _hashCode += getSubject_fr().hashCode();
        }
        if (getSubject_it() != null) {
            _hashCode += getSubject_it().hashCode();
        }
        if (getSubject_ja() != null) {
            _hashCode += getSubject_ja().hashCode();
        }
        if (getSubject_pt() != null) {
            _hashCode += getSubject_pt().hashCode();
        }
        if (getText_de() != null) {
            _hashCode += getText_de().hashCode();
        }
        if (getText_en() != null) {
            _hashCode += getText_en().hashCode();
        }
        if (getText_es() != null) {
            _hashCode += getText_es().hashCode();
        }
        if (getText_fr() != null) {
            _hashCode += getText_fr().hashCode();
        }
        if (getText_it() != null) {
            _hashCode += getText_it().hashCode();
        }
        if (getText_ja() != null) {
            _hashCode += getText_ja().hashCode();
        }
        if (getText_pt() != null) {
            _hashCode += getText_pt().hashCode();
        }
        if (getValid_from() != null) {
            _hashCode += getValid_from().hashCode();
        }
        if (getValid_until() != null) {
            _hashCode += getValid_until().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(News_rec.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://aspera.com/wsdl/", "news_rec"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("news_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "news_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("import_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "import_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("data_source_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "data_source_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("news_type");
        elemField.setXmlName(new javax.xml.namespace.QName("", "news_type"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("subject_de");
        elemField.setXmlName(new javax.xml.namespace.QName("", "subject_de"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("subject_en");
        elemField.setXmlName(new javax.xml.namespace.QName("", "subject_en"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("subject_es");
        elemField.setXmlName(new javax.xml.namespace.QName("", "subject_es"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("subject_fr");
        elemField.setXmlName(new javax.xml.namespace.QName("", "subject_fr"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("subject_it");
        elemField.setXmlName(new javax.xml.namespace.QName("", "subject_it"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("subject_ja");
        elemField.setXmlName(new javax.xml.namespace.QName("", "subject_ja"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("subject_pt");
        elemField.setXmlName(new javax.xml.namespace.QName("", "subject_pt"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("text_de");
        elemField.setXmlName(new javax.xml.namespace.QName("", "text_de"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("text_en");
        elemField.setXmlName(new javax.xml.namespace.QName("", "text_en"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("text_es");
        elemField.setXmlName(new javax.xml.namespace.QName("", "text_es"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("text_fr");
        elemField.setXmlName(new javax.xml.namespace.QName("", "text_fr"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("text_it");
        elemField.setXmlName(new javax.xml.namespace.QName("", "text_it"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("text_ja");
        elemField.setXmlName(new javax.xml.namespace.QName("", "text_ja"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("text_pt");
        elemField.setXmlName(new javax.xml.namespace.QName("", "text_pt"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("valid_from");
        elemField.setXmlName(new javax.xml.namespace.QName("", "valid_from"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("valid_until");
        elemField.setXmlName(new javax.xml.namespace.QName("", "valid_until"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}

/**
 * Signature_file_rec.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ca.usm.plugins.samples.resourceplugin.sam.ws.proxy;

public class Signature_file_rec  implements java.io.Serializable {
    private int signature_file_id;

    private java.lang.String import_id;

    private int data_source_id;

    private java.lang.String file_name;

    private java.lang.String file_size;

    private java.lang.String file_path;

    private java.lang.String publisher;

    private java.lang.String product;

    private java.lang.String product_version;

    private int product_id;

    private java.lang.String remarks;

    private boolean ignore_usage;

    private int signature_status_id;

    private int clearing_responsible_id;

    private java.lang.String clearing_remarks;

    public Signature_file_rec() {
    }

    public Signature_file_rec(
           int signature_file_id,
           java.lang.String import_id,
           int data_source_id,
           java.lang.String file_name,
           java.lang.String file_size,
           java.lang.String file_path,
           java.lang.String publisher,
           java.lang.String product,
           java.lang.String product_version,
           int product_id,
           java.lang.String remarks,
           boolean ignore_usage,
           int signature_status_id,
           int clearing_responsible_id,
           java.lang.String clearing_remarks) {
           this.signature_file_id = signature_file_id;
           this.import_id = import_id;
           this.data_source_id = data_source_id;
           this.file_name = file_name;
           this.file_size = file_size;
           this.file_path = file_path;
           this.publisher = publisher;
           this.product = product;
           this.product_version = product_version;
           this.product_id = product_id;
           this.remarks = remarks;
           this.ignore_usage = ignore_usage;
           this.signature_status_id = signature_status_id;
           this.clearing_responsible_id = clearing_responsible_id;
           this.clearing_remarks = clearing_remarks;
    }


    /**
     * Gets the signature_file_id value for this Signature_file_rec.
     * 
     * @return signature_file_id
     */
    public int getSignature_file_id() {
        return signature_file_id;
    }


    /**
     * Sets the signature_file_id value for this Signature_file_rec.
     * 
     * @param signature_file_id
     */
    public void setSignature_file_id(int signature_file_id) {
        this.signature_file_id = signature_file_id;
    }


    /**
     * Gets the import_id value for this Signature_file_rec.
     * 
     * @return import_id
     */
    public java.lang.String getImport_id() {
        return import_id;
    }


    /**
     * Sets the import_id value for this Signature_file_rec.
     * 
     * @param import_id
     */
    public void setImport_id(java.lang.String import_id) {
        this.import_id = import_id;
    }


    /**
     * Gets the data_source_id value for this Signature_file_rec.
     * 
     * @return data_source_id
     */
    public int getData_source_id() {
        return data_source_id;
    }


    /**
     * Sets the data_source_id value for this Signature_file_rec.
     * 
     * @param data_source_id
     */
    public void setData_source_id(int data_source_id) {
        this.data_source_id = data_source_id;
    }


    /**
     * Gets the file_name value for this Signature_file_rec.
     * 
     * @return file_name
     */
    public java.lang.String getFile_name() {
        return file_name;
    }


    /**
     * Sets the file_name value for this Signature_file_rec.
     * 
     * @param file_name
     */
    public void setFile_name(java.lang.String file_name) {
        this.file_name = file_name;
    }


    /**
     * Gets the file_size value for this Signature_file_rec.
     * 
     * @return file_size
     */
    public java.lang.String getFile_size() {
        return file_size;
    }


    /**
     * Sets the file_size value for this Signature_file_rec.
     * 
     * @param file_size
     */
    public void setFile_size(java.lang.String file_size) {
        this.file_size = file_size;
    }


    /**
     * Gets the file_path value for this Signature_file_rec.
     * 
     * @return file_path
     */
    public java.lang.String getFile_path() {
        return file_path;
    }


    /**
     * Sets the file_path value for this Signature_file_rec.
     * 
     * @param file_path
     */
    public void setFile_path(java.lang.String file_path) {
        this.file_path = file_path;
    }


    /**
     * Gets the publisher value for this Signature_file_rec.
     * 
     * @return publisher
     */
    public java.lang.String getPublisher() {
        return publisher;
    }


    /**
     * Sets the publisher value for this Signature_file_rec.
     * 
     * @param publisher
     */
    public void setPublisher(java.lang.String publisher) {
        this.publisher = publisher;
    }


    /**
     * Gets the product value for this Signature_file_rec.
     * 
     * @return product
     */
    public java.lang.String getProduct() {
        return product;
    }


    /**
     * Sets the product value for this Signature_file_rec.
     * 
     * @param product
     */
    public void setProduct(java.lang.String product) {
        this.product = product;
    }


    /**
     * Gets the product_version value for this Signature_file_rec.
     * 
     * @return product_version
     */
    public java.lang.String getProduct_version() {
        return product_version;
    }


    /**
     * Sets the product_version value for this Signature_file_rec.
     * 
     * @param product_version
     */
    public void setProduct_version(java.lang.String product_version) {
        this.product_version = product_version;
    }


    /**
     * Gets the product_id value for this Signature_file_rec.
     * 
     * @return product_id
     */
    public int getProduct_id() {
        return product_id;
    }


    /**
     * Sets the product_id value for this Signature_file_rec.
     * 
     * @param product_id
     */
    public void setProduct_id(int product_id) {
        this.product_id = product_id;
    }


    /**
     * Gets the remarks value for this Signature_file_rec.
     * 
     * @return remarks
     */
    public java.lang.String getRemarks() {
        return remarks;
    }


    /**
     * Sets the remarks value for this Signature_file_rec.
     * 
     * @param remarks
     */
    public void setRemarks(java.lang.String remarks) {
        this.remarks = remarks;
    }


    /**
     * Gets the ignore_usage value for this Signature_file_rec.
     * 
     * @return ignore_usage
     */
    public boolean isIgnore_usage() {
        return ignore_usage;
    }


    /**
     * Sets the ignore_usage value for this Signature_file_rec.
     * 
     * @param ignore_usage
     */
    public void setIgnore_usage(boolean ignore_usage) {
        this.ignore_usage = ignore_usage;
    }


    /**
     * Gets the signature_status_id value for this Signature_file_rec.
     * 
     * @return signature_status_id
     */
    public int getSignature_status_id() {
        return signature_status_id;
    }


    /**
     * Sets the signature_status_id value for this Signature_file_rec.
     * 
     * @param signature_status_id
     */
    public void setSignature_status_id(int signature_status_id) {
        this.signature_status_id = signature_status_id;
    }


    /**
     * Gets the clearing_responsible_id value for this Signature_file_rec.
     * 
     * @return clearing_responsible_id
     */
    public int getClearing_responsible_id() {
        return clearing_responsible_id;
    }


    /**
     * Sets the clearing_responsible_id value for this Signature_file_rec.
     * 
     * @param clearing_responsible_id
     */
    public void setClearing_responsible_id(int clearing_responsible_id) {
        this.clearing_responsible_id = clearing_responsible_id;
    }


    /**
     * Gets the clearing_remarks value for this Signature_file_rec.
     * 
     * @return clearing_remarks
     */
    public java.lang.String getClearing_remarks() {
        return clearing_remarks;
    }


    /**
     * Sets the clearing_remarks value for this Signature_file_rec.
     * 
     * @param clearing_remarks
     */
    public void setClearing_remarks(java.lang.String clearing_remarks) {
        this.clearing_remarks = clearing_remarks;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Signature_file_rec)) return false;
        Signature_file_rec other = (Signature_file_rec) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            this.signature_file_id == other.getSignature_file_id() &&
            ((this.import_id==null && other.getImport_id()==null) || 
             (this.import_id!=null &&
              this.import_id.equals(other.getImport_id()))) &&
            this.data_source_id == other.getData_source_id() &&
            ((this.file_name==null && other.getFile_name()==null) || 
             (this.file_name!=null &&
              this.file_name.equals(other.getFile_name()))) &&
            ((this.file_size==null && other.getFile_size()==null) || 
             (this.file_size!=null &&
              this.file_size.equals(other.getFile_size()))) &&
            ((this.file_path==null && other.getFile_path()==null) || 
             (this.file_path!=null &&
              this.file_path.equals(other.getFile_path()))) &&
            ((this.publisher==null && other.getPublisher()==null) || 
             (this.publisher!=null &&
              this.publisher.equals(other.getPublisher()))) &&
            ((this.product==null && other.getProduct()==null) || 
             (this.product!=null &&
              this.product.equals(other.getProduct()))) &&
            ((this.product_version==null && other.getProduct_version()==null) || 
             (this.product_version!=null &&
              this.product_version.equals(other.getProduct_version()))) &&
            this.product_id == other.getProduct_id() &&
            ((this.remarks==null && other.getRemarks()==null) || 
             (this.remarks!=null &&
              this.remarks.equals(other.getRemarks()))) &&
            this.ignore_usage == other.isIgnore_usage() &&
            this.signature_status_id == other.getSignature_status_id() &&
            this.clearing_responsible_id == other.getClearing_responsible_id() &&
            ((this.clearing_remarks==null && other.getClearing_remarks()==null) || 
             (this.clearing_remarks!=null &&
              this.clearing_remarks.equals(other.getClearing_remarks())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        _hashCode += getSignature_file_id();
        if (getImport_id() != null) {
            _hashCode += getImport_id().hashCode();
        }
        _hashCode += getData_source_id();
        if (getFile_name() != null) {
            _hashCode += getFile_name().hashCode();
        }
        if (getFile_size() != null) {
            _hashCode += getFile_size().hashCode();
        }
        if (getFile_path() != null) {
            _hashCode += getFile_path().hashCode();
        }
        if (getPublisher() != null) {
            _hashCode += getPublisher().hashCode();
        }
        if (getProduct() != null) {
            _hashCode += getProduct().hashCode();
        }
        if (getProduct_version() != null) {
            _hashCode += getProduct_version().hashCode();
        }
        _hashCode += getProduct_id();
        if (getRemarks() != null) {
            _hashCode += getRemarks().hashCode();
        }
        _hashCode += (isIgnore_usage() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        _hashCode += getSignature_status_id();
        _hashCode += getClearing_responsible_id();
        if (getClearing_remarks() != null) {
            _hashCode += getClearing_remarks().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Signature_file_rec.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://aspera.com/wsdl/", "signature_file_rec"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("signature_file_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "signature_file_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("import_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "import_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("data_source_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "data_source_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("file_name");
        elemField.setXmlName(new javax.xml.namespace.QName("", "file_name"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("file_size");
        elemField.setXmlName(new javax.xml.namespace.QName("", "file_size"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("file_path");
        elemField.setXmlName(new javax.xml.namespace.QName("", "file_path"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("publisher");
        elemField.setXmlName(new javax.xml.namespace.QName("", "publisher"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("product");
        elemField.setXmlName(new javax.xml.namespace.QName("", "product"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("product_version");
        elemField.setXmlName(new javax.xml.namespace.QName("", "product_version"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("product_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "product_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("remarks");
        elemField.setXmlName(new javax.xml.namespace.QName("", "remarks"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ignore_usage");
        elemField.setXmlName(new javax.xml.namespace.QName("", "ignore_usage"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("signature_status_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "signature_status_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("clearing_responsible_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "clearing_responsible_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("clearing_remarks");
        elemField.setXmlName(new javax.xml.namespace.QName("", "clearing_remarks"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}

/**
 * Signature_tag_rec.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ca.usm.plugins.samples.resourceplugin.sam.ws.proxy;

public class Signature_tag_rec  implements java.io.Serializable {
    private int signature_tag_id;

    private java.lang.String import_id;

    private int data_source_id;

    private java.lang.String software_unique_id;

    private java.lang.String product_title;

    private java.lang.String product_ver_name;

    private java.lang.String product_ver_major;

    private java.lang.String product_ver_minor;

    private java.lang.String manufacturer_name;

    private java.lang.String manufacturer_guid;

    private java.lang.String license_req;

    private java.lang.String activation_status;

    private java.lang.String channel_type;

    private java.lang.String supported_languages;

    private int product_id;

    private java.lang.String remarks;

    private boolean ignore_usage;

    private int signature_status_id;

    private int clearing_responsible_id;

    private java.lang.String clearing_remarks;

    public Signature_tag_rec() {
    }

    public Signature_tag_rec(
           int signature_tag_id,
           java.lang.String import_id,
           int data_source_id,
           java.lang.String software_unique_id,
           java.lang.String product_title,
           java.lang.String product_ver_name,
           java.lang.String product_ver_major,
           java.lang.String product_ver_minor,
           java.lang.String manufacturer_name,
           java.lang.String manufacturer_guid,
           java.lang.String license_req,
           java.lang.String activation_status,
           java.lang.String channel_type,
           java.lang.String supported_languages,
           int product_id,
           java.lang.String remarks,
           boolean ignore_usage,
           int signature_status_id,
           int clearing_responsible_id,
           java.lang.String clearing_remarks) {
           this.signature_tag_id = signature_tag_id;
           this.import_id = import_id;
           this.data_source_id = data_source_id;
           this.software_unique_id = software_unique_id;
           this.product_title = product_title;
           this.product_ver_name = product_ver_name;
           this.product_ver_major = product_ver_major;
           this.product_ver_minor = product_ver_minor;
           this.manufacturer_name = manufacturer_name;
           this.manufacturer_guid = manufacturer_guid;
           this.license_req = license_req;
           this.activation_status = activation_status;
           this.channel_type = channel_type;
           this.supported_languages = supported_languages;
           this.product_id = product_id;
           this.remarks = remarks;
           this.ignore_usage = ignore_usage;
           this.signature_status_id = signature_status_id;
           this.clearing_responsible_id = clearing_responsible_id;
           this.clearing_remarks = clearing_remarks;
    }


    /**
     * Gets the signature_tag_id value for this Signature_tag_rec.
     * 
     * @return signature_tag_id
     */
    public int getSignature_tag_id() {
        return signature_tag_id;
    }


    /**
     * Sets the signature_tag_id value for this Signature_tag_rec.
     * 
     * @param signature_tag_id
     */
    public void setSignature_tag_id(int signature_tag_id) {
        this.signature_tag_id = signature_tag_id;
    }


    /**
     * Gets the import_id value for this Signature_tag_rec.
     * 
     * @return import_id
     */
    public java.lang.String getImport_id() {
        return import_id;
    }


    /**
     * Sets the import_id value for this Signature_tag_rec.
     * 
     * @param import_id
     */
    public void setImport_id(java.lang.String import_id) {
        this.import_id = import_id;
    }


    /**
     * Gets the data_source_id value for this Signature_tag_rec.
     * 
     * @return data_source_id
     */
    public int getData_source_id() {
        return data_source_id;
    }


    /**
     * Sets the data_source_id value for this Signature_tag_rec.
     * 
     * @param data_source_id
     */
    public void setData_source_id(int data_source_id) {
        this.data_source_id = data_source_id;
    }


    /**
     * Gets the software_unique_id value for this Signature_tag_rec.
     * 
     * @return software_unique_id
     */
    public java.lang.String getSoftware_unique_id() {
        return software_unique_id;
    }


    /**
     * Sets the software_unique_id value for this Signature_tag_rec.
     * 
     * @param software_unique_id
     */
    public void setSoftware_unique_id(java.lang.String software_unique_id) {
        this.software_unique_id = software_unique_id;
    }


    /**
     * Gets the product_title value for this Signature_tag_rec.
     * 
     * @return product_title
     */
    public java.lang.String getProduct_title() {
        return product_title;
    }


    /**
     * Sets the product_title value for this Signature_tag_rec.
     * 
     * @param product_title
     */
    public void setProduct_title(java.lang.String product_title) {
        this.product_title = product_title;
    }


    /**
     * Gets the product_ver_name value for this Signature_tag_rec.
     * 
     * @return product_ver_name
     */
    public java.lang.String getProduct_ver_name() {
        return product_ver_name;
    }


    /**
     * Sets the product_ver_name value for this Signature_tag_rec.
     * 
     * @param product_ver_name
     */
    public void setProduct_ver_name(java.lang.String product_ver_name) {
        this.product_ver_name = product_ver_name;
    }


    /**
     * Gets the product_ver_major value for this Signature_tag_rec.
     * 
     * @return product_ver_major
     */
    public java.lang.String getProduct_ver_major() {
        return product_ver_major;
    }


    /**
     * Sets the product_ver_major value for this Signature_tag_rec.
     * 
     * @param product_ver_major
     */
    public void setProduct_ver_major(java.lang.String product_ver_major) {
        this.product_ver_major = product_ver_major;
    }


    /**
     * Gets the product_ver_minor value for this Signature_tag_rec.
     * 
     * @return product_ver_minor
     */
    public java.lang.String getProduct_ver_minor() {
        return product_ver_minor;
    }


    /**
     * Sets the product_ver_minor value for this Signature_tag_rec.
     * 
     * @param product_ver_minor
     */
    public void setProduct_ver_minor(java.lang.String product_ver_minor) {
        this.product_ver_minor = product_ver_minor;
    }


    /**
     * Gets the manufacturer_name value for this Signature_tag_rec.
     * 
     * @return manufacturer_name
     */
    public java.lang.String getManufacturer_name() {
        return manufacturer_name;
    }


    /**
     * Sets the manufacturer_name value for this Signature_tag_rec.
     * 
     * @param manufacturer_name
     */
    public void setManufacturer_name(java.lang.String manufacturer_name) {
        this.manufacturer_name = manufacturer_name;
    }


    /**
     * Gets the manufacturer_guid value for this Signature_tag_rec.
     * 
     * @return manufacturer_guid
     */
    public java.lang.String getManufacturer_guid() {
        return manufacturer_guid;
    }


    /**
     * Sets the manufacturer_guid value for this Signature_tag_rec.
     * 
     * @param manufacturer_guid
     */
    public void setManufacturer_guid(java.lang.String manufacturer_guid) {
        this.manufacturer_guid = manufacturer_guid;
    }


    /**
     * Gets the license_req value for this Signature_tag_rec.
     * 
     * @return license_req
     */
    public java.lang.String getLicense_req() {
        return license_req;
    }


    /**
     * Sets the license_req value for this Signature_tag_rec.
     * 
     * @param license_req
     */
    public void setLicense_req(java.lang.String license_req) {
        this.license_req = license_req;
    }


    /**
     * Gets the activation_status value for this Signature_tag_rec.
     * 
     * @return activation_status
     */
    public java.lang.String getActivation_status() {
        return activation_status;
    }


    /**
     * Sets the activation_status value for this Signature_tag_rec.
     * 
     * @param activation_status
     */
    public void setActivation_status(java.lang.String activation_status) {
        this.activation_status = activation_status;
    }


    /**
     * Gets the channel_type value for this Signature_tag_rec.
     * 
     * @return channel_type
     */
    public java.lang.String getChannel_type() {
        return channel_type;
    }


    /**
     * Sets the channel_type value for this Signature_tag_rec.
     * 
     * @param channel_type
     */
    public void setChannel_type(java.lang.String channel_type) {
        this.channel_type = channel_type;
    }


    /**
     * Gets the supported_languages value for this Signature_tag_rec.
     * 
     * @return supported_languages
     */
    public java.lang.String getSupported_languages() {
        return supported_languages;
    }


    /**
     * Sets the supported_languages value for this Signature_tag_rec.
     * 
     * @param supported_languages
     */
    public void setSupported_languages(java.lang.String supported_languages) {
        this.supported_languages = supported_languages;
    }


    /**
     * Gets the product_id value for this Signature_tag_rec.
     * 
     * @return product_id
     */
    public int getProduct_id() {
        return product_id;
    }


    /**
     * Sets the product_id value for this Signature_tag_rec.
     * 
     * @param product_id
     */
    public void setProduct_id(int product_id) {
        this.product_id = product_id;
    }


    /**
     * Gets the remarks value for this Signature_tag_rec.
     * 
     * @return remarks
     */
    public java.lang.String getRemarks() {
        return remarks;
    }


    /**
     * Sets the remarks value for this Signature_tag_rec.
     * 
     * @param remarks
     */
    public void setRemarks(java.lang.String remarks) {
        this.remarks = remarks;
    }


    /**
     * Gets the ignore_usage value for this Signature_tag_rec.
     * 
     * @return ignore_usage
     */
    public boolean isIgnore_usage() {
        return ignore_usage;
    }


    /**
     * Sets the ignore_usage value for this Signature_tag_rec.
     * 
     * @param ignore_usage
     */
    public void setIgnore_usage(boolean ignore_usage) {
        this.ignore_usage = ignore_usage;
    }


    /**
     * Gets the signature_status_id value for this Signature_tag_rec.
     * 
     * @return signature_status_id
     */
    public int getSignature_status_id() {
        return signature_status_id;
    }


    /**
     * Sets the signature_status_id value for this Signature_tag_rec.
     * 
     * @param signature_status_id
     */
    public void setSignature_status_id(int signature_status_id) {
        this.signature_status_id = signature_status_id;
    }


    /**
     * Gets the clearing_responsible_id value for this Signature_tag_rec.
     * 
     * @return clearing_responsible_id
     */
    public int getClearing_responsible_id() {
        return clearing_responsible_id;
    }


    /**
     * Sets the clearing_responsible_id value for this Signature_tag_rec.
     * 
     * @param clearing_responsible_id
     */
    public void setClearing_responsible_id(int clearing_responsible_id) {
        this.clearing_responsible_id = clearing_responsible_id;
    }


    /**
     * Gets the clearing_remarks value for this Signature_tag_rec.
     * 
     * @return clearing_remarks
     */
    public java.lang.String getClearing_remarks() {
        return clearing_remarks;
    }


    /**
     * Sets the clearing_remarks value for this Signature_tag_rec.
     * 
     * @param clearing_remarks
     */
    public void setClearing_remarks(java.lang.String clearing_remarks) {
        this.clearing_remarks = clearing_remarks;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Signature_tag_rec)) return false;
        Signature_tag_rec other = (Signature_tag_rec) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            this.signature_tag_id == other.getSignature_tag_id() &&
            ((this.import_id==null && other.getImport_id()==null) || 
             (this.import_id!=null &&
              this.import_id.equals(other.getImport_id()))) &&
            this.data_source_id == other.getData_source_id() &&
            ((this.software_unique_id==null && other.getSoftware_unique_id()==null) || 
             (this.software_unique_id!=null &&
              this.software_unique_id.equals(other.getSoftware_unique_id()))) &&
            ((this.product_title==null && other.getProduct_title()==null) || 
             (this.product_title!=null &&
              this.product_title.equals(other.getProduct_title()))) &&
            ((this.product_ver_name==null && other.getProduct_ver_name()==null) || 
             (this.product_ver_name!=null &&
              this.product_ver_name.equals(other.getProduct_ver_name()))) &&
            ((this.product_ver_major==null && other.getProduct_ver_major()==null) || 
             (this.product_ver_major!=null &&
              this.product_ver_major.equals(other.getProduct_ver_major()))) &&
            ((this.product_ver_minor==null && other.getProduct_ver_minor()==null) || 
             (this.product_ver_minor!=null &&
              this.product_ver_minor.equals(other.getProduct_ver_minor()))) &&
            ((this.manufacturer_name==null && other.getManufacturer_name()==null) || 
             (this.manufacturer_name!=null &&
              this.manufacturer_name.equals(other.getManufacturer_name()))) &&
            ((this.manufacturer_guid==null && other.getManufacturer_guid()==null) || 
             (this.manufacturer_guid!=null &&
              this.manufacturer_guid.equals(other.getManufacturer_guid()))) &&
            ((this.license_req==null && other.getLicense_req()==null) || 
             (this.license_req!=null &&
              this.license_req.equals(other.getLicense_req()))) &&
            ((this.activation_status==null && other.getActivation_status()==null) || 
             (this.activation_status!=null &&
              this.activation_status.equals(other.getActivation_status()))) &&
            ((this.channel_type==null && other.getChannel_type()==null) || 
             (this.channel_type!=null &&
              this.channel_type.equals(other.getChannel_type()))) &&
            ((this.supported_languages==null && other.getSupported_languages()==null) || 
             (this.supported_languages!=null &&
              this.supported_languages.equals(other.getSupported_languages()))) &&
            this.product_id == other.getProduct_id() &&
            ((this.remarks==null && other.getRemarks()==null) || 
             (this.remarks!=null &&
              this.remarks.equals(other.getRemarks()))) &&
            this.ignore_usage == other.isIgnore_usage() &&
            this.signature_status_id == other.getSignature_status_id() &&
            this.clearing_responsible_id == other.getClearing_responsible_id() &&
            ((this.clearing_remarks==null && other.getClearing_remarks()==null) || 
             (this.clearing_remarks!=null &&
              this.clearing_remarks.equals(other.getClearing_remarks())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        _hashCode += getSignature_tag_id();
        if (getImport_id() != null) {
            _hashCode += getImport_id().hashCode();
        }
        _hashCode += getData_source_id();
        if (getSoftware_unique_id() != null) {
            _hashCode += getSoftware_unique_id().hashCode();
        }
        if (getProduct_title() != null) {
            _hashCode += getProduct_title().hashCode();
        }
        if (getProduct_ver_name() != null) {
            _hashCode += getProduct_ver_name().hashCode();
        }
        if (getProduct_ver_major() != null) {
            _hashCode += getProduct_ver_major().hashCode();
        }
        if (getProduct_ver_minor() != null) {
            _hashCode += getProduct_ver_minor().hashCode();
        }
        if (getManufacturer_name() != null) {
            _hashCode += getManufacturer_name().hashCode();
        }
        if (getManufacturer_guid() != null) {
            _hashCode += getManufacturer_guid().hashCode();
        }
        if (getLicense_req() != null) {
            _hashCode += getLicense_req().hashCode();
        }
        if (getActivation_status() != null) {
            _hashCode += getActivation_status().hashCode();
        }
        if (getChannel_type() != null) {
            _hashCode += getChannel_type().hashCode();
        }
        if (getSupported_languages() != null) {
            _hashCode += getSupported_languages().hashCode();
        }
        _hashCode += getProduct_id();
        if (getRemarks() != null) {
            _hashCode += getRemarks().hashCode();
        }
        _hashCode += (isIgnore_usage() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        _hashCode += getSignature_status_id();
        _hashCode += getClearing_responsible_id();
        if (getClearing_remarks() != null) {
            _hashCode += getClearing_remarks().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Signature_tag_rec.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://aspera.com/wsdl/", "signature_tag_rec"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("signature_tag_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "signature_tag_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("import_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "import_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("data_source_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "data_source_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("software_unique_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "software_unique_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("product_title");
        elemField.setXmlName(new javax.xml.namespace.QName("", "product_title"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("product_ver_name");
        elemField.setXmlName(new javax.xml.namespace.QName("", "product_ver_name"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("product_ver_major");
        elemField.setXmlName(new javax.xml.namespace.QName("", "product_ver_major"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("product_ver_minor");
        elemField.setXmlName(new javax.xml.namespace.QName("", "product_ver_minor"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("manufacturer_name");
        elemField.setXmlName(new javax.xml.namespace.QName("", "manufacturer_name"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("manufacturer_guid");
        elemField.setXmlName(new javax.xml.namespace.QName("", "manufacturer_guid"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("license_req");
        elemField.setXmlName(new javax.xml.namespace.QName("", "license_req"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("activation_status");
        elemField.setXmlName(new javax.xml.namespace.QName("", "activation_status"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("channel_type");
        elemField.setXmlName(new javax.xml.namespace.QName("", "channel_type"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("supported_languages");
        elemField.setXmlName(new javax.xml.namespace.QName("", "supported_languages"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("product_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "product_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("remarks");
        elemField.setXmlName(new javax.xml.namespace.QName("", "remarks"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ignore_usage");
        elemField.setXmlName(new javax.xml.namespace.QName("", "ignore_usage"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("signature_status_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "signature_status_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("clearing_responsible_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "clearing_responsible_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("clearing_remarks");
        elemField.setXmlName(new javax.xml.namespace.QName("", "clearing_remarks"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}

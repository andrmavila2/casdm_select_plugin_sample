/**
 * Expenditure_rec.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ca.usm.plugins.samples.resourceplugin.sam.ws.proxy;

public class Expenditure_rec  implements java.io.Serializable {
    private int expenditure_id;

    private java.lang.String import_id;

    private int data_source_id;

    private int contract_id;

    private int enrolment_id;

    private java.lang.String order_no;

    private java.lang.String order_item;

    private java.lang.String expenditure_date;

    private int org_level_2_id;

    private java.lang.String amount;

    private int currency_id;

    private java.lang.String description;

    private int expenditure_type_id;

    private int project_id;

    private int cost_key_id;

    private java.math.BigInteger depreciation;

    private java.lang.String depreciation_start;

    private java.lang.String expenditure_status;

    public Expenditure_rec() {
    }

    public Expenditure_rec(
           int expenditure_id,
           java.lang.String import_id,
           int data_source_id,
           int contract_id,
           int enrolment_id,
           java.lang.String order_no,
           java.lang.String order_item,
           java.lang.String expenditure_date,
           int org_level_2_id,
           java.lang.String amount,
           int currency_id,
           java.lang.String description,
           int expenditure_type_id,
           int project_id,
           int cost_key_id,
           java.math.BigInteger depreciation,
           java.lang.String depreciation_start,
           java.lang.String expenditure_status) {
           this.expenditure_id = expenditure_id;
           this.import_id = import_id;
           this.data_source_id = data_source_id;
           this.contract_id = contract_id;
           this.enrolment_id = enrolment_id;
           this.order_no = order_no;
           this.order_item = order_item;
           this.expenditure_date = expenditure_date;
           this.org_level_2_id = org_level_2_id;
           this.amount = amount;
           this.currency_id = currency_id;
           this.description = description;
           this.expenditure_type_id = expenditure_type_id;
           this.project_id = project_id;
           this.cost_key_id = cost_key_id;
           this.depreciation = depreciation;
           this.depreciation_start = depreciation_start;
           this.expenditure_status = expenditure_status;
    }


    /**
     * Gets the expenditure_id value for this Expenditure_rec.
     * 
     * @return expenditure_id
     */
    public int getExpenditure_id() {
        return expenditure_id;
    }


    /**
     * Sets the expenditure_id value for this Expenditure_rec.
     * 
     * @param expenditure_id
     */
    public void setExpenditure_id(int expenditure_id) {
        this.expenditure_id = expenditure_id;
    }


    /**
     * Gets the import_id value for this Expenditure_rec.
     * 
     * @return import_id
     */
    public java.lang.String getImport_id() {
        return import_id;
    }


    /**
     * Sets the import_id value for this Expenditure_rec.
     * 
     * @param import_id
     */
    public void setImport_id(java.lang.String import_id) {
        this.import_id = import_id;
    }


    /**
     * Gets the data_source_id value for this Expenditure_rec.
     * 
     * @return data_source_id
     */
    public int getData_source_id() {
        return data_source_id;
    }


    /**
     * Sets the data_source_id value for this Expenditure_rec.
     * 
     * @param data_source_id
     */
    public void setData_source_id(int data_source_id) {
        this.data_source_id = data_source_id;
    }


    /**
     * Gets the contract_id value for this Expenditure_rec.
     * 
     * @return contract_id
     */
    public int getContract_id() {
        return contract_id;
    }


    /**
     * Sets the contract_id value for this Expenditure_rec.
     * 
     * @param contract_id
     */
    public void setContract_id(int contract_id) {
        this.contract_id = contract_id;
    }


    /**
     * Gets the enrolment_id value for this Expenditure_rec.
     * 
     * @return enrolment_id
     */
    public int getEnrolment_id() {
        return enrolment_id;
    }


    /**
     * Sets the enrolment_id value for this Expenditure_rec.
     * 
     * @param enrolment_id
     */
    public void setEnrolment_id(int enrolment_id) {
        this.enrolment_id = enrolment_id;
    }


    /**
     * Gets the order_no value for this Expenditure_rec.
     * 
     * @return order_no
     */
    public java.lang.String getOrder_no() {
        return order_no;
    }


    /**
     * Sets the order_no value for this Expenditure_rec.
     * 
     * @param order_no
     */
    public void setOrder_no(java.lang.String order_no) {
        this.order_no = order_no;
    }


    /**
     * Gets the order_item value for this Expenditure_rec.
     * 
     * @return order_item
     */
    public java.lang.String getOrder_item() {
        return order_item;
    }


    /**
     * Sets the order_item value for this Expenditure_rec.
     * 
     * @param order_item
     */
    public void setOrder_item(java.lang.String order_item) {
        this.order_item = order_item;
    }


    /**
     * Gets the expenditure_date value for this Expenditure_rec.
     * 
     * @return expenditure_date
     */
    public java.lang.String getExpenditure_date() {
        return expenditure_date;
    }


    /**
     * Sets the expenditure_date value for this Expenditure_rec.
     * 
     * @param expenditure_date
     */
    public void setExpenditure_date(java.lang.String expenditure_date) {
        this.expenditure_date = expenditure_date;
    }


    /**
     * Gets the org_level_2_id value for this Expenditure_rec.
     * 
     * @return org_level_2_id
     */
    public int getOrg_level_2_id() {
        return org_level_2_id;
    }


    /**
     * Sets the org_level_2_id value for this Expenditure_rec.
     * 
     * @param org_level_2_id
     */
    public void setOrg_level_2_id(int org_level_2_id) {
        this.org_level_2_id = org_level_2_id;
    }


    /**
     * Gets the amount value for this Expenditure_rec.
     * 
     * @return amount
     */
    public java.lang.String getAmount() {
        return amount;
    }


    /**
     * Sets the amount value for this Expenditure_rec.
     * 
     * @param amount
     */
    public void setAmount(java.lang.String amount) {
        this.amount = amount;
    }


    /**
     * Gets the currency_id value for this Expenditure_rec.
     * 
     * @return currency_id
     */
    public int getCurrency_id() {
        return currency_id;
    }


    /**
     * Sets the currency_id value for this Expenditure_rec.
     * 
     * @param currency_id
     */
    public void setCurrency_id(int currency_id) {
        this.currency_id = currency_id;
    }


    /**
     * Gets the description value for this Expenditure_rec.
     * 
     * @return description
     */
    public java.lang.String getDescription() {
        return description;
    }


    /**
     * Sets the description value for this Expenditure_rec.
     * 
     * @param description
     */
    public void setDescription(java.lang.String description) {
        this.description = description;
    }


    /**
     * Gets the expenditure_type_id value for this Expenditure_rec.
     * 
     * @return expenditure_type_id
     */
    public int getExpenditure_type_id() {
        return expenditure_type_id;
    }


    /**
     * Sets the expenditure_type_id value for this Expenditure_rec.
     * 
     * @param expenditure_type_id
     */
    public void setExpenditure_type_id(int expenditure_type_id) {
        this.expenditure_type_id = expenditure_type_id;
    }


    /**
     * Gets the project_id value for this Expenditure_rec.
     * 
     * @return project_id
     */
    public int getProject_id() {
        return project_id;
    }


    /**
     * Sets the project_id value for this Expenditure_rec.
     * 
     * @param project_id
     */
    public void setProject_id(int project_id) {
        this.project_id = project_id;
    }


    /**
     * Gets the cost_key_id value for this Expenditure_rec.
     * 
     * @return cost_key_id
     */
    public int getCost_key_id() {
        return cost_key_id;
    }


    /**
     * Sets the cost_key_id value for this Expenditure_rec.
     * 
     * @param cost_key_id
     */
    public void setCost_key_id(int cost_key_id) {
        this.cost_key_id = cost_key_id;
    }


    /**
     * Gets the depreciation value for this Expenditure_rec.
     * 
     * @return depreciation
     */
    public java.math.BigInteger getDepreciation() {
        return depreciation;
    }


    /**
     * Sets the depreciation value for this Expenditure_rec.
     * 
     * @param depreciation
     */
    public void setDepreciation(java.math.BigInteger depreciation) {
        this.depreciation = depreciation;
    }


    /**
     * Gets the depreciation_start value for this Expenditure_rec.
     * 
     * @return depreciation_start
     */
    public java.lang.String getDepreciation_start() {
        return depreciation_start;
    }


    /**
     * Sets the depreciation_start value for this Expenditure_rec.
     * 
     * @param depreciation_start
     */
    public void setDepreciation_start(java.lang.String depreciation_start) {
        this.depreciation_start = depreciation_start;
    }


    /**
     * Gets the expenditure_status value for this Expenditure_rec.
     * 
     * @return expenditure_status
     */
    public java.lang.String getExpenditure_status() {
        return expenditure_status;
    }


    /**
     * Sets the expenditure_status value for this Expenditure_rec.
     * 
     * @param expenditure_status
     */
    public void setExpenditure_status(java.lang.String expenditure_status) {
        this.expenditure_status = expenditure_status;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Expenditure_rec)) return false;
        Expenditure_rec other = (Expenditure_rec) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            this.expenditure_id == other.getExpenditure_id() &&
            ((this.import_id==null && other.getImport_id()==null) || 
             (this.import_id!=null &&
              this.import_id.equals(other.getImport_id()))) &&
            this.data_source_id == other.getData_source_id() &&
            this.contract_id == other.getContract_id() &&
            this.enrolment_id == other.getEnrolment_id() &&
            ((this.order_no==null && other.getOrder_no()==null) || 
             (this.order_no!=null &&
              this.order_no.equals(other.getOrder_no()))) &&
            ((this.order_item==null && other.getOrder_item()==null) || 
             (this.order_item!=null &&
              this.order_item.equals(other.getOrder_item()))) &&
            ((this.expenditure_date==null && other.getExpenditure_date()==null) || 
             (this.expenditure_date!=null &&
              this.expenditure_date.equals(other.getExpenditure_date()))) &&
            this.org_level_2_id == other.getOrg_level_2_id() &&
            ((this.amount==null && other.getAmount()==null) || 
             (this.amount!=null &&
              this.amount.equals(other.getAmount()))) &&
            this.currency_id == other.getCurrency_id() &&
            ((this.description==null && other.getDescription()==null) || 
             (this.description!=null &&
              this.description.equals(other.getDescription()))) &&
            this.expenditure_type_id == other.getExpenditure_type_id() &&
            this.project_id == other.getProject_id() &&
            this.cost_key_id == other.getCost_key_id() &&
            ((this.depreciation==null && other.getDepreciation()==null) || 
             (this.depreciation!=null &&
              this.depreciation.equals(other.getDepreciation()))) &&
            ((this.depreciation_start==null && other.getDepreciation_start()==null) || 
             (this.depreciation_start!=null &&
              this.depreciation_start.equals(other.getDepreciation_start()))) &&
            ((this.expenditure_status==null && other.getExpenditure_status()==null) || 
             (this.expenditure_status!=null &&
              this.expenditure_status.equals(other.getExpenditure_status())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        _hashCode += getExpenditure_id();
        if (getImport_id() != null) {
            _hashCode += getImport_id().hashCode();
        }
        _hashCode += getData_source_id();
        _hashCode += getContract_id();
        _hashCode += getEnrolment_id();
        if (getOrder_no() != null) {
            _hashCode += getOrder_no().hashCode();
        }
        if (getOrder_item() != null) {
            _hashCode += getOrder_item().hashCode();
        }
        if (getExpenditure_date() != null) {
            _hashCode += getExpenditure_date().hashCode();
        }
        _hashCode += getOrg_level_2_id();
        if (getAmount() != null) {
            _hashCode += getAmount().hashCode();
        }
        _hashCode += getCurrency_id();
        if (getDescription() != null) {
            _hashCode += getDescription().hashCode();
        }
        _hashCode += getExpenditure_type_id();
        _hashCode += getProject_id();
        _hashCode += getCost_key_id();
        if (getDepreciation() != null) {
            _hashCode += getDepreciation().hashCode();
        }
        if (getDepreciation_start() != null) {
            _hashCode += getDepreciation_start().hashCode();
        }
        if (getExpenditure_status() != null) {
            _hashCode += getExpenditure_status().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Expenditure_rec.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://aspera.com/wsdl/", "expenditure_rec"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("expenditure_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "expenditure_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("import_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "import_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("data_source_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "data_source_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("contract_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "contract_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("enrolment_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "enrolment_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("order_no");
        elemField.setXmlName(new javax.xml.namespace.QName("", "order_no"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("order_item");
        elemField.setXmlName(new javax.xml.namespace.QName("", "order_item"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("expenditure_date");
        elemField.setXmlName(new javax.xml.namespace.QName("", "expenditure_date"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("org_level_2_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "org_level_2_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("amount");
        elemField.setXmlName(new javax.xml.namespace.QName("", "amount"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("currency_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "currency_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("description");
        elemField.setXmlName(new javax.xml.namespace.QName("", "description"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("expenditure_type_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "expenditure_type_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("project_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "project_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("cost_key_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "cost_key_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("depreciation");
        elemField.setXmlName(new javax.xml.namespace.QName("", "depreciation"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("depreciation_start");
        elemField.setXmlName(new javax.xml.namespace.QName("", "depreciation_start"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("expenditure_status");
        elemField.setXmlName(new javax.xml.namespace.QName("", "expenditure_status"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}

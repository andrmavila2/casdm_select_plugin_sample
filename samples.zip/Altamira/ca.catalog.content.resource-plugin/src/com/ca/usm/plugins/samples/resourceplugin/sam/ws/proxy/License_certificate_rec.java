/**
 * License_certificate_rec.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ca.usm.plugins.samples.resourceplugin.sam.ws.proxy;

public class License_certificate_rec  implements java.io.Serializable {
    private int license_certificate_id;

    private java.lang.String import_id;

    private int data_source_id;

    private java.lang.String license_cert_number;

    private java.lang.String issue_date;

    private int org_level_0_id;

    private int org_level_1_id;

    private int org_level_2_id;

    private int manufacturer_id;

    private int supplier_id;

    private int location_id;

    private java.lang.String storage_location;

    private java.lang.String remarks;

    public License_certificate_rec() {
    }

    public License_certificate_rec(
           int license_certificate_id,
           java.lang.String import_id,
           int data_source_id,
           java.lang.String license_cert_number,
           java.lang.String issue_date,
           int org_level_0_id,
           int org_level_1_id,
           int org_level_2_id,
           int manufacturer_id,
           int supplier_id,
           int location_id,
           java.lang.String storage_location,
           java.lang.String remarks) {
           this.license_certificate_id = license_certificate_id;
           this.import_id = import_id;
           this.data_source_id = data_source_id;
           this.license_cert_number = license_cert_number;
           this.issue_date = issue_date;
           this.org_level_0_id = org_level_0_id;
           this.org_level_1_id = org_level_1_id;
           this.org_level_2_id = org_level_2_id;
           this.manufacturer_id = manufacturer_id;
           this.supplier_id = supplier_id;
           this.location_id = location_id;
           this.storage_location = storage_location;
           this.remarks = remarks;
    }


    /**
     * Gets the license_certificate_id value for this License_certificate_rec.
     * 
     * @return license_certificate_id
     */
    public int getLicense_certificate_id() {
        return license_certificate_id;
    }


    /**
     * Sets the license_certificate_id value for this License_certificate_rec.
     * 
     * @param license_certificate_id
     */
    public void setLicense_certificate_id(int license_certificate_id) {
        this.license_certificate_id = license_certificate_id;
    }


    /**
     * Gets the import_id value for this License_certificate_rec.
     * 
     * @return import_id
     */
    public java.lang.String getImport_id() {
        return import_id;
    }


    /**
     * Sets the import_id value for this License_certificate_rec.
     * 
     * @param import_id
     */
    public void setImport_id(java.lang.String import_id) {
        this.import_id = import_id;
    }


    /**
     * Gets the data_source_id value for this License_certificate_rec.
     * 
     * @return data_source_id
     */
    public int getData_source_id() {
        return data_source_id;
    }


    /**
     * Sets the data_source_id value for this License_certificate_rec.
     * 
     * @param data_source_id
     */
    public void setData_source_id(int data_source_id) {
        this.data_source_id = data_source_id;
    }


    /**
     * Gets the license_cert_number value for this License_certificate_rec.
     * 
     * @return license_cert_number
     */
    public java.lang.String getLicense_cert_number() {
        return license_cert_number;
    }


    /**
     * Sets the license_cert_number value for this License_certificate_rec.
     * 
     * @param license_cert_number
     */
    public void setLicense_cert_number(java.lang.String license_cert_number) {
        this.license_cert_number = license_cert_number;
    }


    /**
     * Gets the issue_date value for this License_certificate_rec.
     * 
     * @return issue_date
     */
    public java.lang.String getIssue_date() {
        return issue_date;
    }


    /**
     * Sets the issue_date value for this License_certificate_rec.
     * 
     * @param issue_date
     */
    public void setIssue_date(java.lang.String issue_date) {
        this.issue_date = issue_date;
    }


    /**
     * Gets the org_level_0_id value for this License_certificate_rec.
     * 
     * @return org_level_0_id
     */
    public int getOrg_level_0_id() {
        return org_level_0_id;
    }


    /**
     * Sets the org_level_0_id value for this License_certificate_rec.
     * 
     * @param org_level_0_id
     */
    public void setOrg_level_0_id(int org_level_0_id) {
        this.org_level_0_id = org_level_0_id;
    }


    /**
     * Gets the org_level_1_id value for this License_certificate_rec.
     * 
     * @return org_level_1_id
     */
    public int getOrg_level_1_id() {
        return org_level_1_id;
    }


    /**
     * Sets the org_level_1_id value for this License_certificate_rec.
     * 
     * @param org_level_1_id
     */
    public void setOrg_level_1_id(int org_level_1_id) {
        this.org_level_1_id = org_level_1_id;
    }


    /**
     * Gets the org_level_2_id value for this License_certificate_rec.
     * 
     * @return org_level_2_id
     */
    public int getOrg_level_2_id() {
        return org_level_2_id;
    }


    /**
     * Sets the org_level_2_id value for this License_certificate_rec.
     * 
     * @param org_level_2_id
     */
    public void setOrg_level_2_id(int org_level_2_id) {
        this.org_level_2_id = org_level_2_id;
    }


    /**
     * Gets the manufacturer_id value for this License_certificate_rec.
     * 
     * @return manufacturer_id
     */
    public int getManufacturer_id() {
        return manufacturer_id;
    }


    /**
     * Sets the manufacturer_id value for this License_certificate_rec.
     * 
     * @param manufacturer_id
     */
    public void setManufacturer_id(int manufacturer_id) {
        this.manufacturer_id = manufacturer_id;
    }


    /**
     * Gets the supplier_id value for this License_certificate_rec.
     * 
     * @return supplier_id
     */
    public int getSupplier_id() {
        return supplier_id;
    }


    /**
     * Sets the supplier_id value for this License_certificate_rec.
     * 
     * @param supplier_id
     */
    public void setSupplier_id(int supplier_id) {
        this.supplier_id = supplier_id;
    }


    /**
     * Gets the location_id value for this License_certificate_rec.
     * 
     * @return location_id
     */
    public int getLocation_id() {
        return location_id;
    }


    /**
     * Sets the location_id value for this License_certificate_rec.
     * 
     * @param location_id
     */
    public void setLocation_id(int location_id) {
        this.location_id = location_id;
    }


    /**
     * Gets the storage_location value for this License_certificate_rec.
     * 
     * @return storage_location
     */
    public java.lang.String getStorage_location() {
        return storage_location;
    }


    /**
     * Sets the storage_location value for this License_certificate_rec.
     * 
     * @param storage_location
     */
    public void setStorage_location(java.lang.String storage_location) {
        this.storage_location = storage_location;
    }


    /**
     * Gets the remarks value for this License_certificate_rec.
     * 
     * @return remarks
     */
    public java.lang.String getRemarks() {
        return remarks;
    }


    /**
     * Sets the remarks value for this License_certificate_rec.
     * 
     * @param remarks
     */
    public void setRemarks(java.lang.String remarks) {
        this.remarks = remarks;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof License_certificate_rec)) return false;
        License_certificate_rec other = (License_certificate_rec) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            this.license_certificate_id == other.getLicense_certificate_id() &&
            ((this.import_id==null && other.getImport_id()==null) || 
             (this.import_id!=null &&
              this.import_id.equals(other.getImport_id()))) &&
            this.data_source_id == other.getData_source_id() &&
            ((this.license_cert_number==null && other.getLicense_cert_number()==null) || 
             (this.license_cert_number!=null &&
              this.license_cert_number.equals(other.getLicense_cert_number()))) &&
            ((this.issue_date==null && other.getIssue_date()==null) || 
             (this.issue_date!=null &&
              this.issue_date.equals(other.getIssue_date()))) &&
            this.org_level_0_id == other.getOrg_level_0_id() &&
            this.org_level_1_id == other.getOrg_level_1_id() &&
            this.org_level_2_id == other.getOrg_level_2_id() &&
            this.manufacturer_id == other.getManufacturer_id() &&
            this.supplier_id == other.getSupplier_id() &&
            this.location_id == other.getLocation_id() &&
            ((this.storage_location==null && other.getStorage_location()==null) || 
             (this.storage_location!=null &&
              this.storage_location.equals(other.getStorage_location()))) &&
            ((this.remarks==null && other.getRemarks()==null) || 
             (this.remarks!=null &&
              this.remarks.equals(other.getRemarks())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        _hashCode += getLicense_certificate_id();
        if (getImport_id() != null) {
            _hashCode += getImport_id().hashCode();
        }
        _hashCode += getData_source_id();
        if (getLicense_cert_number() != null) {
            _hashCode += getLicense_cert_number().hashCode();
        }
        if (getIssue_date() != null) {
            _hashCode += getIssue_date().hashCode();
        }
        _hashCode += getOrg_level_0_id();
        _hashCode += getOrg_level_1_id();
        _hashCode += getOrg_level_2_id();
        _hashCode += getManufacturer_id();
        _hashCode += getSupplier_id();
        _hashCode += getLocation_id();
        if (getStorage_location() != null) {
            _hashCode += getStorage_location().hashCode();
        }
        if (getRemarks() != null) {
            _hashCode += getRemarks().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(License_certificate_rec.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://aspera.com/wsdl/", "license_certificate_rec"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("license_certificate_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "license_certificate_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("import_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "import_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("data_source_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "data_source_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("license_cert_number");
        elemField.setXmlName(new javax.xml.namespace.QName("", "license_cert_number"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("issue_date");
        elemField.setXmlName(new javax.xml.namespace.QName("", "issue_date"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("org_level_0_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "org_level_0_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("org_level_1_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "org_level_1_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("org_level_2_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "org_level_2_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("manufacturer_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "manufacturer_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("supplier_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "supplier_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("location_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "location_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("storage_location");
        elemField.setXmlName(new javax.xml.namespace.QName("", "storage_location"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("remarks");
        elemField.setXmlName(new javax.xml.namespace.QName("", "remarks"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}

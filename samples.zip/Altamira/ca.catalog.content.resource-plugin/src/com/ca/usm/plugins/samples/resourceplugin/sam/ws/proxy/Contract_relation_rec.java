/**
 * Contract_relation_rec.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ca.usm.plugins.samples.resourceplugin.sam.ws.proxy;

public class Contract_relation_rec  implements java.io.Serializable {
    private int contract_relation_id;

    private java.lang.String import_id;

    private int data_source_id;

    private int contract_rel_type_id;

    private int from_contract_id;

    private int to_contract_id;

    public Contract_relation_rec() {
    }

    public Contract_relation_rec(
           int contract_relation_id,
           java.lang.String import_id,
           int data_source_id,
           int contract_rel_type_id,
           int from_contract_id,
           int to_contract_id) {
           this.contract_relation_id = contract_relation_id;
           this.import_id = import_id;
           this.data_source_id = data_source_id;
           this.contract_rel_type_id = contract_rel_type_id;
           this.from_contract_id = from_contract_id;
           this.to_contract_id = to_contract_id;
    }


    /**
     * Gets the contract_relation_id value for this Contract_relation_rec.
     * 
     * @return contract_relation_id
     */
    public int getContract_relation_id() {
        return contract_relation_id;
    }


    /**
     * Sets the contract_relation_id value for this Contract_relation_rec.
     * 
     * @param contract_relation_id
     */
    public void setContract_relation_id(int contract_relation_id) {
        this.contract_relation_id = contract_relation_id;
    }


    /**
     * Gets the import_id value for this Contract_relation_rec.
     * 
     * @return import_id
     */
    public java.lang.String getImport_id() {
        return import_id;
    }


    /**
     * Sets the import_id value for this Contract_relation_rec.
     * 
     * @param import_id
     */
    public void setImport_id(java.lang.String import_id) {
        this.import_id = import_id;
    }


    /**
     * Gets the data_source_id value for this Contract_relation_rec.
     * 
     * @return data_source_id
     */
    public int getData_source_id() {
        return data_source_id;
    }


    /**
     * Sets the data_source_id value for this Contract_relation_rec.
     * 
     * @param data_source_id
     */
    public void setData_source_id(int data_source_id) {
        this.data_source_id = data_source_id;
    }


    /**
     * Gets the contract_rel_type_id value for this Contract_relation_rec.
     * 
     * @return contract_rel_type_id
     */
    public int getContract_rel_type_id() {
        return contract_rel_type_id;
    }


    /**
     * Sets the contract_rel_type_id value for this Contract_relation_rec.
     * 
     * @param contract_rel_type_id
     */
    public void setContract_rel_type_id(int contract_rel_type_id) {
        this.contract_rel_type_id = contract_rel_type_id;
    }


    /**
     * Gets the from_contract_id value for this Contract_relation_rec.
     * 
     * @return from_contract_id
     */
    public int getFrom_contract_id() {
        return from_contract_id;
    }


    /**
     * Sets the from_contract_id value for this Contract_relation_rec.
     * 
     * @param from_contract_id
     */
    public void setFrom_contract_id(int from_contract_id) {
        this.from_contract_id = from_contract_id;
    }


    /**
     * Gets the to_contract_id value for this Contract_relation_rec.
     * 
     * @return to_contract_id
     */
    public int getTo_contract_id() {
        return to_contract_id;
    }


    /**
     * Sets the to_contract_id value for this Contract_relation_rec.
     * 
     * @param to_contract_id
     */
    public void setTo_contract_id(int to_contract_id) {
        this.to_contract_id = to_contract_id;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Contract_relation_rec)) return false;
        Contract_relation_rec other = (Contract_relation_rec) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            this.contract_relation_id == other.getContract_relation_id() &&
            ((this.import_id==null && other.getImport_id()==null) || 
             (this.import_id!=null &&
              this.import_id.equals(other.getImport_id()))) &&
            this.data_source_id == other.getData_source_id() &&
            this.contract_rel_type_id == other.getContract_rel_type_id() &&
            this.from_contract_id == other.getFrom_contract_id() &&
            this.to_contract_id == other.getTo_contract_id();
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        _hashCode += getContract_relation_id();
        if (getImport_id() != null) {
            _hashCode += getImport_id().hashCode();
        }
        _hashCode += getData_source_id();
        _hashCode += getContract_rel_type_id();
        _hashCode += getFrom_contract_id();
        _hashCode += getTo_contract_id();
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Contract_relation_rec.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://aspera.com/wsdl/", "contract_relation_rec"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("contract_relation_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "contract_relation_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("import_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "import_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("data_source_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "data_source_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("contract_rel_type_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "contract_rel_type_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("from_contract_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "from_contract_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("to_contract_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "to_contract_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}

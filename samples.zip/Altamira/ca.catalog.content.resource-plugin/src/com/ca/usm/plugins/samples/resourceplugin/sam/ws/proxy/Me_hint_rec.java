/**
 * Me_hint_rec.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ca.usm.plugins.samples.resourceplugin.sam.ws.proxy;

public class Me_hint_rec  implements java.io.Serializable {
    private int me_hint_id;

    private java.lang.String import_id;

    private int data_source_id;

    private int device_id;

    private int account_id;

    private int org_level_2_id;

    private java.lang.String remarks;

    private java.lang.String metric_engine;

    private java.lang.String engine_hint_0;

    private java.lang.String engine_hint_1;

    private java.lang.String engine_hint_2;

    private java.lang.String engine_hint_3;

    private java.lang.String engine_hint_4;

    public Me_hint_rec() {
    }

    public Me_hint_rec(
           int me_hint_id,
           java.lang.String import_id,
           int data_source_id,
           int device_id,
           int account_id,
           int org_level_2_id,
           java.lang.String remarks,
           java.lang.String metric_engine,
           java.lang.String engine_hint_0,
           java.lang.String engine_hint_1,
           java.lang.String engine_hint_2,
           java.lang.String engine_hint_3,
           java.lang.String engine_hint_4) {
           this.me_hint_id = me_hint_id;
           this.import_id = import_id;
           this.data_source_id = data_source_id;
           this.device_id = device_id;
           this.account_id = account_id;
           this.org_level_2_id = org_level_2_id;
           this.remarks = remarks;
           this.metric_engine = metric_engine;
           this.engine_hint_0 = engine_hint_0;
           this.engine_hint_1 = engine_hint_1;
           this.engine_hint_2 = engine_hint_2;
           this.engine_hint_3 = engine_hint_3;
           this.engine_hint_4 = engine_hint_4;
    }


    /**
     * Gets the me_hint_id value for this Me_hint_rec.
     * 
     * @return me_hint_id
     */
    public int getMe_hint_id() {
        return me_hint_id;
    }


    /**
     * Sets the me_hint_id value for this Me_hint_rec.
     * 
     * @param me_hint_id
     */
    public void setMe_hint_id(int me_hint_id) {
        this.me_hint_id = me_hint_id;
    }


    /**
     * Gets the import_id value for this Me_hint_rec.
     * 
     * @return import_id
     */
    public java.lang.String getImport_id() {
        return import_id;
    }


    /**
     * Sets the import_id value for this Me_hint_rec.
     * 
     * @param import_id
     */
    public void setImport_id(java.lang.String import_id) {
        this.import_id = import_id;
    }


    /**
     * Gets the data_source_id value for this Me_hint_rec.
     * 
     * @return data_source_id
     */
    public int getData_source_id() {
        return data_source_id;
    }


    /**
     * Sets the data_source_id value for this Me_hint_rec.
     * 
     * @param data_source_id
     */
    public void setData_source_id(int data_source_id) {
        this.data_source_id = data_source_id;
    }


    /**
     * Gets the device_id value for this Me_hint_rec.
     * 
     * @return device_id
     */
    public int getDevice_id() {
        return device_id;
    }


    /**
     * Sets the device_id value for this Me_hint_rec.
     * 
     * @param device_id
     */
    public void setDevice_id(int device_id) {
        this.device_id = device_id;
    }


    /**
     * Gets the account_id value for this Me_hint_rec.
     * 
     * @return account_id
     */
    public int getAccount_id() {
        return account_id;
    }


    /**
     * Sets the account_id value for this Me_hint_rec.
     * 
     * @param account_id
     */
    public void setAccount_id(int account_id) {
        this.account_id = account_id;
    }


    /**
     * Gets the org_level_2_id value for this Me_hint_rec.
     * 
     * @return org_level_2_id
     */
    public int getOrg_level_2_id() {
        return org_level_2_id;
    }


    /**
     * Sets the org_level_2_id value for this Me_hint_rec.
     * 
     * @param org_level_2_id
     */
    public void setOrg_level_2_id(int org_level_2_id) {
        this.org_level_2_id = org_level_2_id;
    }


    /**
     * Gets the remarks value for this Me_hint_rec.
     * 
     * @return remarks
     */
    public java.lang.String getRemarks() {
        return remarks;
    }


    /**
     * Sets the remarks value for this Me_hint_rec.
     * 
     * @param remarks
     */
    public void setRemarks(java.lang.String remarks) {
        this.remarks = remarks;
    }


    /**
     * Gets the metric_engine value for this Me_hint_rec.
     * 
     * @return metric_engine
     */
    public java.lang.String getMetric_engine() {
        return metric_engine;
    }


    /**
     * Sets the metric_engine value for this Me_hint_rec.
     * 
     * @param metric_engine
     */
    public void setMetric_engine(java.lang.String metric_engine) {
        this.metric_engine = metric_engine;
    }


    /**
     * Gets the engine_hint_0 value for this Me_hint_rec.
     * 
     * @return engine_hint_0
     */
    public java.lang.String getEngine_hint_0() {
        return engine_hint_0;
    }


    /**
     * Sets the engine_hint_0 value for this Me_hint_rec.
     * 
     * @param engine_hint_0
     */
    public void setEngine_hint_0(java.lang.String engine_hint_0) {
        this.engine_hint_0 = engine_hint_0;
    }


    /**
     * Gets the engine_hint_1 value for this Me_hint_rec.
     * 
     * @return engine_hint_1
     */
    public java.lang.String getEngine_hint_1() {
        return engine_hint_1;
    }


    /**
     * Sets the engine_hint_1 value for this Me_hint_rec.
     * 
     * @param engine_hint_1
     */
    public void setEngine_hint_1(java.lang.String engine_hint_1) {
        this.engine_hint_1 = engine_hint_1;
    }


    /**
     * Gets the engine_hint_2 value for this Me_hint_rec.
     * 
     * @return engine_hint_2
     */
    public java.lang.String getEngine_hint_2() {
        return engine_hint_2;
    }


    /**
     * Sets the engine_hint_2 value for this Me_hint_rec.
     * 
     * @param engine_hint_2
     */
    public void setEngine_hint_2(java.lang.String engine_hint_2) {
        this.engine_hint_2 = engine_hint_2;
    }


    /**
     * Gets the engine_hint_3 value for this Me_hint_rec.
     * 
     * @return engine_hint_3
     */
    public java.lang.String getEngine_hint_3() {
        return engine_hint_3;
    }


    /**
     * Sets the engine_hint_3 value for this Me_hint_rec.
     * 
     * @param engine_hint_3
     */
    public void setEngine_hint_3(java.lang.String engine_hint_3) {
        this.engine_hint_3 = engine_hint_3;
    }


    /**
     * Gets the engine_hint_4 value for this Me_hint_rec.
     * 
     * @return engine_hint_4
     */
    public java.lang.String getEngine_hint_4() {
        return engine_hint_4;
    }


    /**
     * Sets the engine_hint_4 value for this Me_hint_rec.
     * 
     * @param engine_hint_4
     */
    public void setEngine_hint_4(java.lang.String engine_hint_4) {
        this.engine_hint_4 = engine_hint_4;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Me_hint_rec)) return false;
        Me_hint_rec other = (Me_hint_rec) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            this.me_hint_id == other.getMe_hint_id() &&
            ((this.import_id==null && other.getImport_id()==null) || 
             (this.import_id!=null &&
              this.import_id.equals(other.getImport_id()))) &&
            this.data_source_id == other.getData_source_id() &&
            this.device_id == other.getDevice_id() &&
            this.account_id == other.getAccount_id() &&
            this.org_level_2_id == other.getOrg_level_2_id() &&
            ((this.remarks==null && other.getRemarks()==null) || 
             (this.remarks!=null &&
              this.remarks.equals(other.getRemarks()))) &&
            ((this.metric_engine==null && other.getMetric_engine()==null) || 
             (this.metric_engine!=null &&
              this.metric_engine.equals(other.getMetric_engine()))) &&
            ((this.engine_hint_0==null && other.getEngine_hint_0()==null) || 
             (this.engine_hint_0!=null &&
              this.engine_hint_0.equals(other.getEngine_hint_0()))) &&
            ((this.engine_hint_1==null && other.getEngine_hint_1()==null) || 
             (this.engine_hint_1!=null &&
              this.engine_hint_1.equals(other.getEngine_hint_1()))) &&
            ((this.engine_hint_2==null && other.getEngine_hint_2()==null) || 
             (this.engine_hint_2!=null &&
              this.engine_hint_2.equals(other.getEngine_hint_2()))) &&
            ((this.engine_hint_3==null && other.getEngine_hint_3()==null) || 
             (this.engine_hint_3!=null &&
              this.engine_hint_3.equals(other.getEngine_hint_3()))) &&
            ((this.engine_hint_4==null && other.getEngine_hint_4()==null) || 
             (this.engine_hint_4!=null &&
              this.engine_hint_4.equals(other.getEngine_hint_4())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        _hashCode += getMe_hint_id();
        if (getImport_id() != null) {
            _hashCode += getImport_id().hashCode();
        }
        _hashCode += getData_source_id();
        _hashCode += getDevice_id();
        _hashCode += getAccount_id();
        _hashCode += getOrg_level_2_id();
        if (getRemarks() != null) {
            _hashCode += getRemarks().hashCode();
        }
        if (getMetric_engine() != null) {
            _hashCode += getMetric_engine().hashCode();
        }
        if (getEngine_hint_0() != null) {
            _hashCode += getEngine_hint_0().hashCode();
        }
        if (getEngine_hint_1() != null) {
            _hashCode += getEngine_hint_1().hashCode();
        }
        if (getEngine_hint_2() != null) {
            _hashCode += getEngine_hint_2().hashCode();
        }
        if (getEngine_hint_3() != null) {
            _hashCode += getEngine_hint_3().hashCode();
        }
        if (getEngine_hint_4() != null) {
            _hashCode += getEngine_hint_4().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Me_hint_rec.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://aspera.com/wsdl/", "me_hint_rec"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("me_hint_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "me_hint_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("import_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "import_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("data_source_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "data_source_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("device_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "device_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("account_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "account_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("org_level_2_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "org_level_2_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("remarks");
        elemField.setXmlName(new javax.xml.namespace.QName("", "remarks"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("metric_engine");
        elemField.setXmlName(new javax.xml.namespace.QName("", "metric_engine"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("engine_hint_0");
        elemField.setXmlName(new javax.xml.namespace.QName("", "engine_hint_0"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("engine_hint_1");
        elemField.setXmlName(new javax.xml.namespace.QName("", "engine_hint_1"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("engine_hint_2");
        elemField.setXmlName(new javax.xml.namespace.QName("", "engine_hint_2"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("engine_hint_3");
        elemField.setXmlName(new javax.xml.namespace.QName("", "engine_hint_3"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("engine_hint_4");
        elemField.setXmlName(new javax.xml.namespace.QName("", "engine_hint_4"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}

/**
 * Article_rec.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ca.usm.plugins.samples.resourceplugin.sam.ws.proxy;

public class Article_rec  implements java.io.Serializable {
    private int article_id;

    private java.lang.String import_id;

    private int data_source_id;

    private int manufacturer_id;

    private java.lang.String man_article_number;

    private java.lang.String description;

    private java.lang.String reference_price;

    private int currency_id;

    private java.lang.String language;

    private java.lang.String version;

    private int license_type_id;

    private java.math.BigInteger point_value;

    private int point_pool_id;

    private boolean is_enabled;

    private boolean is_medium;

    private java.lang.String remarks;

    private java.lang.String int_material_no;

    public Article_rec() {
    }

    public Article_rec(
           int article_id,
           java.lang.String import_id,
           int data_source_id,
           int manufacturer_id,
           java.lang.String man_article_number,
           java.lang.String description,
           java.lang.String reference_price,
           int currency_id,
           java.lang.String language,
           java.lang.String version,
           int license_type_id,
           java.math.BigInteger point_value,
           int point_pool_id,
           boolean is_enabled,
           boolean is_medium,
           java.lang.String remarks,
           java.lang.String int_material_no) {
           this.article_id = article_id;
           this.import_id = import_id;
           this.data_source_id = data_source_id;
           this.manufacturer_id = manufacturer_id;
           this.man_article_number = man_article_number;
           this.description = description;
           this.reference_price = reference_price;
           this.currency_id = currency_id;
           this.language = language;
           this.version = version;
           this.license_type_id = license_type_id;
           this.point_value = point_value;
           this.point_pool_id = point_pool_id;
           this.is_enabled = is_enabled;
           this.is_medium = is_medium;
           this.remarks = remarks;
           this.int_material_no = int_material_no;
    }


    /**
     * Gets the article_id value for this Article_rec.
     * 
     * @return article_id
     */
    public int getArticle_id() {
        return article_id;
    }


    /**
     * Sets the article_id value for this Article_rec.
     * 
     * @param article_id
     */
    public void setArticle_id(int article_id) {
        this.article_id = article_id;
    }


    /**
     * Gets the import_id value for this Article_rec.
     * 
     * @return import_id
     */
    public java.lang.String getImport_id() {
        return import_id;
    }


    /**
     * Sets the import_id value for this Article_rec.
     * 
     * @param import_id
     */
    public void setImport_id(java.lang.String import_id) {
        this.import_id = import_id;
    }


    /**
     * Gets the data_source_id value for this Article_rec.
     * 
     * @return data_source_id
     */
    public int getData_source_id() {
        return data_source_id;
    }


    /**
     * Sets the data_source_id value for this Article_rec.
     * 
     * @param data_source_id
     */
    public void setData_source_id(int data_source_id) {
        this.data_source_id = data_source_id;
    }


    /**
     * Gets the manufacturer_id value for this Article_rec.
     * 
     * @return manufacturer_id
     */
    public int getManufacturer_id() {
        return manufacturer_id;
    }


    /**
     * Sets the manufacturer_id value for this Article_rec.
     * 
     * @param manufacturer_id
     */
    public void setManufacturer_id(int manufacturer_id) {
        this.manufacturer_id = manufacturer_id;
    }


    /**
     * Gets the man_article_number value for this Article_rec.
     * 
     * @return man_article_number
     */
    public java.lang.String getMan_article_number() {
        return man_article_number;
    }


    /**
     * Sets the man_article_number value for this Article_rec.
     * 
     * @param man_article_number
     */
    public void setMan_article_number(java.lang.String man_article_number) {
        this.man_article_number = man_article_number;
    }


    /**
     * Gets the description value for this Article_rec.
     * 
     * @return description
     */
    public java.lang.String getDescription() {
        return description;
    }


    /**
     * Sets the description value for this Article_rec.
     * 
     * @param description
     */
    public void setDescription(java.lang.String description) {
        this.description = description;
    }


    /**
     * Gets the reference_price value for this Article_rec.
     * 
     * @return reference_price
     */
    public java.lang.String getReference_price() {
        return reference_price;
    }


    /**
     * Sets the reference_price value for this Article_rec.
     * 
     * @param reference_price
     */
    public void setReference_price(java.lang.String reference_price) {
        this.reference_price = reference_price;
    }


    /**
     * Gets the currency_id value for this Article_rec.
     * 
     * @return currency_id
     */
    public int getCurrency_id() {
        return currency_id;
    }


    /**
     * Sets the currency_id value for this Article_rec.
     * 
     * @param currency_id
     */
    public void setCurrency_id(int currency_id) {
        this.currency_id = currency_id;
    }


    /**
     * Gets the language value for this Article_rec.
     * 
     * @return language
     */
    public java.lang.String getLanguage() {
        return language;
    }


    /**
     * Sets the language value for this Article_rec.
     * 
     * @param language
     */
    public void setLanguage(java.lang.String language) {
        this.language = language;
    }


    /**
     * Gets the version value for this Article_rec.
     * 
     * @return version
     */
    public java.lang.String getVersion() {
        return version;
    }


    /**
     * Sets the version value for this Article_rec.
     * 
     * @param version
     */
    public void setVersion(java.lang.String version) {
        this.version = version;
    }


    /**
     * Gets the license_type_id value for this Article_rec.
     * 
     * @return license_type_id
     */
    public int getLicense_type_id() {
        return license_type_id;
    }


    /**
     * Sets the license_type_id value for this Article_rec.
     * 
     * @param license_type_id
     */
    public void setLicense_type_id(int license_type_id) {
        this.license_type_id = license_type_id;
    }


    /**
     * Gets the point_value value for this Article_rec.
     * 
     * @return point_value
     */
    public java.math.BigInteger getPoint_value() {
        return point_value;
    }


    /**
     * Sets the point_value value for this Article_rec.
     * 
     * @param point_value
     */
    public void setPoint_value(java.math.BigInteger point_value) {
        this.point_value = point_value;
    }


    /**
     * Gets the point_pool_id value for this Article_rec.
     * 
     * @return point_pool_id
     */
    public int getPoint_pool_id() {
        return point_pool_id;
    }


    /**
     * Sets the point_pool_id value for this Article_rec.
     * 
     * @param point_pool_id
     */
    public void setPoint_pool_id(int point_pool_id) {
        this.point_pool_id = point_pool_id;
    }


    /**
     * Gets the is_enabled value for this Article_rec.
     * 
     * @return is_enabled
     */
    public boolean isIs_enabled() {
        return is_enabled;
    }


    /**
     * Sets the is_enabled value for this Article_rec.
     * 
     * @param is_enabled
     */
    public void setIs_enabled(boolean is_enabled) {
        this.is_enabled = is_enabled;
    }


    /**
     * Gets the is_medium value for this Article_rec.
     * 
     * @return is_medium
     */
    public boolean isIs_medium() {
        return is_medium;
    }


    /**
     * Sets the is_medium value for this Article_rec.
     * 
     * @param is_medium
     */
    public void setIs_medium(boolean is_medium) {
        this.is_medium = is_medium;
    }


    /**
     * Gets the remarks value for this Article_rec.
     * 
     * @return remarks
     */
    public java.lang.String getRemarks() {
        return remarks;
    }


    /**
     * Sets the remarks value for this Article_rec.
     * 
     * @param remarks
     */
    public void setRemarks(java.lang.String remarks) {
        this.remarks = remarks;
    }


    /**
     * Gets the int_material_no value for this Article_rec.
     * 
     * @return int_material_no
     */
    public java.lang.String getInt_material_no() {
        return int_material_no;
    }


    /**
     * Sets the int_material_no value for this Article_rec.
     * 
     * @param int_material_no
     */
    public void setInt_material_no(java.lang.String int_material_no) {
        this.int_material_no = int_material_no;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Article_rec)) return false;
        Article_rec other = (Article_rec) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            this.article_id == other.getArticle_id() &&
            ((this.import_id==null && other.getImport_id()==null) || 
             (this.import_id!=null &&
              this.import_id.equals(other.getImport_id()))) &&
            this.data_source_id == other.getData_source_id() &&
            this.manufacturer_id == other.getManufacturer_id() &&
            ((this.man_article_number==null && other.getMan_article_number()==null) || 
             (this.man_article_number!=null &&
              this.man_article_number.equals(other.getMan_article_number()))) &&
            ((this.description==null && other.getDescription()==null) || 
             (this.description!=null &&
              this.description.equals(other.getDescription()))) &&
            ((this.reference_price==null && other.getReference_price()==null) || 
             (this.reference_price!=null &&
              this.reference_price.equals(other.getReference_price()))) &&
            this.currency_id == other.getCurrency_id() &&
            ((this.language==null && other.getLanguage()==null) || 
             (this.language!=null &&
              this.language.equals(other.getLanguage()))) &&
            ((this.version==null && other.getVersion()==null) || 
             (this.version!=null &&
              this.version.equals(other.getVersion()))) &&
            this.license_type_id == other.getLicense_type_id() &&
            ((this.point_value==null && other.getPoint_value()==null) || 
             (this.point_value!=null &&
              this.point_value.equals(other.getPoint_value()))) &&
            this.point_pool_id == other.getPoint_pool_id() &&
            this.is_enabled == other.isIs_enabled() &&
            this.is_medium == other.isIs_medium() &&
            ((this.remarks==null && other.getRemarks()==null) || 
             (this.remarks!=null &&
              this.remarks.equals(other.getRemarks()))) &&
            ((this.int_material_no==null && other.getInt_material_no()==null) || 
             (this.int_material_no!=null &&
              this.int_material_no.equals(other.getInt_material_no())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        _hashCode += getArticle_id();
        if (getImport_id() != null) {
            _hashCode += getImport_id().hashCode();
        }
        _hashCode += getData_source_id();
        _hashCode += getManufacturer_id();
        if (getMan_article_number() != null) {
            _hashCode += getMan_article_number().hashCode();
        }
        if (getDescription() != null) {
            _hashCode += getDescription().hashCode();
        }
        if (getReference_price() != null) {
            _hashCode += getReference_price().hashCode();
        }
        _hashCode += getCurrency_id();
        if (getLanguage() != null) {
            _hashCode += getLanguage().hashCode();
        }
        if (getVersion() != null) {
            _hashCode += getVersion().hashCode();
        }
        _hashCode += getLicense_type_id();
        if (getPoint_value() != null) {
            _hashCode += getPoint_value().hashCode();
        }
        _hashCode += getPoint_pool_id();
        _hashCode += (isIs_enabled() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        _hashCode += (isIs_medium() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        if (getRemarks() != null) {
            _hashCode += getRemarks().hashCode();
        }
        if (getInt_material_no() != null) {
            _hashCode += getInt_material_no().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Article_rec.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://aspera.com/wsdl/", "article_rec"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("article_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "article_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("import_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "import_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("data_source_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "data_source_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("manufacturer_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "manufacturer_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("man_article_number");
        elemField.setXmlName(new javax.xml.namespace.QName("", "man_article_number"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("description");
        elemField.setXmlName(new javax.xml.namespace.QName("", "description"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("reference_price");
        elemField.setXmlName(new javax.xml.namespace.QName("", "reference_price"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("currency_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "currency_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("language");
        elemField.setXmlName(new javax.xml.namespace.QName("", "language"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("version");
        elemField.setXmlName(new javax.xml.namespace.QName("", "version"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("license_type_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "license_type_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("point_value");
        elemField.setXmlName(new javax.xml.namespace.QName("", "point_value"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("point_pool_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "point_pool_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("is_enabled");
        elemField.setXmlName(new javax.xml.namespace.QName("", "is_enabled"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("is_medium");
        elemField.setXmlName(new javax.xml.namespace.QName("", "is_medium"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("remarks");
        elemField.setXmlName(new javax.xml.namespace.QName("", "remarks"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("int_material_no");
        elemField.setXmlName(new javax.xml.namespace.QName("", "int_material_no"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}

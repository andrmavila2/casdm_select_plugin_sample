/**
 * Role_rec.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ca.usm.plugins.samples.resourceplugin.sam.ws.proxy;

public class Role_rec  implements java.io.Serializable {
    private int role_id;

    private java.lang.String import_id;

    private int data_source_id;

    private java.lang.String name;

    private java.lang.String remarks;

    private java.lang.String what_perm;

    private java.lang.String where_perm;

    private boolean show_members_in_cc;

    public Role_rec() {
    }

    public Role_rec(
           int role_id,
           java.lang.String import_id,
           int data_source_id,
           java.lang.String name,
           java.lang.String remarks,
           java.lang.String what_perm,
           java.lang.String where_perm,
           boolean show_members_in_cc) {
           this.role_id = role_id;
           this.import_id = import_id;
           this.data_source_id = data_source_id;
           this.name = name;
           this.remarks = remarks;
           this.what_perm = what_perm;
           this.where_perm = where_perm;
           this.show_members_in_cc = show_members_in_cc;
    }


    /**
     * Gets the role_id value for this Role_rec.
     * 
     * @return role_id
     */
    public int getRole_id() {
        return role_id;
    }


    /**
     * Sets the role_id value for this Role_rec.
     * 
     * @param role_id
     */
    public void setRole_id(int role_id) {
        this.role_id = role_id;
    }


    /**
     * Gets the import_id value for this Role_rec.
     * 
     * @return import_id
     */
    public java.lang.String getImport_id() {
        return import_id;
    }


    /**
     * Sets the import_id value for this Role_rec.
     * 
     * @param import_id
     */
    public void setImport_id(java.lang.String import_id) {
        this.import_id = import_id;
    }


    /**
     * Gets the data_source_id value for this Role_rec.
     * 
     * @return data_source_id
     */
    public int getData_source_id() {
        return data_source_id;
    }


    /**
     * Sets the data_source_id value for this Role_rec.
     * 
     * @param data_source_id
     */
    public void setData_source_id(int data_source_id) {
        this.data_source_id = data_source_id;
    }


    /**
     * Gets the name value for this Role_rec.
     * 
     * @return name
     */
    public java.lang.String getName() {
        return name;
    }


    /**
     * Sets the name value for this Role_rec.
     * 
     * @param name
     */
    public void setName(java.lang.String name) {
        this.name = name;
    }


    /**
     * Gets the remarks value for this Role_rec.
     * 
     * @return remarks
     */
    public java.lang.String getRemarks() {
        return remarks;
    }


    /**
     * Sets the remarks value for this Role_rec.
     * 
     * @param remarks
     */
    public void setRemarks(java.lang.String remarks) {
        this.remarks = remarks;
    }


    /**
     * Gets the what_perm value for this Role_rec.
     * 
     * @return what_perm
     */
    public java.lang.String getWhat_perm() {
        return what_perm;
    }


    /**
     * Sets the what_perm value for this Role_rec.
     * 
     * @param what_perm
     */
    public void setWhat_perm(java.lang.String what_perm) {
        this.what_perm = what_perm;
    }


    /**
     * Gets the where_perm value for this Role_rec.
     * 
     * @return where_perm
     */
    public java.lang.String getWhere_perm() {
        return where_perm;
    }


    /**
     * Sets the where_perm value for this Role_rec.
     * 
     * @param where_perm
     */
    public void setWhere_perm(java.lang.String where_perm) {
        this.where_perm = where_perm;
    }


    /**
     * Gets the show_members_in_cc value for this Role_rec.
     * 
     * @return show_members_in_cc
     */
    public boolean isShow_members_in_cc() {
        return show_members_in_cc;
    }


    /**
     * Sets the show_members_in_cc value for this Role_rec.
     * 
     * @param show_members_in_cc
     */
    public void setShow_members_in_cc(boolean show_members_in_cc) {
        this.show_members_in_cc = show_members_in_cc;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Role_rec)) return false;
        Role_rec other = (Role_rec) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            this.role_id == other.getRole_id() &&
            ((this.import_id==null && other.getImport_id()==null) || 
             (this.import_id!=null &&
              this.import_id.equals(other.getImport_id()))) &&
            this.data_source_id == other.getData_source_id() &&
            ((this.name==null && other.getName()==null) || 
             (this.name!=null &&
              this.name.equals(other.getName()))) &&
            ((this.remarks==null && other.getRemarks()==null) || 
             (this.remarks!=null &&
              this.remarks.equals(other.getRemarks()))) &&
            ((this.what_perm==null && other.getWhat_perm()==null) || 
             (this.what_perm!=null &&
              this.what_perm.equals(other.getWhat_perm()))) &&
            ((this.where_perm==null && other.getWhere_perm()==null) || 
             (this.where_perm!=null &&
              this.where_perm.equals(other.getWhere_perm()))) &&
            this.show_members_in_cc == other.isShow_members_in_cc();
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        _hashCode += getRole_id();
        if (getImport_id() != null) {
            _hashCode += getImport_id().hashCode();
        }
        _hashCode += getData_source_id();
        if (getName() != null) {
            _hashCode += getName().hashCode();
        }
        if (getRemarks() != null) {
            _hashCode += getRemarks().hashCode();
        }
        if (getWhat_perm() != null) {
            _hashCode += getWhat_perm().hashCode();
        }
        if (getWhere_perm() != null) {
            _hashCode += getWhere_perm().hashCode();
        }
        _hashCode += (isShow_members_in_cc() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Role_rec.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://aspera.com/wsdl/", "role_rec"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("role_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "role_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("import_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "import_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("data_source_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "data_source_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("name");
        elemField.setXmlName(new javax.xml.namespace.QName("", "name"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("remarks");
        elemField.setXmlName(new javax.xml.namespace.QName("", "remarks"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("what_perm");
        elemField.setXmlName(new javax.xml.namespace.QName("", "what_perm"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("where_perm");
        elemField.setXmlName(new javax.xml.namespace.QName("", "where_perm"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("show_members_in_cc");
        elemField.setXmlName(new javax.xml.namespace.QName("", "show_members_in_cc"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}

/**
 * Inv_raw_generic_rec.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ca.usm.plugins.samples.resourceplugin.sam.ws.proxy;

public class Inv_raw_generic_rec  implements java.io.Serializable {
    private int inv_raw_generic_id;

    private java.lang.String import_id;

    private int data_source_id;

    private java.lang.String generic_key;

    private java.lang.String description;

    private java.lang.String publisher;

    private java.lang.String product;

    private java.lang.String product_version;

    private int device_id;

    private int account_id;

    private java.lang.String quantity;

    private java.lang.String installation_date;

    private java.lang.String last_usage;

    private int last_usage_account_id;

    private java.math.BigInteger usage_frequency_month;

    public Inv_raw_generic_rec() {
    }

    public Inv_raw_generic_rec(
           int inv_raw_generic_id,
           java.lang.String import_id,
           int data_source_id,
           java.lang.String generic_key,
           java.lang.String description,
           java.lang.String publisher,
           java.lang.String product,
           java.lang.String product_version,
           int device_id,
           int account_id,
           java.lang.String quantity,
           java.lang.String installation_date,
           java.lang.String last_usage,
           int last_usage_account_id,
           java.math.BigInteger usage_frequency_month) {
           this.inv_raw_generic_id = inv_raw_generic_id;
           this.import_id = import_id;
           this.data_source_id = data_source_id;
           this.generic_key = generic_key;
           this.description = description;
           this.publisher = publisher;
           this.product = product;
           this.product_version = product_version;
           this.device_id = device_id;
           this.account_id = account_id;
           this.quantity = quantity;
           this.installation_date = installation_date;
           this.last_usage = last_usage;
           this.last_usage_account_id = last_usage_account_id;
           this.usage_frequency_month = usage_frequency_month;
    }


    /**
     * Gets the inv_raw_generic_id value for this Inv_raw_generic_rec.
     * 
     * @return inv_raw_generic_id
     */
    public int getInv_raw_generic_id() {
        return inv_raw_generic_id;
    }


    /**
     * Sets the inv_raw_generic_id value for this Inv_raw_generic_rec.
     * 
     * @param inv_raw_generic_id
     */
    public void setInv_raw_generic_id(int inv_raw_generic_id) {
        this.inv_raw_generic_id = inv_raw_generic_id;
    }


    /**
     * Gets the import_id value for this Inv_raw_generic_rec.
     * 
     * @return import_id
     */
    public java.lang.String getImport_id() {
        return import_id;
    }


    /**
     * Sets the import_id value for this Inv_raw_generic_rec.
     * 
     * @param import_id
     */
    public void setImport_id(java.lang.String import_id) {
        this.import_id = import_id;
    }


    /**
     * Gets the data_source_id value for this Inv_raw_generic_rec.
     * 
     * @return data_source_id
     */
    public int getData_source_id() {
        return data_source_id;
    }


    /**
     * Sets the data_source_id value for this Inv_raw_generic_rec.
     * 
     * @param data_source_id
     */
    public void setData_source_id(int data_source_id) {
        this.data_source_id = data_source_id;
    }


    /**
     * Gets the generic_key value for this Inv_raw_generic_rec.
     * 
     * @return generic_key
     */
    public java.lang.String getGeneric_key() {
        return generic_key;
    }


    /**
     * Sets the generic_key value for this Inv_raw_generic_rec.
     * 
     * @param generic_key
     */
    public void setGeneric_key(java.lang.String generic_key) {
        this.generic_key = generic_key;
    }


    /**
     * Gets the description value for this Inv_raw_generic_rec.
     * 
     * @return description
     */
    public java.lang.String getDescription() {
        return description;
    }


    /**
     * Sets the description value for this Inv_raw_generic_rec.
     * 
     * @param description
     */
    public void setDescription(java.lang.String description) {
        this.description = description;
    }


    /**
     * Gets the publisher value for this Inv_raw_generic_rec.
     * 
     * @return publisher
     */
    public java.lang.String getPublisher() {
        return publisher;
    }


    /**
     * Sets the publisher value for this Inv_raw_generic_rec.
     * 
     * @param publisher
     */
    public void setPublisher(java.lang.String publisher) {
        this.publisher = publisher;
    }


    /**
     * Gets the product value for this Inv_raw_generic_rec.
     * 
     * @return product
     */
    public java.lang.String getProduct() {
        return product;
    }


    /**
     * Sets the product value for this Inv_raw_generic_rec.
     * 
     * @param product
     */
    public void setProduct(java.lang.String product) {
        this.product = product;
    }


    /**
     * Gets the product_version value for this Inv_raw_generic_rec.
     * 
     * @return product_version
     */
    public java.lang.String getProduct_version() {
        return product_version;
    }


    /**
     * Sets the product_version value for this Inv_raw_generic_rec.
     * 
     * @param product_version
     */
    public void setProduct_version(java.lang.String product_version) {
        this.product_version = product_version;
    }


    /**
     * Gets the device_id value for this Inv_raw_generic_rec.
     * 
     * @return device_id
     */
    public int getDevice_id() {
        return device_id;
    }


    /**
     * Sets the device_id value for this Inv_raw_generic_rec.
     * 
     * @param device_id
     */
    public void setDevice_id(int device_id) {
        this.device_id = device_id;
    }


    /**
     * Gets the account_id value for this Inv_raw_generic_rec.
     * 
     * @return account_id
     */
    public int getAccount_id() {
        return account_id;
    }


    /**
     * Sets the account_id value for this Inv_raw_generic_rec.
     * 
     * @param account_id
     */
    public void setAccount_id(int account_id) {
        this.account_id = account_id;
    }


    /**
     * Gets the quantity value for this Inv_raw_generic_rec.
     * 
     * @return quantity
     */
    public java.lang.String getQuantity() {
        return quantity;
    }


    /**
     * Sets the quantity value for this Inv_raw_generic_rec.
     * 
     * @param quantity
     */
    public void setQuantity(java.lang.String quantity) {
        this.quantity = quantity;
    }


    /**
     * Gets the installation_date value for this Inv_raw_generic_rec.
     * 
     * @return installation_date
     */
    public java.lang.String getInstallation_date() {
        return installation_date;
    }


    /**
     * Sets the installation_date value for this Inv_raw_generic_rec.
     * 
     * @param installation_date
     */
    public void setInstallation_date(java.lang.String installation_date) {
        this.installation_date = installation_date;
    }


    /**
     * Gets the last_usage value for this Inv_raw_generic_rec.
     * 
     * @return last_usage
     */
    public java.lang.String getLast_usage() {
        return last_usage;
    }


    /**
     * Sets the last_usage value for this Inv_raw_generic_rec.
     * 
     * @param last_usage
     */
    public void setLast_usage(java.lang.String last_usage) {
        this.last_usage = last_usage;
    }


    /**
     * Gets the last_usage_account_id value for this Inv_raw_generic_rec.
     * 
     * @return last_usage_account_id
     */
    public int getLast_usage_account_id() {
        return last_usage_account_id;
    }


    /**
     * Sets the last_usage_account_id value for this Inv_raw_generic_rec.
     * 
     * @param last_usage_account_id
     */
    public void setLast_usage_account_id(int last_usage_account_id) {
        this.last_usage_account_id = last_usage_account_id;
    }


    /**
     * Gets the usage_frequency_month value for this Inv_raw_generic_rec.
     * 
     * @return usage_frequency_month
     */
    public java.math.BigInteger getUsage_frequency_month() {
        return usage_frequency_month;
    }


    /**
     * Sets the usage_frequency_month value for this Inv_raw_generic_rec.
     * 
     * @param usage_frequency_month
     */
    public void setUsage_frequency_month(java.math.BigInteger usage_frequency_month) {
        this.usage_frequency_month = usage_frequency_month;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Inv_raw_generic_rec)) return false;
        Inv_raw_generic_rec other = (Inv_raw_generic_rec) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            this.inv_raw_generic_id == other.getInv_raw_generic_id() &&
            ((this.import_id==null && other.getImport_id()==null) || 
             (this.import_id!=null &&
              this.import_id.equals(other.getImport_id()))) &&
            this.data_source_id == other.getData_source_id() &&
            ((this.generic_key==null && other.getGeneric_key()==null) || 
             (this.generic_key!=null &&
              this.generic_key.equals(other.getGeneric_key()))) &&
            ((this.description==null && other.getDescription()==null) || 
             (this.description!=null &&
              this.description.equals(other.getDescription()))) &&
            ((this.publisher==null && other.getPublisher()==null) || 
             (this.publisher!=null &&
              this.publisher.equals(other.getPublisher()))) &&
            ((this.product==null && other.getProduct()==null) || 
             (this.product!=null &&
              this.product.equals(other.getProduct()))) &&
            ((this.product_version==null && other.getProduct_version()==null) || 
             (this.product_version!=null &&
              this.product_version.equals(other.getProduct_version()))) &&
            this.device_id == other.getDevice_id() &&
            this.account_id == other.getAccount_id() &&
            ((this.quantity==null && other.getQuantity()==null) || 
             (this.quantity!=null &&
              this.quantity.equals(other.getQuantity()))) &&
            ((this.installation_date==null && other.getInstallation_date()==null) || 
             (this.installation_date!=null &&
              this.installation_date.equals(other.getInstallation_date()))) &&
            ((this.last_usage==null && other.getLast_usage()==null) || 
             (this.last_usage!=null &&
              this.last_usage.equals(other.getLast_usage()))) &&
            this.last_usage_account_id == other.getLast_usage_account_id() &&
            ((this.usage_frequency_month==null && other.getUsage_frequency_month()==null) || 
             (this.usage_frequency_month!=null &&
              this.usage_frequency_month.equals(other.getUsage_frequency_month())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        _hashCode += getInv_raw_generic_id();
        if (getImport_id() != null) {
            _hashCode += getImport_id().hashCode();
        }
        _hashCode += getData_source_id();
        if (getGeneric_key() != null) {
            _hashCode += getGeneric_key().hashCode();
        }
        if (getDescription() != null) {
            _hashCode += getDescription().hashCode();
        }
        if (getPublisher() != null) {
            _hashCode += getPublisher().hashCode();
        }
        if (getProduct() != null) {
            _hashCode += getProduct().hashCode();
        }
        if (getProduct_version() != null) {
            _hashCode += getProduct_version().hashCode();
        }
        _hashCode += getDevice_id();
        _hashCode += getAccount_id();
        if (getQuantity() != null) {
            _hashCode += getQuantity().hashCode();
        }
        if (getInstallation_date() != null) {
            _hashCode += getInstallation_date().hashCode();
        }
        if (getLast_usage() != null) {
            _hashCode += getLast_usage().hashCode();
        }
        _hashCode += getLast_usage_account_id();
        if (getUsage_frequency_month() != null) {
            _hashCode += getUsage_frequency_month().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Inv_raw_generic_rec.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://aspera.com/wsdl/", "inv_raw_generic_rec"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("inv_raw_generic_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "inv_raw_generic_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("import_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "import_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("data_source_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "data_source_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("generic_key");
        elemField.setXmlName(new javax.xml.namespace.QName("", "generic_key"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("description");
        elemField.setXmlName(new javax.xml.namespace.QName("", "description"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("publisher");
        elemField.setXmlName(new javax.xml.namespace.QName("", "publisher"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("product");
        elemField.setXmlName(new javax.xml.namespace.QName("", "product"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("product_version");
        elemField.setXmlName(new javax.xml.namespace.QName("", "product_version"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("device_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "device_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("account_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "account_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("quantity");
        elemField.setXmlName(new javax.xml.namespace.QName("", "quantity"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("installation_date");
        elemField.setXmlName(new javax.xml.namespace.QName("", "installation_date"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("last_usage");
        elemField.setXmlName(new javax.xml.namespace.QName("", "last_usage"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("last_usage_account_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "last_usage_account_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("usage_frequency_month");
        elemField.setXmlName(new javax.xml.namespace.QName("", "usage_frequency_month"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}

package com.ca.usm.plugins.samples.resourceplugin;

import com.ca.usm.plugins.samples.resourceplugin.sam.ws.proxy.Monitor_data_exchange_process_rec;
import com.ca.usm.plugins.samples.resourceplugin.sam.ws.proxy.St_import;
import com.ca.usm.plugins.samples.resourceplugin.sam.ws.proxy.St_importBindingStub;
import com.ca.usm.plugins.samples.resourceplugin.sam.ws.proxy.St_importLocator;

import org.apache.axis.encoding.Base64;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.rmi.RemoteException;


public class ProcessSAMXML {	
  
  St_importBindingStub _stClient;

  ProcessSAMXML()
  {
    URL url;
    try {

      url = new URL(ResourcePlugin.SAM_WEBSERVICE_URL);
      St_import service = new St_importLocator();
      _stClient = (St_importBindingStub) service.getst_importPort(url);

    } catch (Exception e) {
      // TODO Auto-generated catch block
      e.printStackTrace();
    }

  }

  //upload xml file to SAM web service
  public void upload_file(String filePath, String outputFile) throws Exception
  {
    try
    {			
      String transactionId = _stClient.start_transaction(ResourcePlugin.SAM_WEBSERVICE_USERNAME,ResourcePlugin.SAM_WEBSERVICE_PASSWORD);

      if (data_exchange_upload(transactionId, "superuser", "in", outputFile + ".xml", encodeFileToBase64Binary(filePath), false))
      {
        _stClient.start_data_exchange_process(transactionId, "superuser", outputFile + ".xml");
      }			
      _stClient.end_transaction(transactionId);
    }
    catch (Exception e)
    {
      //log.error("Upload xml file to SAM web service is failed", e);
      throw e;
    }
  }

  //download the csv file from SAM web service
  public byte[] monitor_process(String outputFile) throws Exception
  {
    try
    {            
      byte[] data = null;	

      String transactionId = _stClient.start_transaction(ResourcePlugin.SAM_WEBSERVICE_USERNAME,ResourcePlugin.SAM_WEBSERVICE_PASSWORD);

      Monitor_data_exchange_process_rec monitorDataExchangeProcessRec = monitor_data_exchange_process(transactionId, "superuser", outputFile + ".xml");
      if (monitorDataExchangeProcessRec != null ) 
      {               
        String fileName = outputFile + ".csv";
        String logFile = _stClient.data_exchange_download(transactionId, "superuser", "in", fileName, false);
        if (!logFile.equals(""))
        {
          data = new Base64().decode(logFile);   
        }
      }
      _stClient.end_transaction(transactionId);
      return data;
    }
    catch (Exception e)
    {            
      //log.error("failed to download .csv file from SAM web service", e);
      return null;
    }
  }

  //Monitor SAM webservice data exchange process
  private Monitor_data_exchange_process_rec monitor_data_exchange_process(String tid, String exchangeDirectory, String fileName) throws RemoteException
  {
    return _stClient.monitor_data_exchange_process(tid, exchangeDirectory, fileName);
  }

  //Upload xml file to SAM web service
  private final boolean data_exchange_upload(String tid, String exchangeDirectory, String subdirectory, String fileName, String base64Document, boolean extractZipArchive) throws RemoteException
  {
    return _stClient.data_exchange_upload(tid, exchangeDirectory, subdirectory, fileName, base64Document, extractZipArchive);
  }	 

  //encode xml file to base 64
  private String encodeFileToBase64Binary(String fileName)
          throws IOException {

    File file = new File(fileName);
    byte[] bytes = loadFile(file);
    //byte[] encoded = Base64.encodeBase64(bytes);
    //String encodedString = new String(encoded);
    String encodedString = org.apache.axis.encoding.Base64.encode(bytes);

    return encodedString;
  }

  //convert xml file to byte array
  private static byte[] loadFile(File file) throws IOException {
    InputStream is = new FileInputStream(file);

    long length = file.length();
    if (length > Integer.MAX_VALUE) {
      // File is too large
    }
    byte[] bytes = new byte[(int)length];

    int offset = 0;
    int numRead = 0;
    while (offset < bytes.length
            && (numRead=is.read(bytes, offset, bytes.length-offset)) >= 0) {
      offset += numRead;
    }

    if (offset < bytes.length) {
      throw new IOException("Could not completely read file "+file.getName());
    }

    is.close();
    return bytes;
  }



}

/**
 * Device_relation_rec.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ca.usm.plugins.samples.resourceplugin.sam.ws.proxy;

public class Device_relation_rec  implements java.io.Serializable {
    private int device_relation_id;

    private java.lang.String import_id;

    private int data_source_id;

    private int device_rel_type_id;

    private int from_device_id;

    private int to_device_id;

    public Device_relation_rec() {
    }

    public Device_relation_rec(
           int device_relation_id,
           java.lang.String import_id,
           int data_source_id,
           int device_rel_type_id,
           int from_device_id,
           int to_device_id) {
           this.device_relation_id = device_relation_id;
           this.import_id = import_id;
           this.data_source_id = data_source_id;
           this.device_rel_type_id = device_rel_type_id;
           this.from_device_id = from_device_id;
           this.to_device_id = to_device_id;
    }


    /**
     * Gets the device_relation_id value for this Device_relation_rec.
     * 
     * @return device_relation_id
     */
    public int getDevice_relation_id() {
        return device_relation_id;
    }


    /**
     * Sets the device_relation_id value for this Device_relation_rec.
     * 
     * @param device_relation_id
     */
    public void setDevice_relation_id(int device_relation_id) {
        this.device_relation_id = device_relation_id;
    }


    /**
     * Gets the import_id value for this Device_relation_rec.
     * 
     * @return import_id
     */
    public java.lang.String getImport_id() {
        return import_id;
    }


    /**
     * Sets the import_id value for this Device_relation_rec.
     * 
     * @param import_id
     */
    public void setImport_id(java.lang.String import_id) {
        this.import_id = import_id;
    }


    /**
     * Gets the data_source_id value for this Device_relation_rec.
     * 
     * @return data_source_id
     */
    public int getData_source_id() {
        return data_source_id;
    }


    /**
     * Sets the data_source_id value for this Device_relation_rec.
     * 
     * @param data_source_id
     */
    public void setData_source_id(int data_source_id) {
        this.data_source_id = data_source_id;
    }


    /**
     * Gets the device_rel_type_id value for this Device_relation_rec.
     * 
     * @return device_rel_type_id
     */
    public int getDevice_rel_type_id() {
        return device_rel_type_id;
    }


    /**
     * Sets the device_rel_type_id value for this Device_relation_rec.
     * 
     * @param device_rel_type_id
     */
    public void setDevice_rel_type_id(int device_rel_type_id) {
        this.device_rel_type_id = device_rel_type_id;
    }


    /**
     * Gets the from_device_id value for this Device_relation_rec.
     * 
     * @return from_device_id
     */
    public int getFrom_device_id() {
        return from_device_id;
    }


    /**
     * Sets the from_device_id value for this Device_relation_rec.
     * 
     * @param from_device_id
     */
    public void setFrom_device_id(int from_device_id) {
        this.from_device_id = from_device_id;
    }


    /**
     * Gets the to_device_id value for this Device_relation_rec.
     * 
     * @return to_device_id
     */
    public int getTo_device_id() {
        return to_device_id;
    }


    /**
     * Sets the to_device_id value for this Device_relation_rec.
     * 
     * @param to_device_id
     */
    public void setTo_device_id(int to_device_id) {
        this.to_device_id = to_device_id;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Device_relation_rec)) return false;
        Device_relation_rec other = (Device_relation_rec) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            this.device_relation_id == other.getDevice_relation_id() &&
            ((this.import_id==null && other.getImport_id()==null) || 
             (this.import_id!=null &&
              this.import_id.equals(other.getImport_id()))) &&
            this.data_source_id == other.getData_source_id() &&
            this.device_rel_type_id == other.getDevice_rel_type_id() &&
            this.from_device_id == other.getFrom_device_id() &&
            this.to_device_id == other.getTo_device_id();
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        _hashCode += getDevice_relation_id();
        if (getImport_id() != null) {
            _hashCode += getImport_id().hashCode();
        }
        _hashCode += getData_source_id();
        _hashCode += getDevice_rel_type_id();
        _hashCode += getFrom_device_id();
        _hashCode += getTo_device_id();
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Device_relation_rec.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://aspera.com/wsdl/", "device_relation_rec"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("device_relation_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "device_relation_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("import_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "import_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("data_source_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "data_source_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("device_rel_type_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "device_rel_type_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("from_device_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "from_device_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("to_device_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "to_device_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}

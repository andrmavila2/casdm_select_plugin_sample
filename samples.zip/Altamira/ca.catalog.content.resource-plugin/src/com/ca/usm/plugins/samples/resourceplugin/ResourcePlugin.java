package com.ca.usm.plugins.samples.resourceplugin;

import com.ca.usm.plugins.apis.PluginContext;
import com.ca.usm.plugins.apis.forms.FDOption;
import com.ca.usm.plugins.apis.forms.FDSelectDataProvider;

import org.apache.commons.logging.Log;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Vector;

public class ResourcePlugin implements FDSelectDataProvider {

  private Log log ;
  private PluginContext context;
  private Map<String,Object> inputs;
  
  static String SAM_WEBSERVICE_USERNAME = "";
  static String SAM_WEBSERVICE_PASSWORD = "";
  static String SAM_WEBSERVICE_URL = "";
    
  @Override
  public void setContext(PluginContext context) 
  {
    this.context = context;
    log = context.getLogger(ResourcePlugin.class);
  }

  @Override
  public void setInputs(Map<String, Object> inputs) 
  {
    this.inputs = inputs;
  }

  //@Override
  /*public List<FDTableRow> getTableRows(int start, int numToReturn, String sortField, boolean sortAscending) 
  {
    List<FDTableRow> rows = new LinkedList<FDTableRow>();
    
    String userID = (String) inputs.get("userid");
    String tenantID = (String) inputs.get("tenantid");
    String requiredOnly = (String) inputs.get("required_only");
    
    setSAMWebServiceCredentials(tenantID);
    
    if(requiredOnly == null)
    {
      try {
        // query for fetching software list from SAM
        
        String query = 
                "SELECT d.device_name AS 'device',id.product_id,p.description AS 'product',pf.description as 'product_family'," +
                " idm.last_usage,idm.usage_frequency_month AS usage_freq_per_month" +
                //",CONVERT(DATE,l.expires_on) AS prod_license_expires_on " + 
                " FROM inv_device id" +
                " JOIN products p ON p.product_id=id.product_id" +
                " JOIN devices d ON d.device_id=id.device_id" +
                " JOIN users u ON u.user_id=d.user_id" +
                " JOIN product_families pf ON pf.product_family_id=p.product_family_id" +
                " LEFT OUTER JOIN inv_device_metering idm ON idm.inv_device_id=id.inv_device_id" +
                //" LEFT OUTER JOIN product_use_rights pur ON pur.product_id=id.product_id" +
                //" LEFT OUTER JOIN licenses l ON l.product_use_right_id=pur.product_use_right_id" +
                //" WHERE u.login = '"+userID+"'";
                " WHERE u.login = 'jarnold'";  
        if(log.isDebugEnabled())
          log.debug("Query for getting software list from SAM : " + query);
        
        Vector<HashMap<String, String>> list = new SAMWebservice().querySoftwareList(query);
      
        String value = "";
        for (HashMap<String, String> rowMap : list) {
          FDTableRow row = new FDTableRow();
          for (String key : rowMap.keySet()) {
             // removing time from expiration datetime value
             if(key.equals("prod_license_expires_on"))
             {
               value = rowMap.get(key).substring(0, 9);
             }
             else
             {
               value = rowMap.get(key);
             }
             row.setColumnValue(key,rowMap.get(key));
          }
          rows.add(row);
        }
      } catch (Exception e) {
          log.error("Error occured while getting resources",e);
      }
    }
            
    return rows;
  }*/

  @Override
  public int totalCount() {return 0;}
  
  void setSAMWebServiceCredentials(String tenantID)
  {
    try {
    
    Map<String,Object> configValues = context.getCatalogConfigValues("ca_cc_sam_ws_configuration", tenantID);  
    
    SAM_WEBSERVICE_USERNAME = (String) configValues.get("username");
    SAM_WEBSERVICE_PASSWORD = (String) configValues.get("password");
    SAM_WEBSERVICE_URL = (String) configValues.get("url");
    
    if(log.isDebugEnabled())
      log.debug("SAM Configuration : " + configValues);
    
    if(SAM_WEBSERVICE_USERNAME == null || SAM_WEBSERVICE_USERNAME.equals(""))
      throw new Exception("username not set properly");
    if(SAM_WEBSERVICE_PASSWORD == null || SAM_WEBSERVICE_PASSWORD.equals(""))
      throw new Exception("password not set properly");
    if(SAM_WEBSERVICE_URL == null || SAM_WEBSERVICE_URL.equals(""))
      throw new Exception("url not set properly");
    
    } catch (Exception e) {
      log.error("Error in SAM Configuration Form values",e);
    }
       
  }

  @Override
  public List<FDOption> getOptions(int start, int numToReturn) {
    
    List<FDOption> options = new LinkedList<FDOption>();
    
    String userID = (String) inputs.get("userid");
    String tenantID = (String) inputs.get("tenantid");
    boolean productFamilyOnly  = new Boolean((String)inputs.get("product_family_only"));
    String sw_ProdFamilyIds = (String) inputs.get("sw_ProdFamilyIds");
    String sub_ProdFamilyIds = (String) inputs.get("sub_ProdFamilyIds");
       
    setSAMWebServiceCredentials(tenantID);
    
    try {
      
        if(!productFamilyOnly)
        {
          String query = null;
          // query for fetching software list from SAM
          query = 
                  "SELECT a.account AS \"account\",p.product_id ,p.description AS \"product\",pf.product_family_id,'' AS \"device\",pf.description as \"product_family\", " +
                  " ium.last_usage,ium.usage_frequency_month AS usage_freq_per_month, d.device_key AS last_usage_on_device,1 as flag " +
                  " FROM inv_user iu"+
                  " JOIN products p ON p.product_id=iu.product_id"+
                  " JOIN accounts a ON a.account_id=iu.account_id"+
                  " JOIN users u ON u.user_id=a.user_id"+
                  " JOIN product_families pf ON pf.product_family_id=p.product_family_id"+
                  " LEFT OUTER JOIN inv_user_metering ium ON ium.inv_user_id=iu.inv_user_id"+
                  " LEFT OUTER JOIN devices d ON d.device_id=ium.last_usage_device_id"+
                  " WHERE u.login='"+userID+"'" +
                  " and pf.product_family_id in ("+ sub_ProdFamilyIds +") " + 
                  " UNION " +
                  " SELECT '' AS \"account\",id.product_id ,p.description AS \"product\",pf.product_family_id,d.device_key AS \"device\",pf.description as \"product_family\", " + 
                  " idm.last_usage,idm.usage_frequency_month AS usage_freq_per_month,'' AS last_usage_on_device,2 AS flag " +
                 //",CONVERT(DATE,l.expires_on) AS prod_license_expires_on " + 
                 " FROM inv_device id" +
                 " JOIN products p ON p.product_id=id.product_id" +
                 " JOIN devices d ON d.device_id=id.device_id" +
                 " JOIN users u ON u.user_id=d.user_id" +
                 " JOIN product_families pf ON pf.product_family_id=p.product_family_id" +
                 " LEFT OUTER JOIN inv_device_metering idm ON idm.inv_device_id=id.inv_device_id" +
                 //" LEFT OUTER JOIN product_use_rights pur ON pur.product_id=id.product_id" +
                 //" LEFT OUTER JOIN licenses l ON l.product_use_right_id=pur.product_use_right_id" +
                 " WHERE u.login = '"+userID+"'" +
                 //" and p.description in ("+ productsIn +") ";
                 " and pf.product_family_id in ("+ sw_ProdFamilyIds + ") ";
         
         
          if(log.isDebugEnabled())
            log.debug("Query for getting software list from SAM : " + query);
          
          Vector<HashMap<String, String>> list = new SAMWebservice().querySoftwareList(query);
        
          for (HashMap<String, String> item : list) {
            FDOption option = new FDOption();
            
            option.setId(item.remove("product_id"));
            
            String value = "";
            for (String key : item.keySet()) {
              value += key + "::" + item.get(key) + "|";
            }
                   
            option.setValue(value);
                                  
            options.add(option);
          }
        }
        else if(productFamilyOnly)
        {
          String query = "select pf.product_family_id,pf.description as \"product_family\" from product_families pf";
          
          if(log.isDebugEnabled())
            log.debug("Query for getting software list from SAM : " + query);
          
          Vector<HashMap<String, String>> list = new SAMWebservice().querySoftwareList(query);
        
          for (HashMap<String, String> item : list) {
            FDOption option = new FDOption();
            
            option.setId(item.get("product_family_id"));
            option.setValue(item.get("product_family"));
                                  
            options.add(option);
          }
        }
      } catch (Exception e) {
        log.error("Error occured while getting resources",e);
      }
        
    return options;
    
  }

}

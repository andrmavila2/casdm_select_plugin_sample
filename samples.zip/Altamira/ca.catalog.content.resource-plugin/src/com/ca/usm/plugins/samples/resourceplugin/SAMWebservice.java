package com.ca.usm.plugins.samples.resourceplugin;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.InputStream;
import java.util.Date;
import java.util.HashMap;
import java.util.Scanner;
import java.util.Vector;


public class SAMWebservice {
		
	public Vector<HashMap<String,String>> querySoftwareList(String query) throws Exception
	{		
		Vector<HashMap<String, String>> softwareList = new Vector<HashMap<String,String>>();
		String fileName = "SoftwareList_" + new Date().getTime();
			
		//Create xml file to give as a input to SAM web service
		GenerateXML samXML = new GenerateXML();
		samXML.createXML(query,fileName);			
					
		//Download the csv file from SAM web service
		ProcessSAMXML processXML = new ProcessSAMXML();
		String tempFolder = System.getProperty("java.io.tmpdir");
		processXML.upload_file(tempFolder + File.separator + fileName + ".xml",fileName);
		byte[] fileData = processXML.monitor_process(fileName);
		InputStream myInputStream = new ByteArrayInputStream(fileData);
		
		Scanner scanner = new Scanner(myInputStream,"utf-8");
		int columnCount =0;
		String[] columnNames = null;
		String[] values = null;		
		
		if(scanner.hasNext())
		{
			String data=scanner.nextLine();
			columnNames = data.split("\";"); 
			columnCount = columnNames.length;				
		}
		
		while(scanner.hasNextLine())
		{					
			String data=scanner.nextLine();		
			values= data.split("\";"); 	
			int valuesCount = values.length;
			if(columnCount == valuesCount)
			{				
				HashMap<String, String> row = new HashMap<String,String>();
				for(int i=0;i<columnCount;i++)
				{						
					if(columnNames != null && values != null)		
					{
						String columnName = columnNames[i].toString().toLowerCase();
						String columnValue = values[i].toString();
						 		
						
						columnName = removePrefixAndSuffix(columnName);
						columnValue = removePrefixAndSuffix(columnValue);
						
						row.put(columnName, columnValue);
					}	
				}
				
				softwareList.add(row);
			}				
						
		}
		
		scanner.close();
			
		return softwareList;
		
	}
	
	private String removePrefixAndSuffix(String text)
	{
		String modifiedText = text;
		if(modifiedText.startsWith("\""))
			modifiedText = modifiedText.substring(1);							
		
		if(modifiedText.endsWith("\""))
			modifiedText = modifiedText.substring(0, modifiedText.length() - 1);
		
		if(modifiedText.contains("\"\""))
			modifiedText = modifiedText.replace("\"\"", "\"");
		
		return modifiedText;
		
	}

}

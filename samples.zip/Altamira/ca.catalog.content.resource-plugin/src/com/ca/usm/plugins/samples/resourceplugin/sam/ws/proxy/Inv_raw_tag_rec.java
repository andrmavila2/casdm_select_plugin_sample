/**
 * Inv_raw_tag_rec.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ca.usm.plugins.samples.resourceplugin.sam.ws.proxy;

public class Inv_raw_tag_rec  implements java.io.Serializable {
    private int inv_raw_tag_id;

    private java.lang.String import_id;

    private int data_source_id;

    private java.lang.String software_unique_id;

    private java.lang.String product_title;

    private java.lang.String product_ver_name;

    private java.lang.String product_ver_major;

    private java.lang.String product_ver_minor;

    private java.lang.String manufacturer_name;

    private java.lang.String manufacturer_guid;

    private java.lang.String license_req;

    private java.lang.String activation_status;

    private java.lang.String channel_type;

    private java.lang.String supported_languages;

    private int device_id;

    private java.lang.String installation_date;

    public Inv_raw_tag_rec() {
    }

    public Inv_raw_tag_rec(
           int inv_raw_tag_id,
           java.lang.String import_id,
           int data_source_id,
           java.lang.String software_unique_id,
           java.lang.String product_title,
           java.lang.String product_ver_name,
           java.lang.String product_ver_major,
           java.lang.String product_ver_minor,
           java.lang.String manufacturer_name,
           java.lang.String manufacturer_guid,
           java.lang.String license_req,
           java.lang.String activation_status,
           java.lang.String channel_type,
           java.lang.String supported_languages,
           int device_id,
           java.lang.String installation_date) {
           this.inv_raw_tag_id = inv_raw_tag_id;
           this.import_id = import_id;
           this.data_source_id = data_source_id;
           this.software_unique_id = software_unique_id;
           this.product_title = product_title;
           this.product_ver_name = product_ver_name;
           this.product_ver_major = product_ver_major;
           this.product_ver_minor = product_ver_minor;
           this.manufacturer_name = manufacturer_name;
           this.manufacturer_guid = manufacturer_guid;
           this.license_req = license_req;
           this.activation_status = activation_status;
           this.channel_type = channel_type;
           this.supported_languages = supported_languages;
           this.device_id = device_id;
           this.installation_date = installation_date;
    }


    /**
     * Gets the inv_raw_tag_id value for this Inv_raw_tag_rec.
     * 
     * @return inv_raw_tag_id
     */
    public int getInv_raw_tag_id() {
        return inv_raw_tag_id;
    }


    /**
     * Sets the inv_raw_tag_id value for this Inv_raw_tag_rec.
     * 
     * @param inv_raw_tag_id
     */
    public void setInv_raw_tag_id(int inv_raw_tag_id) {
        this.inv_raw_tag_id = inv_raw_tag_id;
    }


    /**
     * Gets the import_id value for this Inv_raw_tag_rec.
     * 
     * @return import_id
     */
    public java.lang.String getImport_id() {
        return import_id;
    }


    /**
     * Sets the import_id value for this Inv_raw_tag_rec.
     * 
     * @param import_id
     */
    public void setImport_id(java.lang.String import_id) {
        this.import_id = import_id;
    }


    /**
     * Gets the data_source_id value for this Inv_raw_tag_rec.
     * 
     * @return data_source_id
     */
    public int getData_source_id() {
        return data_source_id;
    }


    /**
     * Sets the data_source_id value for this Inv_raw_tag_rec.
     * 
     * @param data_source_id
     */
    public void setData_source_id(int data_source_id) {
        this.data_source_id = data_source_id;
    }


    /**
     * Gets the software_unique_id value for this Inv_raw_tag_rec.
     * 
     * @return software_unique_id
     */
    public java.lang.String getSoftware_unique_id() {
        return software_unique_id;
    }


    /**
     * Sets the software_unique_id value for this Inv_raw_tag_rec.
     * 
     * @param software_unique_id
     */
    public void setSoftware_unique_id(java.lang.String software_unique_id) {
        this.software_unique_id = software_unique_id;
    }


    /**
     * Gets the product_title value for this Inv_raw_tag_rec.
     * 
     * @return product_title
     */
    public java.lang.String getProduct_title() {
        return product_title;
    }


    /**
     * Sets the product_title value for this Inv_raw_tag_rec.
     * 
     * @param product_title
     */
    public void setProduct_title(java.lang.String product_title) {
        this.product_title = product_title;
    }


    /**
     * Gets the product_ver_name value for this Inv_raw_tag_rec.
     * 
     * @return product_ver_name
     */
    public java.lang.String getProduct_ver_name() {
        return product_ver_name;
    }


    /**
     * Sets the product_ver_name value for this Inv_raw_tag_rec.
     * 
     * @param product_ver_name
     */
    public void setProduct_ver_name(java.lang.String product_ver_name) {
        this.product_ver_name = product_ver_name;
    }


    /**
     * Gets the product_ver_major value for this Inv_raw_tag_rec.
     * 
     * @return product_ver_major
     */
    public java.lang.String getProduct_ver_major() {
        return product_ver_major;
    }


    /**
     * Sets the product_ver_major value for this Inv_raw_tag_rec.
     * 
     * @param product_ver_major
     */
    public void setProduct_ver_major(java.lang.String product_ver_major) {
        this.product_ver_major = product_ver_major;
    }


    /**
     * Gets the product_ver_minor value for this Inv_raw_tag_rec.
     * 
     * @return product_ver_minor
     */
    public java.lang.String getProduct_ver_minor() {
        return product_ver_minor;
    }


    /**
     * Sets the product_ver_minor value for this Inv_raw_tag_rec.
     * 
     * @param product_ver_minor
     */
    public void setProduct_ver_minor(java.lang.String product_ver_minor) {
        this.product_ver_minor = product_ver_minor;
    }


    /**
     * Gets the manufacturer_name value for this Inv_raw_tag_rec.
     * 
     * @return manufacturer_name
     */
    public java.lang.String getManufacturer_name() {
        return manufacturer_name;
    }


    /**
     * Sets the manufacturer_name value for this Inv_raw_tag_rec.
     * 
     * @param manufacturer_name
     */
    public void setManufacturer_name(java.lang.String manufacturer_name) {
        this.manufacturer_name = manufacturer_name;
    }


    /**
     * Gets the manufacturer_guid value for this Inv_raw_tag_rec.
     * 
     * @return manufacturer_guid
     */
    public java.lang.String getManufacturer_guid() {
        return manufacturer_guid;
    }


    /**
     * Sets the manufacturer_guid value for this Inv_raw_tag_rec.
     * 
     * @param manufacturer_guid
     */
    public void setManufacturer_guid(java.lang.String manufacturer_guid) {
        this.manufacturer_guid = manufacturer_guid;
    }


    /**
     * Gets the license_req value for this Inv_raw_tag_rec.
     * 
     * @return license_req
     */
    public java.lang.String getLicense_req() {
        return license_req;
    }


    /**
     * Sets the license_req value for this Inv_raw_tag_rec.
     * 
     * @param license_req
     */
    public void setLicense_req(java.lang.String license_req) {
        this.license_req = license_req;
    }


    /**
     * Gets the activation_status value for this Inv_raw_tag_rec.
     * 
     * @return activation_status
     */
    public java.lang.String getActivation_status() {
        return activation_status;
    }


    /**
     * Sets the activation_status value for this Inv_raw_tag_rec.
     * 
     * @param activation_status
     */
    public void setActivation_status(java.lang.String activation_status) {
        this.activation_status = activation_status;
    }


    /**
     * Gets the channel_type value for this Inv_raw_tag_rec.
     * 
     * @return channel_type
     */
    public java.lang.String getChannel_type() {
        return channel_type;
    }


    /**
     * Sets the channel_type value for this Inv_raw_tag_rec.
     * 
     * @param channel_type
     */
    public void setChannel_type(java.lang.String channel_type) {
        this.channel_type = channel_type;
    }


    /**
     * Gets the supported_languages value for this Inv_raw_tag_rec.
     * 
     * @return supported_languages
     */
    public java.lang.String getSupported_languages() {
        return supported_languages;
    }


    /**
     * Sets the supported_languages value for this Inv_raw_tag_rec.
     * 
     * @param supported_languages
     */
    public void setSupported_languages(java.lang.String supported_languages) {
        this.supported_languages = supported_languages;
    }


    /**
     * Gets the device_id value for this Inv_raw_tag_rec.
     * 
     * @return device_id
     */
    public int getDevice_id() {
        return device_id;
    }


    /**
     * Sets the device_id value for this Inv_raw_tag_rec.
     * 
     * @param device_id
     */
    public void setDevice_id(int device_id) {
        this.device_id = device_id;
    }


    /**
     * Gets the installation_date value for this Inv_raw_tag_rec.
     * 
     * @return installation_date
     */
    public java.lang.String getInstallation_date() {
        return installation_date;
    }


    /**
     * Sets the installation_date value for this Inv_raw_tag_rec.
     * 
     * @param installation_date
     */
    public void setInstallation_date(java.lang.String installation_date) {
        this.installation_date = installation_date;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Inv_raw_tag_rec)) return false;
        Inv_raw_tag_rec other = (Inv_raw_tag_rec) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            this.inv_raw_tag_id == other.getInv_raw_tag_id() &&
            ((this.import_id==null && other.getImport_id()==null) || 
             (this.import_id!=null &&
              this.import_id.equals(other.getImport_id()))) &&
            this.data_source_id == other.getData_source_id() &&
            ((this.software_unique_id==null && other.getSoftware_unique_id()==null) || 
             (this.software_unique_id!=null &&
              this.software_unique_id.equals(other.getSoftware_unique_id()))) &&
            ((this.product_title==null && other.getProduct_title()==null) || 
             (this.product_title!=null &&
              this.product_title.equals(other.getProduct_title()))) &&
            ((this.product_ver_name==null && other.getProduct_ver_name()==null) || 
             (this.product_ver_name!=null &&
              this.product_ver_name.equals(other.getProduct_ver_name()))) &&
            ((this.product_ver_major==null && other.getProduct_ver_major()==null) || 
             (this.product_ver_major!=null &&
              this.product_ver_major.equals(other.getProduct_ver_major()))) &&
            ((this.product_ver_minor==null && other.getProduct_ver_minor()==null) || 
             (this.product_ver_minor!=null &&
              this.product_ver_minor.equals(other.getProduct_ver_minor()))) &&
            ((this.manufacturer_name==null && other.getManufacturer_name()==null) || 
             (this.manufacturer_name!=null &&
              this.manufacturer_name.equals(other.getManufacturer_name()))) &&
            ((this.manufacturer_guid==null && other.getManufacturer_guid()==null) || 
             (this.manufacturer_guid!=null &&
              this.manufacturer_guid.equals(other.getManufacturer_guid()))) &&
            ((this.license_req==null && other.getLicense_req()==null) || 
             (this.license_req!=null &&
              this.license_req.equals(other.getLicense_req()))) &&
            ((this.activation_status==null && other.getActivation_status()==null) || 
             (this.activation_status!=null &&
              this.activation_status.equals(other.getActivation_status()))) &&
            ((this.channel_type==null && other.getChannel_type()==null) || 
             (this.channel_type!=null &&
              this.channel_type.equals(other.getChannel_type()))) &&
            ((this.supported_languages==null && other.getSupported_languages()==null) || 
             (this.supported_languages!=null &&
              this.supported_languages.equals(other.getSupported_languages()))) &&
            this.device_id == other.getDevice_id() &&
            ((this.installation_date==null && other.getInstallation_date()==null) || 
             (this.installation_date!=null &&
              this.installation_date.equals(other.getInstallation_date())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        _hashCode += getInv_raw_tag_id();
        if (getImport_id() != null) {
            _hashCode += getImport_id().hashCode();
        }
        _hashCode += getData_source_id();
        if (getSoftware_unique_id() != null) {
            _hashCode += getSoftware_unique_id().hashCode();
        }
        if (getProduct_title() != null) {
            _hashCode += getProduct_title().hashCode();
        }
        if (getProduct_ver_name() != null) {
            _hashCode += getProduct_ver_name().hashCode();
        }
        if (getProduct_ver_major() != null) {
            _hashCode += getProduct_ver_major().hashCode();
        }
        if (getProduct_ver_minor() != null) {
            _hashCode += getProduct_ver_minor().hashCode();
        }
        if (getManufacturer_name() != null) {
            _hashCode += getManufacturer_name().hashCode();
        }
        if (getManufacturer_guid() != null) {
            _hashCode += getManufacturer_guid().hashCode();
        }
        if (getLicense_req() != null) {
            _hashCode += getLicense_req().hashCode();
        }
        if (getActivation_status() != null) {
            _hashCode += getActivation_status().hashCode();
        }
        if (getChannel_type() != null) {
            _hashCode += getChannel_type().hashCode();
        }
        if (getSupported_languages() != null) {
            _hashCode += getSupported_languages().hashCode();
        }
        _hashCode += getDevice_id();
        if (getInstallation_date() != null) {
            _hashCode += getInstallation_date().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Inv_raw_tag_rec.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://aspera.com/wsdl/", "inv_raw_tag_rec"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("inv_raw_tag_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "inv_raw_tag_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("import_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "import_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("data_source_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "data_source_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("software_unique_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "software_unique_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("product_title");
        elemField.setXmlName(new javax.xml.namespace.QName("", "product_title"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("product_ver_name");
        elemField.setXmlName(new javax.xml.namespace.QName("", "product_ver_name"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("product_ver_major");
        elemField.setXmlName(new javax.xml.namespace.QName("", "product_ver_major"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("product_ver_minor");
        elemField.setXmlName(new javax.xml.namespace.QName("", "product_ver_minor"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("manufacturer_name");
        elemField.setXmlName(new javax.xml.namespace.QName("", "manufacturer_name"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("manufacturer_guid");
        elemField.setXmlName(new javax.xml.namespace.QName("", "manufacturer_guid"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("license_req");
        elemField.setXmlName(new javax.xml.namespace.QName("", "license_req"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("activation_status");
        elemField.setXmlName(new javax.xml.namespace.QName("", "activation_status"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("channel_type");
        elemField.setXmlName(new javax.xml.namespace.QName("", "channel_type"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("supported_languages");
        elemField.setXmlName(new javax.xml.namespace.QName("", "supported_languages"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("device_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "device_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("installation_date");
        elemField.setXmlName(new javax.xml.namespace.QName("", "installation_date"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}

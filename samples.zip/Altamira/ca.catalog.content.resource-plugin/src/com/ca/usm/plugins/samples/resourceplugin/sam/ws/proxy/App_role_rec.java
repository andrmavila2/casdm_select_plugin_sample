/**
 * App_role_rec.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ca.usm.plugins.samples.resourceplugin.sam.ws.proxy;

public class App_role_rec  implements java.io.Serializable {
    private int app_role_id;

    private java.lang.String import_id;

    private int data_source_id;

    private java.lang.String name;

    private java.lang.String remarks;

    private java.lang.String perm_icm_compliance;

    private java.lang.String perm_st;

    private java.lang.String perm_lic_cert;

    private java.lang.String perm_import;

    private java.lang.String perm_lic_upd_base;

    private java.lang.String perm_lic_move;

    private java.lang.String perm_lic_transfer;

    private java.lang.String perm_md_sys_lic_stat;

    private java.lang.String perm_md_sys_lic_cl_stat;

    private java.lang.String perm_icm_usage;

    private java.lang.String perm_icm_me_hints;

    private java.lang.String perm_icm_raw;

    private java.lang.String perm_md_sys_inv_stat;

    private java.lang.String perm_cmm_cont;

    private java.lang.String perm_cmm_enrol;

    private java.lang.String perm_cmm_points;

    private java.lang.String perm_cmm_expend;

    private java.lang.String perm_md_cmm_class;

    private java.lang.String perm_md_cmm_rel_typ;

    private java.lang.String perm_md_cmm_trans;

    private java.lang.String perm_md_cmm_pay_terms;

    private java.lang.String perm_md_cmm_typ;

    private java.lang.String perm_md_cmm_status;

    private java.lang.String perm_md_cmm_exp_typ;

    private java.lang.String perm_fc;

    private java.lang.String perm_osm_demand_opt;

    private java.lang.String perm_osm_cost_sav;

    private java.lang.String perm_fm;

    private java.lang.String perm_fm_charging;

    private java.lang.String perm_adm;

    private java.lang.String perm_md_pr_man;

    private java.lang.String perm_md_pr_prod_fam;

    private java.lang.String perm_md_pr_prod;

    private java.lang.String perm_md_pr_pur;

    private java.lang.String perm_md_pr_art;

    private java.lang.String perm_md_pr_dg_path;

    private java.lang.String perm_md_pr_product_path;

    private java.lang.String perm_md_pr_prod_dep;

    private java.lang.String perm_md_pr_man_syn;

    private java.lang.String perm_md_org_cont;

    private java.lang.String perm_md_pr_inv_syn;

    private java.lang.String perm_md_pr_sw_class;

    private java.lang.String perm_md_org_sup;

    private java.lang.String perm_md_pr_supp_art;

    private java.lang.String perm_md_pr_lic_metr;

    private java.lang.String perm_md_pr_lic_types;

    private java.lang.String perm_md_pr_point_cat;

    private java.lang.String perm_md_pr_tiers;

    private java.lang.String perm_md_pr_status;

    private java.lang.String perm_md_sys_sig_stat;

    private java.lang.String perm_md_org_co;

    private java.lang.String perm_md_org_bu;

    private java.lang.String perm_md_org_cc;

    private java.lang.String perm_md_org_loc;

    private java.lang.String perm_md_org_proj;

    private java.lang.String perm_md_org_rep;

    private java.lang.String perm_md_dev_dev;

    private java.lang.String perm_md_dev_dev_rel;

    private java.lang.String perm_md_dev_dev_cap;

    private java.lang.String perm_md_user_users;

    private java.lang.String perm_md_user_acc;

    private java.lang.String perm_md_user_perms;

    private java.lang.String perm_md_dev_dev_rel_typ;

    private java.lang.String perm_md_dev_dev_typ;

    private java.lang.String perm_md_dev_dev_stat;

    private java.lang.String perm_md_dev_cpu_typ;

    private java.lang.String perm_exch_import;

    private java.lang.String perm_exch_exch_dir;

    private java.lang.String perm_exch_feeds;

    private java.lang.String perm_exch_export;

    private java.lang.String perm_exch_proc;

    private java.lang.String perm_exch_steps;

    private java.lang.String perm_exch_files;

    private java.lang.String perm_exch_err_stat;

    private java.lang.String perm_exch_err_det;

    private java.lang.String perm_exch_import_stat;

    private java.lang.String perm_exch_feed_cat;

    private java.lang.String perm_exch_feed_stat;

    private java.lang.String perm_admin;

    private java.lang.String perm_md_glob_lang;

    private java.lang.String perm_md_glob_reg;

    private java.lang.String perm_md_glob_count;

    private java.lang.String perm_md_glob_curr;

    private java.lang.String perm_md_glob_ex;

    private java.lang.String perm_md_sys_act_reas;

    private java.lang.String perm_md_sys_perimeters;

    private java.lang.String perm_md_sys_ds;

    private java.lang.String perm_mm;

    private java.lang.String perm_report;

    private java.lang.String perm_fm_cpp;

    public App_role_rec() {
    }

    public App_role_rec(
           int app_role_id,
           java.lang.String import_id,
           int data_source_id,
           java.lang.String name,
           java.lang.String remarks,
           java.lang.String perm_icm_compliance,
           java.lang.String perm_st,
           java.lang.String perm_lic_cert,
           java.lang.String perm_import,
           java.lang.String perm_lic_upd_base,
           java.lang.String perm_lic_move,
           java.lang.String perm_lic_transfer,
           java.lang.String perm_md_sys_lic_stat,
           java.lang.String perm_md_sys_lic_cl_stat,
           java.lang.String perm_icm_usage,
           java.lang.String perm_icm_me_hints,
           java.lang.String perm_icm_raw,
           java.lang.String perm_md_sys_inv_stat,
           java.lang.String perm_cmm_cont,
           java.lang.String perm_cmm_enrol,
           java.lang.String perm_cmm_points,
           java.lang.String perm_cmm_expend,
           java.lang.String perm_md_cmm_class,
           java.lang.String perm_md_cmm_rel_typ,
           java.lang.String perm_md_cmm_trans,
           java.lang.String perm_md_cmm_pay_terms,
           java.lang.String perm_md_cmm_typ,
           java.lang.String perm_md_cmm_status,
           java.lang.String perm_md_cmm_exp_typ,
           java.lang.String perm_fc,
           java.lang.String perm_osm_demand_opt,
           java.lang.String perm_osm_cost_sav,
           java.lang.String perm_fm,
           java.lang.String perm_fm_charging,
           java.lang.String perm_adm,
           java.lang.String perm_md_pr_man,
           java.lang.String perm_md_pr_prod_fam,
           java.lang.String perm_md_pr_prod,
           java.lang.String perm_md_pr_pur,
           java.lang.String perm_md_pr_art,
           java.lang.String perm_md_pr_dg_path,
           java.lang.String perm_md_pr_product_path,
           java.lang.String perm_md_pr_prod_dep,
           java.lang.String perm_md_pr_man_syn,
           java.lang.String perm_md_org_cont,
           java.lang.String perm_md_pr_inv_syn,
           java.lang.String perm_md_pr_sw_class,
           java.lang.String perm_md_org_sup,
           java.lang.String perm_md_pr_supp_art,
           java.lang.String perm_md_pr_lic_metr,
           java.lang.String perm_md_pr_lic_types,
           java.lang.String perm_md_pr_point_cat,
           java.lang.String perm_md_pr_tiers,
           java.lang.String perm_md_pr_status,
           java.lang.String perm_md_sys_sig_stat,
           java.lang.String perm_md_org_co,
           java.lang.String perm_md_org_bu,
           java.lang.String perm_md_org_cc,
           java.lang.String perm_md_org_loc,
           java.lang.String perm_md_org_proj,
           java.lang.String perm_md_org_rep,
           java.lang.String perm_md_dev_dev,
           java.lang.String perm_md_dev_dev_rel,
           java.lang.String perm_md_dev_dev_cap,
           java.lang.String perm_md_user_users,
           java.lang.String perm_md_user_acc,
           java.lang.String perm_md_user_perms,
           java.lang.String perm_md_dev_dev_rel_typ,
           java.lang.String perm_md_dev_dev_typ,
           java.lang.String perm_md_dev_dev_stat,
           java.lang.String perm_md_dev_cpu_typ,
           java.lang.String perm_exch_import,
           java.lang.String perm_exch_exch_dir,
           java.lang.String perm_exch_feeds,
           java.lang.String perm_exch_export,
           java.lang.String perm_exch_proc,
           java.lang.String perm_exch_steps,
           java.lang.String perm_exch_files,
           java.lang.String perm_exch_err_stat,
           java.lang.String perm_exch_err_det,
           java.lang.String perm_exch_import_stat,
           java.lang.String perm_exch_feed_cat,
           java.lang.String perm_exch_feed_stat,
           java.lang.String perm_admin,
           java.lang.String perm_md_glob_lang,
           java.lang.String perm_md_glob_reg,
           java.lang.String perm_md_glob_count,
           java.lang.String perm_md_glob_curr,
           java.lang.String perm_md_glob_ex,
           java.lang.String perm_md_sys_act_reas,
           java.lang.String perm_md_sys_perimeters,
           java.lang.String perm_md_sys_ds,
           java.lang.String perm_mm,
           java.lang.String perm_report,
           java.lang.String perm_fm_cpp) {
           this.app_role_id = app_role_id;
           this.import_id = import_id;
           this.data_source_id = data_source_id;
           this.name = name;
           this.remarks = remarks;
           this.perm_icm_compliance = perm_icm_compliance;
           this.perm_st = perm_st;
           this.perm_lic_cert = perm_lic_cert;
           this.perm_import = perm_import;
           this.perm_lic_upd_base = perm_lic_upd_base;
           this.perm_lic_move = perm_lic_move;
           this.perm_lic_transfer = perm_lic_transfer;
           this.perm_md_sys_lic_stat = perm_md_sys_lic_stat;
           this.perm_md_sys_lic_cl_stat = perm_md_sys_lic_cl_stat;
           this.perm_icm_usage = perm_icm_usage;
           this.perm_icm_me_hints = perm_icm_me_hints;
           this.perm_icm_raw = perm_icm_raw;
           this.perm_md_sys_inv_stat = perm_md_sys_inv_stat;
           this.perm_cmm_cont = perm_cmm_cont;
           this.perm_cmm_enrol = perm_cmm_enrol;
           this.perm_cmm_points = perm_cmm_points;
           this.perm_cmm_expend = perm_cmm_expend;
           this.perm_md_cmm_class = perm_md_cmm_class;
           this.perm_md_cmm_rel_typ = perm_md_cmm_rel_typ;
           this.perm_md_cmm_trans = perm_md_cmm_trans;
           this.perm_md_cmm_pay_terms = perm_md_cmm_pay_terms;
           this.perm_md_cmm_typ = perm_md_cmm_typ;
           this.perm_md_cmm_status = perm_md_cmm_status;
           this.perm_md_cmm_exp_typ = perm_md_cmm_exp_typ;
           this.perm_fc = perm_fc;
           this.perm_osm_demand_opt = perm_osm_demand_opt;
           this.perm_osm_cost_sav = perm_osm_cost_sav;
           this.perm_fm = perm_fm;
           this.perm_fm_charging = perm_fm_charging;
           this.perm_adm = perm_adm;
           this.perm_md_pr_man = perm_md_pr_man;
           this.perm_md_pr_prod_fam = perm_md_pr_prod_fam;
           this.perm_md_pr_prod = perm_md_pr_prod;
           this.perm_md_pr_pur = perm_md_pr_pur;
           this.perm_md_pr_art = perm_md_pr_art;
           this.perm_md_pr_dg_path = perm_md_pr_dg_path;
           this.perm_md_pr_product_path = perm_md_pr_product_path;
           this.perm_md_pr_prod_dep = perm_md_pr_prod_dep;
           this.perm_md_pr_man_syn = perm_md_pr_man_syn;
           this.perm_md_org_cont = perm_md_org_cont;
           this.perm_md_pr_inv_syn = perm_md_pr_inv_syn;
           this.perm_md_pr_sw_class = perm_md_pr_sw_class;
           this.perm_md_org_sup = perm_md_org_sup;
           this.perm_md_pr_supp_art = perm_md_pr_supp_art;
           this.perm_md_pr_lic_metr = perm_md_pr_lic_metr;
           this.perm_md_pr_lic_types = perm_md_pr_lic_types;
           this.perm_md_pr_point_cat = perm_md_pr_point_cat;
           this.perm_md_pr_tiers = perm_md_pr_tiers;
           this.perm_md_pr_status = perm_md_pr_status;
           this.perm_md_sys_sig_stat = perm_md_sys_sig_stat;
           this.perm_md_org_co = perm_md_org_co;
           this.perm_md_org_bu = perm_md_org_bu;
           this.perm_md_org_cc = perm_md_org_cc;
           this.perm_md_org_loc = perm_md_org_loc;
           this.perm_md_org_proj = perm_md_org_proj;
           this.perm_md_org_rep = perm_md_org_rep;
           this.perm_md_dev_dev = perm_md_dev_dev;
           this.perm_md_dev_dev_rel = perm_md_dev_dev_rel;
           this.perm_md_dev_dev_cap = perm_md_dev_dev_cap;
           this.perm_md_user_users = perm_md_user_users;
           this.perm_md_user_acc = perm_md_user_acc;
           this.perm_md_user_perms = perm_md_user_perms;
           this.perm_md_dev_dev_rel_typ = perm_md_dev_dev_rel_typ;
           this.perm_md_dev_dev_typ = perm_md_dev_dev_typ;
           this.perm_md_dev_dev_stat = perm_md_dev_dev_stat;
           this.perm_md_dev_cpu_typ = perm_md_dev_cpu_typ;
           this.perm_exch_import = perm_exch_import;
           this.perm_exch_exch_dir = perm_exch_exch_dir;
           this.perm_exch_feeds = perm_exch_feeds;
           this.perm_exch_export = perm_exch_export;
           this.perm_exch_proc = perm_exch_proc;
           this.perm_exch_steps = perm_exch_steps;
           this.perm_exch_files = perm_exch_files;
           this.perm_exch_err_stat = perm_exch_err_stat;
           this.perm_exch_err_det = perm_exch_err_det;
           this.perm_exch_import_stat = perm_exch_import_stat;
           this.perm_exch_feed_cat = perm_exch_feed_cat;
           this.perm_exch_feed_stat = perm_exch_feed_stat;
           this.perm_admin = perm_admin;
           this.perm_md_glob_lang = perm_md_glob_lang;
           this.perm_md_glob_reg = perm_md_glob_reg;
           this.perm_md_glob_count = perm_md_glob_count;
           this.perm_md_glob_curr = perm_md_glob_curr;
           this.perm_md_glob_ex = perm_md_glob_ex;
           this.perm_md_sys_act_reas = perm_md_sys_act_reas;
           this.perm_md_sys_perimeters = perm_md_sys_perimeters;
           this.perm_md_sys_ds = perm_md_sys_ds;
           this.perm_mm = perm_mm;
           this.perm_report = perm_report;
           this.perm_fm_cpp = perm_fm_cpp;
    }


    /**
     * Gets the app_role_id value for this App_role_rec.
     * 
     * @return app_role_id
     */
    public int getApp_role_id() {
        return app_role_id;
    }


    /**
     * Sets the app_role_id value for this App_role_rec.
     * 
     * @param app_role_id
     */
    public void setApp_role_id(int app_role_id) {
        this.app_role_id = app_role_id;
    }


    /**
     * Gets the import_id value for this App_role_rec.
     * 
     * @return import_id
     */
    public java.lang.String getImport_id() {
        return import_id;
    }


    /**
     * Sets the import_id value for this App_role_rec.
     * 
     * @param import_id
     */
    public void setImport_id(java.lang.String import_id) {
        this.import_id = import_id;
    }


    /**
     * Gets the data_source_id value for this App_role_rec.
     * 
     * @return data_source_id
     */
    public int getData_source_id() {
        return data_source_id;
    }


    /**
     * Sets the data_source_id value for this App_role_rec.
     * 
     * @param data_source_id
     */
    public void setData_source_id(int data_source_id) {
        this.data_source_id = data_source_id;
    }


    /**
     * Gets the name value for this App_role_rec.
     * 
     * @return name
     */
    public java.lang.String getName() {
        return name;
    }


    /**
     * Sets the name value for this App_role_rec.
     * 
     * @param name
     */
    public void setName(java.lang.String name) {
        this.name = name;
    }


    /**
     * Gets the remarks value for this App_role_rec.
     * 
     * @return remarks
     */
    public java.lang.String getRemarks() {
        return remarks;
    }


    /**
     * Sets the remarks value for this App_role_rec.
     * 
     * @param remarks
     */
    public void setRemarks(java.lang.String remarks) {
        this.remarks = remarks;
    }


    /**
     * Gets the perm_icm_compliance value for this App_role_rec.
     * 
     * @return perm_icm_compliance
     */
    public java.lang.String getPerm_icm_compliance() {
        return perm_icm_compliance;
    }


    /**
     * Sets the perm_icm_compliance value for this App_role_rec.
     * 
     * @param perm_icm_compliance
     */
    public void setPerm_icm_compliance(java.lang.String perm_icm_compliance) {
        this.perm_icm_compliance = perm_icm_compliance;
    }


    /**
     * Gets the perm_st value for this App_role_rec.
     * 
     * @return perm_st
     */
    public java.lang.String getPerm_st() {
        return perm_st;
    }


    /**
     * Sets the perm_st value for this App_role_rec.
     * 
     * @param perm_st
     */
    public void setPerm_st(java.lang.String perm_st) {
        this.perm_st = perm_st;
    }


    /**
     * Gets the perm_lic_cert value for this App_role_rec.
     * 
     * @return perm_lic_cert
     */
    public java.lang.String getPerm_lic_cert() {
        return perm_lic_cert;
    }


    /**
     * Sets the perm_lic_cert value for this App_role_rec.
     * 
     * @param perm_lic_cert
     */
    public void setPerm_lic_cert(java.lang.String perm_lic_cert) {
        this.perm_lic_cert = perm_lic_cert;
    }


    /**
     * Gets the perm_import value for this App_role_rec.
     * 
     * @return perm_import
     */
    public java.lang.String getPerm_import() {
        return perm_import;
    }


    /**
     * Sets the perm_import value for this App_role_rec.
     * 
     * @param perm_import
     */
    public void setPerm_import(java.lang.String perm_import) {
        this.perm_import = perm_import;
    }


    /**
     * Gets the perm_lic_upd_base value for this App_role_rec.
     * 
     * @return perm_lic_upd_base
     */
    public java.lang.String getPerm_lic_upd_base() {
        return perm_lic_upd_base;
    }


    /**
     * Sets the perm_lic_upd_base value for this App_role_rec.
     * 
     * @param perm_lic_upd_base
     */
    public void setPerm_lic_upd_base(java.lang.String perm_lic_upd_base) {
        this.perm_lic_upd_base = perm_lic_upd_base;
    }


    /**
     * Gets the perm_lic_move value for this App_role_rec.
     * 
     * @return perm_lic_move
     */
    public java.lang.String getPerm_lic_move() {
        return perm_lic_move;
    }


    /**
     * Sets the perm_lic_move value for this App_role_rec.
     * 
     * @param perm_lic_move
     */
    public void setPerm_lic_move(java.lang.String perm_lic_move) {
        this.perm_lic_move = perm_lic_move;
    }


    /**
     * Gets the perm_lic_transfer value for this App_role_rec.
     * 
     * @return perm_lic_transfer
     */
    public java.lang.String getPerm_lic_transfer() {
        return perm_lic_transfer;
    }


    /**
     * Sets the perm_lic_transfer value for this App_role_rec.
     * 
     * @param perm_lic_transfer
     */
    public void setPerm_lic_transfer(java.lang.String perm_lic_transfer) {
        this.perm_lic_transfer = perm_lic_transfer;
    }


    /**
     * Gets the perm_md_sys_lic_stat value for this App_role_rec.
     * 
     * @return perm_md_sys_lic_stat
     */
    public java.lang.String getPerm_md_sys_lic_stat() {
        return perm_md_sys_lic_stat;
    }


    /**
     * Sets the perm_md_sys_lic_stat value for this App_role_rec.
     * 
     * @param perm_md_sys_lic_stat
     */
    public void setPerm_md_sys_lic_stat(java.lang.String perm_md_sys_lic_stat) {
        this.perm_md_sys_lic_stat = perm_md_sys_lic_stat;
    }


    /**
     * Gets the perm_md_sys_lic_cl_stat value for this App_role_rec.
     * 
     * @return perm_md_sys_lic_cl_stat
     */
    public java.lang.String getPerm_md_sys_lic_cl_stat() {
        return perm_md_sys_lic_cl_stat;
    }


    /**
     * Sets the perm_md_sys_lic_cl_stat value for this App_role_rec.
     * 
     * @param perm_md_sys_lic_cl_stat
     */
    public void setPerm_md_sys_lic_cl_stat(java.lang.String perm_md_sys_lic_cl_stat) {
        this.perm_md_sys_lic_cl_stat = perm_md_sys_lic_cl_stat;
    }


    /**
     * Gets the perm_icm_usage value for this App_role_rec.
     * 
     * @return perm_icm_usage
     */
    public java.lang.String getPerm_icm_usage() {
        return perm_icm_usage;
    }


    /**
     * Sets the perm_icm_usage value for this App_role_rec.
     * 
     * @param perm_icm_usage
     */
    public void setPerm_icm_usage(java.lang.String perm_icm_usage) {
        this.perm_icm_usage = perm_icm_usage;
    }


    /**
     * Gets the perm_icm_me_hints value for this App_role_rec.
     * 
     * @return perm_icm_me_hints
     */
    public java.lang.String getPerm_icm_me_hints() {
        return perm_icm_me_hints;
    }


    /**
     * Sets the perm_icm_me_hints value for this App_role_rec.
     * 
     * @param perm_icm_me_hints
     */
    public void setPerm_icm_me_hints(java.lang.String perm_icm_me_hints) {
        this.perm_icm_me_hints = perm_icm_me_hints;
    }


    /**
     * Gets the perm_icm_raw value for this App_role_rec.
     * 
     * @return perm_icm_raw
     */
    public java.lang.String getPerm_icm_raw() {
        return perm_icm_raw;
    }


    /**
     * Sets the perm_icm_raw value for this App_role_rec.
     * 
     * @param perm_icm_raw
     */
    public void setPerm_icm_raw(java.lang.String perm_icm_raw) {
        this.perm_icm_raw = perm_icm_raw;
    }


    /**
     * Gets the perm_md_sys_inv_stat value for this App_role_rec.
     * 
     * @return perm_md_sys_inv_stat
     */
    public java.lang.String getPerm_md_sys_inv_stat() {
        return perm_md_sys_inv_stat;
    }


    /**
     * Sets the perm_md_sys_inv_stat value for this App_role_rec.
     * 
     * @param perm_md_sys_inv_stat
     */
    public void setPerm_md_sys_inv_stat(java.lang.String perm_md_sys_inv_stat) {
        this.perm_md_sys_inv_stat = perm_md_sys_inv_stat;
    }


    /**
     * Gets the perm_cmm_cont value for this App_role_rec.
     * 
     * @return perm_cmm_cont
     */
    public java.lang.String getPerm_cmm_cont() {
        return perm_cmm_cont;
    }


    /**
     * Sets the perm_cmm_cont value for this App_role_rec.
     * 
     * @param perm_cmm_cont
     */
    public void setPerm_cmm_cont(java.lang.String perm_cmm_cont) {
        this.perm_cmm_cont = perm_cmm_cont;
    }


    /**
     * Gets the perm_cmm_enrol value for this App_role_rec.
     * 
     * @return perm_cmm_enrol
     */
    public java.lang.String getPerm_cmm_enrol() {
        return perm_cmm_enrol;
    }


    /**
     * Sets the perm_cmm_enrol value for this App_role_rec.
     * 
     * @param perm_cmm_enrol
     */
    public void setPerm_cmm_enrol(java.lang.String perm_cmm_enrol) {
        this.perm_cmm_enrol = perm_cmm_enrol;
    }


    /**
     * Gets the perm_cmm_points value for this App_role_rec.
     * 
     * @return perm_cmm_points
     */
    public java.lang.String getPerm_cmm_points() {
        return perm_cmm_points;
    }


    /**
     * Sets the perm_cmm_points value for this App_role_rec.
     * 
     * @param perm_cmm_points
     */
    public void setPerm_cmm_points(java.lang.String perm_cmm_points) {
        this.perm_cmm_points = perm_cmm_points;
    }


    /**
     * Gets the perm_cmm_expend value for this App_role_rec.
     * 
     * @return perm_cmm_expend
     */
    public java.lang.String getPerm_cmm_expend() {
        return perm_cmm_expend;
    }


    /**
     * Sets the perm_cmm_expend value for this App_role_rec.
     * 
     * @param perm_cmm_expend
     */
    public void setPerm_cmm_expend(java.lang.String perm_cmm_expend) {
        this.perm_cmm_expend = perm_cmm_expend;
    }


    /**
     * Gets the perm_md_cmm_class value for this App_role_rec.
     * 
     * @return perm_md_cmm_class
     */
    public java.lang.String getPerm_md_cmm_class() {
        return perm_md_cmm_class;
    }


    /**
     * Sets the perm_md_cmm_class value for this App_role_rec.
     * 
     * @param perm_md_cmm_class
     */
    public void setPerm_md_cmm_class(java.lang.String perm_md_cmm_class) {
        this.perm_md_cmm_class = perm_md_cmm_class;
    }


    /**
     * Gets the perm_md_cmm_rel_typ value for this App_role_rec.
     * 
     * @return perm_md_cmm_rel_typ
     */
    public java.lang.String getPerm_md_cmm_rel_typ() {
        return perm_md_cmm_rel_typ;
    }


    /**
     * Sets the perm_md_cmm_rel_typ value for this App_role_rec.
     * 
     * @param perm_md_cmm_rel_typ
     */
    public void setPerm_md_cmm_rel_typ(java.lang.String perm_md_cmm_rel_typ) {
        this.perm_md_cmm_rel_typ = perm_md_cmm_rel_typ;
    }


    /**
     * Gets the perm_md_cmm_trans value for this App_role_rec.
     * 
     * @return perm_md_cmm_trans
     */
    public java.lang.String getPerm_md_cmm_trans() {
        return perm_md_cmm_trans;
    }


    /**
     * Sets the perm_md_cmm_trans value for this App_role_rec.
     * 
     * @param perm_md_cmm_trans
     */
    public void setPerm_md_cmm_trans(java.lang.String perm_md_cmm_trans) {
        this.perm_md_cmm_trans = perm_md_cmm_trans;
    }


    /**
     * Gets the perm_md_cmm_pay_terms value for this App_role_rec.
     * 
     * @return perm_md_cmm_pay_terms
     */
    public java.lang.String getPerm_md_cmm_pay_terms() {
        return perm_md_cmm_pay_terms;
    }


    /**
     * Sets the perm_md_cmm_pay_terms value for this App_role_rec.
     * 
     * @param perm_md_cmm_pay_terms
     */
    public void setPerm_md_cmm_pay_terms(java.lang.String perm_md_cmm_pay_terms) {
        this.perm_md_cmm_pay_terms = perm_md_cmm_pay_terms;
    }


    /**
     * Gets the perm_md_cmm_typ value for this App_role_rec.
     * 
     * @return perm_md_cmm_typ
     */
    public java.lang.String getPerm_md_cmm_typ() {
        return perm_md_cmm_typ;
    }


    /**
     * Sets the perm_md_cmm_typ value for this App_role_rec.
     * 
     * @param perm_md_cmm_typ
     */
    public void setPerm_md_cmm_typ(java.lang.String perm_md_cmm_typ) {
        this.perm_md_cmm_typ = perm_md_cmm_typ;
    }


    /**
     * Gets the perm_md_cmm_status value for this App_role_rec.
     * 
     * @return perm_md_cmm_status
     */
    public java.lang.String getPerm_md_cmm_status() {
        return perm_md_cmm_status;
    }


    /**
     * Sets the perm_md_cmm_status value for this App_role_rec.
     * 
     * @param perm_md_cmm_status
     */
    public void setPerm_md_cmm_status(java.lang.String perm_md_cmm_status) {
        this.perm_md_cmm_status = perm_md_cmm_status;
    }


    /**
     * Gets the perm_md_cmm_exp_typ value for this App_role_rec.
     * 
     * @return perm_md_cmm_exp_typ
     */
    public java.lang.String getPerm_md_cmm_exp_typ() {
        return perm_md_cmm_exp_typ;
    }


    /**
     * Sets the perm_md_cmm_exp_typ value for this App_role_rec.
     * 
     * @param perm_md_cmm_exp_typ
     */
    public void setPerm_md_cmm_exp_typ(java.lang.String perm_md_cmm_exp_typ) {
        this.perm_md_cmm_exp_typ = perm_md_cmm_exp_typ;
    }


    /**
     * Gets the perm_fc value for this App_role_rec.
     * 
     * @return perm_fc
     */
    public java.lang.String getPerm_fc() {
        return perm_fc;
    }


    /**
     * Sets the perm_fc value for this App_role_rec.
     * 
     * @param perm_fc
     */
    public void setPerm_fc(java.lang.String perm_fc) {
        this.perm_fc = perm_fc;
    }


    /**
     * Gets the perm_osm_demand_opt value for this App_role_rec.
     * 
     * @return perm_osm_demand_opt
     */
    public java.lang.String getPerm_osm_demand_opt() {
        return perm_osm_demand_opt;
    }


    /**
     * Sets the perm_osm_demand_opt value for this App_role_rec.
     * 
     * @param perm_osm_demand_opt
     */
    public void setPerm_osm_demand_opt(java.lang.String perm_osm_demand_opt) {
        this.perm_osm_demand_opt = perm_osm_demand_opt;
    }


    /**
     * Gets the perm_osm_cost_sav value for this App_role_rec.
     * 
     * @return perm_osm_cost_sav
     */
    public java.lang.String getPerm_osm_cost_sav() {
        return perm_osm_cost_sav;
    }


    /**
     * Sets the perm_osm_cost_sav value for this App_role_rec.
     * 
     * @param perm_osm_cost_sav
     */
    public void setPerm_osm_cost_sav(java.lang.String perm_osm_cost_sav) {
        this.perm_osm_cost_sav = perm_osm_cost_sav;
    }


    /**
     * Gets the perm_fm value for this App_role_rec.
     * 
     * @return perm_fm
     */
    public java.lang.String getPerm_fm() {
        return perm_fm;
    }


    /**
     * Sets the perm_fm value for this App_role_rec.
     * 
     * @param perm_fm
     */
    public void setPerm_fm(java.lang.String perm_fm) {
        this.perm_fm = perm_fm;
    }


    /**
     * Gets the perm_fm_charging value for this App_role_rec.
     * 
     * @return perm_fm_charging
     */
    public java.lang.String getPerm_fm_charging() {
        return perm_fm_charging;
    }


    /**
     * Sets the perm_fm_charging value for this App_role_rec.
     * 
     * @param perm_fm_charging
     */
    public void setPerm_fm_charging(java.lang.String perm_fm_charging) {
        this.perm_fm_charging = perm_fm_charging;
    }


    /**
     * Gets the perm_adm value for this App_role_rec.
     * 
     * @return perm_adm
     */
    public java.lang.String getPerm_adm() {
        return perm_adm;
    }


    /**
     * Sets the perm_adm value for this App_role_rec.
     * 
     * @param perm_adm
     */
    public void setPerm_adm(java.lang.String perm_adm) {
        this.perm_adm = perm_adm;
    }


    /**
     * Gets the perm_md_pr_man value for this App_role_rec.
     * 
     * @return perm_md_pr_man
     */
    public java.lang.String getPerm_md_pr_man() {
        return perm_md_pr_man;
    }


    /**
     * Sets the perm_md_pr_man value for this App_role_rec.
     * 
     * @param perm_md_pr_man
     */
    public void setPerm_md_pr_man(java.lang.String perm_md_pr_man) {
        this.perm_md_pr_man = perm_md_pr_man;
    }


    /**
     * Gets the perm_md_pr_prod_fam value for this App_role_rec.
     * 
     * @return perm_md_pr_prod_fam
     */
    public java.lang.String getPerm_md_pr_prod_fam() {
        return perm_md_pr_prod_fam;
    }


    /**
     * Sets the perm_md_pr_prod_fam value for this App_role_rec.
     * 
     * @param perm_md_pr_prod_fam
     */
    public void setPerm_md_pr_prod_fam(java.lang.String perm_md_pr_prod_fam) {
        this.perm_md_pr_prod_fam = perm_md_pr_prod_fam;
    }


    /**
     * Gets the perm_md_pr_prod value for this App_role_rec.
     * 
     * @return perm_md_pr_prod
     */
    public java.lang.String getPerm_md_pr_prod() {
        return perm_md_pr_prod;
    }


    /**
     * Sets the perm_md_pr_prod value for this App_role_rec.
     * 
     * @param perm_md_pr_prod
     */
    public void setPerm_md_pr_prod(java.lang.String perm_md_pr_prod) {
        this.perm_md_pr_prod = perm_md_pr_prod;
    }


    /**
     * Gets the perm_md_pr_pur value for this App_role_rec.
     * 
     * @return perm_md_pr_pur
     */
    public java.lang.String getPerm_md_pr_pur() {
        return perm_md_pr_pur;
    }


    /**
     * Sets the perm_md_pr_pur value for this App_role_rec.
     * 
     * @param perm_md_pr_pur
     */
    public void setPerm_md_pr_pur(java.lang.String perm_md_pr_pur) {
        this.perm_md_pr_pur = perm_md_pr_pur;
    }


    /**
     * Gets the perm_md_pr_art value for this App_role_rec.
     * 
     * @return perm_md_pr_art
     */
    public java.lang.String getPerm_md_pr_art() {
        return perm_md_pr_art;
    }


    /**
     * Sets the perm_md_pr_art value for this App_role_rec.
     * 
     * @param perm_md_pr_art
     */
    public void setPerm_md_pr_art(java.lang.String perm_md_pr_art) {
        this.perm_md_pr_art = perm_md_pr_art;
    }


    /**
     * Gets the perm_md_pr_dg_path value for this App_role_rec.
     * 
     * @return perm_md_pr_dg_path
     */
    public java.lang.String getPerm_md_pr_dg_path() {
        return perm_md_pr_dg_path;
    }


    /**
     * Sets the perm_md_pr_dg_path value for this App_role_rec.
     * 
     * @param perm_md_pr_dg_path
     */
    public void setPerm_md_pr_dg_path(java.lang.String perm_md_pr_dg_path) {
        this.perm_md_pr_dg_path = perm_md_pr_dg_path;
    }


    /**
     * Gets the perm_md_pr_product_path value for this App_role_rec.
     * 
     * @return perm_md_pr_product_path
     */
    public java.lang.String getPerm_md_pr_product_path() {
        return perm_md_pr_product_path;
    }


    /**
     * Sets the perm_md_pr_product_path value for this App_role_rec.
     * 
     * @param perm_md_pr_product_path
     */
    public void setPerm_md_pr_product_path(java.lang.String perm_md_pr_product_path) {
        this.perm_md_pr_product_path = perm_md_pr_product_path;
    }


    /**
     * Gets the perm_md_pr_prod_dep value for this App_role_rec.
     * 
     * @return perm_md_pr_prod_dep
     */
    public java.lang.String getPerm_md_pr_prod_dep() {
        return perm_md_pr_prod_dep;
    }


    /**
     * Sets the perm_md_pr_prod_dep value for this App_role_rec.
     * 
     * @param perm_md_pr_prod_dep
     */
    public void setPerm_md_pr_prod_dep(java.lang.String perm_md_pr_prod_dep) {
        this.perm_md_pr_prod_dep = perm_md_pr_prod_dep;
    }


    /**
     * Gets the perm_md_pr_man_syn value for this App_role_rec.
     * 
     * @return perm_md_pr_man_syn
     */
    public java.lang.String getPerm_md_pr_man_syn() {
        return perm_md_pr_man_syn;
    }


    /**
     * Sets the perm_md_pr_man_syn value for this App_role_rec.
     * 
     * @param perm_md_pr_man_syn
     */
    public void setPerm_md_pr_man_syn(java.lang.String perm_md_pr_man_syn) {
        this.perm_md_pr_man_syn = perm_md_pr_man_syn;
    }


    /**
     * Gets the perm_md_org_cont value for this App_role_rec.
     * 
     * @return perm_md_org_cont
     */
    public java.lang.String getPerm_md_org_cont() {
        return perm_md_org_cont;
    }


    /**
     * Sets the perm_md_org_cont value for this App_role_rec.
     * 
     * @param perm_md_org_cont
     */
    public void setPerm_md_org_cont(java.lang.String perm_md_org_cont) {
        this.perm_md_org_cont = perm_md_org_cont;
    }


    /**
     * Gets the perm_md_pr_inv_syn value for this App_role_rec.
     * 
     * @return perm_md_pr_inv_syn
     */
    public java.lang.String getPerm_md_pr_inv_syn() {
        return perm_md_pr_inv_syn;
    }


    /**
     * Sets the perm_md_pr_inv_syn value for this App_role_rec.
     * 
     * @param perm_md_pr_inv_syn
     */
    public void setPerm_md_pr_inv_syn(java.lang.String perm_md_pr_inv_syn) {
        this.perm_md_pr_inv_syn = perm_md_pr_inv_syn;
    }


    /**
     * Gets the perm_md_pr_sw_class value for this App_role_rec.
     * 
     * @return perm_md_pr_sw_class
     */
    public java.lang.String getPerm_md_pr_sw_class() {
        return perm_md_pr_sw_class;
    }


    /**
     * Sets the perm_md_pr_sw_class value for this App_role_rec.
     * 
     * @param perm_md_pr_sw_class
     */
    public void setPerm_md_pr_sw_class(java.lang.String perm_md_pr_sw_class) {
        this.perm_md_pr_sw_class = perm_md_pr_sw_class;
    }


    /**
     * Gets the perm_md_org_sup value for this App_role_rec.
     * 
     * @return perm_md_org_sup
     */
    public java.lang.String getPerm_md_org_sup() {
        return perm_md_org_sup;
    }


    /**
     * Sets the perm_md_org_sup value for this App_role_rec.
     * 
     * @param perm_md_org_sup
     */
    public void setPerm_md_org_sup(java.lang.String perm_md_org_sup) {
        this.perm_md_org_sup = perm_md_org_sup;
    }


    /**
     * Gets the perm_md_pr_supp_art value for this App_role_rec.
     * 
     * @return perm_md_pr_supp_art
     */
    public java.lang.String getPerm_md_pr_supp_art() {
        return perm_md_pr_supp_art;
    }


    /**
     * Sets the perm_md_pr_supp_art value for this App_role_rec.
     * 
     * @param perm_md_pr_supp_art
     */
    public void setPerm_md_pr_supp_art(java.lang.String perm_md_pr_supp_art) {
        this.perm_md_pr_supp_art = perm_md_pr_supp_art;
    }


    /**
     * Gets the perm_md_pr_lic_metr value for this App_role_rec.
     * 
     * @return perm_md_pr_lic_metr
     */
    public java.lang.String getPerm_md_pr_lic_metr() {
        return perm_md_pr_lic_metr;
    }


    /**
     * Sets the perm_md_pr_lic_metr value for this App_role_rec.
     * 
     * @param perm_md_pr_lic_metr
     */
    public void setPerm_md_pr_lic_metr(java.lang.String perm_md_pr_lic_metr) {
        this.perm_md_pr_lic_metr = perm_md_pr_lic_metr;
    }


    /**
     * Gets the perm_md_pr_lic_types value for this App_role_rec.
     * 
     * @return perm_md_pr_lic_types
     */
    public java.lang.String getPerm_md_pr_lic_types() {
        return perm_md_pr_lic_types;
    }


    /**
     * Sets the perm_md_pr_lic_types value for this App_role_rec.
     * 
     * @param perm_md_pr_lic_types
     */
    public void setPerm_md_pr_lic_types(java.lang.String perm_md_pr_lic_types) {
        this.perm_md_pr_lic_types = perm_md_pr_lic_types;
    }


    /**
     * Gets the perm_md_pr_point_cat value for this App_role_rec.
     * 
     * @return perm_md_pr_point_cat
     */
    public java.lang.String getPerm_md_pr_point_cat() {
        return perm_md_pr_point_cat;
    }


    /**
     * Sets the perm_md_pr_point_cat value for this App_role_rec.
     * 
     * @param perm_md_pr_point_cat
     */
    public void setPerm_md_pr_point_cat(java.lang.String perm_md_pr_point_cat) {
        this.perm_md_pr_point_cat = perm_md_pr_point_cat;
    }


    /**
     * Gets the perm_md_pr_tiers value for this App_role_rec.
     * 
     * @return perm_md_pr_tiers
     */
    public java.lang.String getPerm_md_pr_tiers() {
        return perm_md_pr_tiers;
    }


    /**
     * Sets the perm_md_pr_tiers value for this App_role_rec.
     * 
     * @param perm_md_pr_tiers
     */
    public void setPerm_md_pr_tiers(java.lang.String perm_md_pr_tiers) {
        this.perm_md_pr_tiers = perm_md_pr_tiers;
    }


    /**
     * Gets the perm_md_pr_status value for this App_role_rec.
     * 
     * @return perm_md_pr_status
     */
    public java.lang.String getPerm_md_pr_status() {
        return perm_md_pr_status;
    }


    /**
     * Sets the perm_md_pr_status value for this App_role_rec.
     * 
     * @param perm_md_pr_status
     */
    public void setPerm_md_pr_status(java.lang.String perm_md_pr_status) {
        this.perm_md_pr_status = perm_md_pr_status;
    }


    /**
     * Gets the perm_md_sys_sig_stat value for this App_role_rec.
     * 
     * @return perm_md_sys_sig_stat
     */
    public java.lang.String getPerm_md_sys_sig_stat() {
        return perm_md_sys_sig_stat;
    }


    /**
     * Sets the perm_md_sys_sig_stat value for this App_role_rec.
     * 
     * @param perm_md_sys_sig_stat
     */
    public void setPerm_md_sys_sig_stat(java.lang.String perm_md_sys_sig_stat) {
        this.perm_md_sys_sig_stat = perm_md_sys_sig_stat;
    }


    /**
     * Gets the perm_md_org_co value for this App_role_rec.
     * 
     * @return perm_md_org_co
     */
    public java.lang.String getPerm_md_org_co() {
        return perm_md_org_co;
    }


    /**
     * Sets the perm_md_org_co value for this App_role_rec.
     * 
     * @param perm_md_org_co
     */
    public void setPerm_md_org_co(java.lang.String perm_md_org_co) {
        this.perm_md_org_co = perm_md_org_co;
    }


    /**
     * Gets the perm_md_org_bu value for this App_role_rec.
     * 
     * @return perm_md_org_bu
     */
    public java.lang.String getPerm_md_org_bu() {
        return perm_md_org_bu;
    }


    /**
     * Sets the perm_md_org_bu value for this App_role_rec.
     * 
     * @param perm_md_org_bu
     */
    public void setPerm_md_org_bu(java.lang.String perm_md_org_bu) {
        this.perm_md_org_bu = perm_md_org_bu;
    }


    /**
     * Gets the perm_md_org_cc value for this App_role_rec.
     * 
     * @return perm_md_org_cc
     */
    public java.lang.String getPerm_md_org_cc() {
        return perm_md_org_cc;
    }


    /**
     * Sets the perm_md_org_cc value for this App_role_rec.
     * 
     * @param perm_md_org_cc
     */
    public void setPerm_md_org_cc(java.lang.String perm_md_org_cc) {
        this.perm_md_org_cc = perm_md_org_cc;
    }


    /**
     * Gets the perm_md_org_loc value for this App_role_rec.
     * 
     * @return perm_md_org_loc
     */
    public java.lang.String getPerm_md_org_loc() {
        return perm_md_org_loc;
    }


    /**
     * Sets the perm_md_org_loc value for this App_role_rec.
     * 
     * @param perm_md_org_loc
     */
    public void setPerm_md_org_loc(java.lang.String perm_md_org_loc) {
        this.perm_md_org_loc = perm_md_org_loc;
    }


    /**
     * Gets the perm_md_org_proj value for this App_role_rec.
     * 
     * @return perm_md_org_proj
     */
    public java.lang.String getPerm_md_org_proj() {
        return perm_md_org_proj;
    }


    /**
     * Sets the perm_md_org_proj value for this App_role_rec.
     * 
     * @param perm_md_org_proj
     */
    public void setPerm_md_org_proj(java.lang.String perm_md_org_proj) {
        this.perm_md_org_proj = perm_md_org_proj;
    }


    /**
     * Gets the perm_md_org_rep value for this App_role_rec.
     * 
     * @return perm_md_org_rep
     */
    public java.lang.String getPerm_md_org_rep() {
        return perm_md_org_rep;
    }


    /**
     * Sets the perm_md_org_rep value for this App_role_rec.
     * 
     * @param perm_md_org_rep
     */
    public void setPerm_md_org_rep(java.lang.String perm_md_org_rep) {
        this.perm_md_org_rep = perm_md_org_rep;
    }


    /**
     * Gets the perm_md_dev_dev value for this App_role_rec.
     * 
     * @return perm_md_dev_dev
     */
    public java.lang.String getPerm_md_dev_dev() {
        return perm_md_dev_dev;
    }


    /**
     * Sets the perm_md_dev_dev value for this App_role_rec.
     * 
     * @param perm_md_dev_dev
     */
    public void setPerm_md_dev_dev(java.lang.String perm_md_dev_dev) {
        this.perm_md_dev_dev = perm_md_dev_dev;
    }


    /**
     * Gets the perm_md_dev_dev_rel value for this App_role_rec.
     * 
     * @return perm_md_dev_dev_rel
     */
    public java.lang.String getPerm_md_dev_dev_rel() {
        return perm_md_dev_dev_rel;
    }


    /**
     * Sets the perm_md_dev_dev_rel value for this App_role_rec.
     * 
     * @param perm_md_dev_dev_rel
     */
    public void setPerm_md_dev_dev_rel(java.lang.String perm_md_dev_dev_rel) {
        this.perm_md_dev_dev_rel = perm_md_dev_dev_rel;
    }


    /**
     * Gets the perm_md_dev_dev_cap value for this App_role_rec.
     * 
     * @return perm_md_dev_dev_cap
     */
    public java.lang.String getPerm_md_dev_dev_cap() {
        return perm_md_dev_dev_cap;
    }


    /**
     * Sets the perm_md_dev_dev_cap value for this App_role_rec.
     * 
     * @param perm_md_dev_dev_cap
     */
    public void setPerm_md_dev_dev_cap(java.lang.String perm_md_dev_dev_cap) {
        this.perm_md_dev_dev_cap = perm_md_dev_dev_cap;
    }


    /**
     * Gets the perm_md_user_users value for this App_role_rec.
     * 
     * @return perm_md_user_users
     */
    public java.lang.String getPerm_md_user_users() {
        return perm_md_user_users;
    }


    /**
     * Sets the perm_md_user_users value for this App_role_rec.
     * 
     * @param perm_md_user_users
     */
    public void setPerm_md_user_users(java.lang.String perm_md_user_users) {
        this.perm_md_user_users = perm_md_user_users;
    }


    /**
     * Gets the perm_md_user_acc value for this App_role_rec.
     * 
     * @return perm_md_user_acc
     */
    public java.lang.String getPerm_md_user_acc() {
        return perm_md_user_acc;
    }


    /**
     * Sets the perm_md_user_acc value for this App_role_rec.
     * 
     * @param perm_md_user_acc
     */
    public void setPerm_md_user_acc(java.lang.String perm_md_user_acc) {
        this.perm_md_user_acc = perm_md_user_acc;
    }


    /**
     * Gets the perm_md_user_perms value for this App_role_rec.
     * 
     * @return perm_md_user_perms
     */
    public java.lang.String getPerm_md_user_perms() {
        return perm_md_user_perms;
    }


    /**
     * Sets the perm_md_user_perms value for this App_role_rec.
     * 
     * @param perm_md_user_perms
     */
    public void setPerm_md_user_perms(java.lang.String perm_md_user_perms) {
        this.perm_md_user_perms = perm_md_user_perms;
    }


    /**
     * Gets the perm_md_dev_dev_rel_typ value for this App_role_rec.
     * 
     * @return perm_md_dev_dev_rel_typ
     */
    public java.lang.String getPerm_md_dev_dev_rel_typ() {
        return perm_md_dev_dev_rel_typ;
    }


    /**
     * Sets the perm_md_dev_dev_rel_typ value for this App_role_rec.
     * 
     * @param perm_md_dev_dev_rel_typ
     */
    public void setPerm_md_dev_dev_rel_typ(java.lang.String perm_md_dev_dev_rel_typ) {
        this.perm_md_dev_dev_rel_typ = perm_md_dev_dev_rel_typ;
    }


    /**
     * Gets the perm_md_dev_dev_typ value for this App_role_rec.
     * 
     * @return perm_md_dev_dev_typ
     */
    public java.lang.String getPerm_md_dev_dev_typ() {
        return perm_md_dev_dev_typ;
    }


    /**
     * Sets the perm_md_dev_dev_typ value for this App_role_rec.
     * 
     * @param perm_md_dev_dev_typ
     */
    public void setPerm_md_dev_dev_typ(java.lang.String perm_md_dev_dev_typ) {
        this.perm_md_dev_dev_typ = perm_md_dev_dev_typ;
    }


    /**
     * Gets the perm_md_dev_dev_stat value for this App_role_rec.
     * 
     * @return perm_md_dev_dev_stat
     */
    public java.lang.String getPerm_md_dev_dev_stat() {
        return perm_md_dev_dev_stat;
    }


    /**
     * Sets the perm_md_dev_dev_stat value for this App_role_rec.
     * 
     * @param perm_md_dev_dev_stat
     */
    public void setPerm_md_dev_dev_stat(java.lang.String perm_md_dev_dev_stat) {
        this.perm_md_dev_dev_stat = perm_md_dev_dev_stat;
    }


    /**
     * Gets the perm_md_dev_cpu_typ value for this App_role_rec.
     * 
     * @return perm_md_dev_cpu_typ
     */
    public java.lang.String getPerm_md_dev_cpu_typ() {
        return perm_md_dev_cpu_typ;
    }


    /**
     * Sets the perm_md_dev_cpu_typ value for this App_role_rec.
     * 
     * @param perm_md_dev_cpu_typ
     */
    public void setPerm_md_dev_cpu_typ(java.lang.String perm_md_dev_cpu_typ) {
        this.perm_md_dev_cpu_typ = perm_md_dev_cpu_typ;
    }


    /**
     * Gets the perm_exch_import value for this App_role_rec.
     * 
     * @return perm_exch_import
     */
    public java.lang.String getPerm_exch_import() {
        return perm_exch_import;
    }


    /**
     * Sets the perm_exch_import value for this App_role_rec.
     * 
     * @param perm_exch_import
     */
    public void setPerm_exch_import(java.lang.String perm_exch_import) {
        this.perm_exch_import = perm_exch_import;
    }


    /**
     * Gets the perm_exch_exch_dir value for this App_role_rec.
     * 
     * @return perm_exch_exch_dir
     */
    public java.lang.String getPerm_exch_exch_dir() {
        return perm_exch_exch_dir;
    }


    /**
     * Sets the perm_exch_exch_dir value for this App_role_rec.
     * 
     * @param perm_exch_exch_dir
     */
    public void setPerm_exch_exch_dir(java.lang.String perm_exch_exch_dir) {
        this.perm_exch_exch_dir = perm_exch_exch_dir;
    }


    /**
     * Gets the perm_exch_feeds value for this App_role_rec.
     * 
     * @return perm_exch_feeds
     */
    public java.lang.String getPerm_exch_feeds() {
        return perm_exch_feeds;
    }


    /**
     * Sets the perm_exch_feeds value for this App_role_rec.
     * 
     * @param perm_exch_feeds
     */
    public void setPerm_exch_feeds(java.lang.String perm_exch_feeds) {
        this.perm_exch_feeds = perm_exch_feeds;
    }


    /**
     * Gets the perm_exch_export value for this App_role_rec.
     * 
     * @return perm_exch_export
     */
    public java.lang.String getPerm_exch_export() {
        return perm_exch_export;
    }


    /**
     * Sets the perm_exch_export value for this App_role_rec.
     * 
     * @param perm_exch_export
     */
    public void setPerm_exch_export(java.lang.String perm_exch_export) {
        this.perm_exch_export = perm_exch_export;
    }


    /**
     * Gets the perm_exch_proc value for this App_role_rec.
     * 
     * @return perm_exch_proc
     */
    public java.lang.String getPerm_exch_proc() {
        return perm_exch_proc;
    }


    /**
     * Sets the perm_exch_proc value for this App_role_rec.
     * 
     * @param perm_exch_proc
     */
    public void setPerm_exch_proc(java.lang.String perm_exch_proc) {
        this.perm_exch_proc = perm_exch_proc;
    }


    /**
     * Gets the perm_exch_steps value for this App_role_rec.
     * 
     * @return perm_exch_steps
     */
    public java.lang.String getPerm_exch_steps() {
        return perm_exch_steps;
    }


    /**
     * Sets the perm_exch_steps value for this App_role_rec.
     * 
     * @param perm_exch_steps
     */
    public void setPerm_exch_steps(java.lang.String perm_exch_steps) {
        this.perm_exch_steps = perm_exch_steps;
    }


    /**
     * Gets the perm_exch_files value for this App_role_rec.
     * 
     * @return perm_exch_files
     */
    public java.lang.String getPerm_exch_files() {
        return perm_exch_files;
    }


    /**
     * Sets the perm_exch_files value for this App_role_rec.
     * 
     * @param perm_exch_files
     */
    public void setPerm_exch_files(java.lang.String perm_exch_files) {
        this.perm_exch_files = perm_exch_files;
    }


    /**
     * Gets the perm_exch_err_stat value for this App_role_rec.
     * 
     * @return perm_exch_err_stat
     */
    public java.lang.String getPerm_exch_err_stat() {
        return perm_exch_err_stat;
    }


    /**
     * Sets the perm_exch_err_stat value for this App_role_rec.
     * 
     * @param perm_exch_err_stat
     */
    public void setPerm_exch_err_stat(java.lang.String perm_exch_err_stat) {
        this.perm_exch_err_stat = perm_exch_err_stat;
    }


    /**
     * Gets the perm_exch_err_det value for this App_role_rec.
     * 
     * @return perm_exch_err_det
     */
    public java.lang.String getPerm_exch_err_det() {
        return perm_exch_err_det;
    }


    /**
     * Sets the perm_exch_err_det value for this App_role_rec.
     * 
     * @param perm_exch_err_det
     */
    public void setPerm_exch_err_det(java.lang.String perm_exch_err_det) {
        this.perm_exch_err_det = perm_exch_err_det;
    }


    /**
     * Gets the perm_exch_import_stat value for this App_role_rec.
     * 
     * @return perm_exch_import_stat
     */
    public java.lang.String getPerm_exch_import_stat() {
        return perm_exch_import_stat;
    }


    /**
     * Sets the perm_exch_import_stat value for this App_role_rec.
     * 
     * @param perm_exch_import_stat
     */
    public void setPerm_exch_import_stat(java.lang.String perm_exch_import_stat) {
        this.perm_exch_import_stat = perm_exch_import_stat;
    }


    /**
     * Gets the perm_exch_feed_cat value for this App_role_rec.
     * 
     * @return perm_exch_feed_cat
     */
    public java.lang.String getPerm_exch_feed_cat() {
        return perm_exch_feed_cat;
    }


    /**
     * Sets the perm_exch_feed_cat value for this App_role_rec.
     * 
     * @param perm_exch_feed_cat
     */
    public void setPerm_exch_feed_cat(java.lang.String perm_exch_feed_cat) {
        this.perm_exch_feed_cat = perm_exch_feed_cat;
    }


    /**
     * Gets the perm_exch_feed_stat value for this App_role_rec.
     * 
     * @return perm_exch_feed_stat
     */
    public java.lang.String getPerm_exch_feed_stat() {
        return perm_exch_feed_stat;
    }


    /**
     * Sets the perm_exch_feed_stat value for this App_role_rec.
     * 
     * @param perm_exch_feed_stat
     */
    public void setPerm_exch_feed_stat(java.lang.String perm_exch_feed_stat) {
        this.perm_exch_feed_stat = perm_exch_feed_stat;
    }


    /**
     * Gets the perm_admin value for this App_role_rec.
     * 
     * @return perm_admin
     */
    public java.lang.String getPerm_admin() {
        return perm_admin;
    }


    /**
     * Sets the perm_admin value for this App_role_rec.
     * 
     * @param perm_admin
     */
    public void setPerm_admin(java.lang.String perm_admin) {
        this.perm_admin = perm_admin;
    }


    /**
     * Gets the perm_md_glob_lang value for this App_role_rec.
     * 
     * @return perm_md_glob_lang
     */
    public java.lang.String getPerm_md_glob_lang() {
        return perm_md_glob_lang;
    }


    /**
     * Sets the perm_md_glob_lang value for this App_role_rec.
     * 
     * @param perm_md_glob_lang
     */
    public void setPerm_md_glob_lang(java.lang.String perm_md_glob_lang) {
        this.perm_md_glob_lang = perm_md_glob_lang;
    }


    /**
     * Gets the perm_md_glob_reg value for this App_role_rec.
     * 
     * @return perm_md_glob_reg
     */
    public java.lang.String getPerm_md_glob_reg() {
        return perm_md_glob_reg;
    }


    /**
     * Sets the perm_md_glob_reg value for this App_role_rec.
     * 
     * @param perm_md_glob_reg
     */
    public void setPerm_md_glob_reg(java.lang.String perm_md_glob_reg) {
        this.perm_md_glob_reg = perm_md_glob_reg;
    }


    /**
     * Gets the perm_md_glob_count value for this App_role_rec.
     * 
     * @return perm_md_glob_count
     */
    public java.lang.String getPerm_md_glob_count() {
        return perm_md_glob_count;
    }


    /**
     * Sets the perm_md_glob_count value for this App_role_rec.
     * 
     * @param perm_md_glob_count
     */
    public void setPerm_md_glob_count(java.lang.String perm_md_glob_count) {
        this.perm_md_glob_count = perm_md_glob_count;
    }


    /**
     * Gets the perm_md_glob_curr value for this App_role_rec.
     * 
     * @return perm_md_glob_curr
     */
    public java.lang.String getPerm_md_glob_curr() {
        return perm_md_glob_curr;
    }


    /**
     * Sets the perm_md_glob_curr value for this App_role_rec.
     * 
     * @param perm_md_glob_curr
     */
    public void setPerm_md_glob_curr(java.lang.String perm_md_glob_curr) {
        this.perm_md_glob_curr = perm_md_glob_curr;
    }


    /**
     * Gets the perm_md_glob_ex value for this App_role_rec.
     * 
     * @return perm_md_glob_ex
     */
    public java.lang.String getPerm_md_glob_ex() {
        return perm_md_glob_ex;
    }


    /**
     * Sets the perm_md_glob_ex value for this App_role_rec.
     * 
     * @param perm_md_glob_ex
     */
    public void setPerm_md_glob_ex(java.lang.String perm_md_glob_ex) {
        this.perm_md_glob_ex = perm_md_glob_ex;
    }


    /**
     * Gets the perm_md_sys_act_reas value for this App_role_rec.
     * 
     * @return perm_md_sys_act_reas
     */
    public java.lang.String getPerm_md_sys_act_reas() {
        return perm_md_sys_act_reas;
    }


    /**
     * Sets the perm_md_sys_act_reas value for this App_role_rec.
     * 
     * @param perm_md_sys_act_reas
     */
    public void setPerm_md_sys_act_reas(java.lang.String perm_md_sys_act_reas) {
        this.perm_md_sys_act_reas = perm_md_sys_act_reas;
    }


    /**
     * Gets the perm_md_sys_perimeters value for this App_role_rec.
     * 
     * @return perm_md_sys_perimeters
     */
    public java.lang.String getPerm_md_sys_perimeters() {
        return perm_md_sys_perimeters;
    }


    /**
     * Sets the perm_md_sys_perimeters value for this App_role_rec.
     * 
     * @param perm_md_sys_perimeters
     */
    public void setPerm_md_sys_perimeters(java.lang.String perm_md_sys_perimeters) {
        this.perm_md_sys_perimeters = perm_md_sys_perimeters;
    }


    /**
     * Gets the perm_md_sys_ds value for this App_role_rec.
     * 
     * @return perm_md_sys_ds
     */
    public java.lang.String getPerm_md_sys_ds() {
        return perm_md_sys_ds;
    }


    /**
     * Sets the perm_md_sys_ds value for this App_role_rec.
     * 
     * @param perm_md_sys_ds
     */
    public void setPerm_md_sys_ds(java.lang.String perm_md_sys_ds) {
        this.perm_md_sys_ds = perm_md_sys_ds;
    }


    /**
     * Gets the perm_mm value for this App_role_rec.
     * 
     * @return perm_mm
     */
    public java.lang.String getPerm_mm() {
        return perm_mm;
    }


    /**
     * Sets the perm_mm value for this App_role_rec.
     * 
     * @param perm_mm
     */
    public void setPerm_mm(java.lang.String perm_mm) {
        this.perm_mm = perm_mm;
    }


    /**
     * Gets the perm_report value for this App_role_rec.
     * 
     * @return perm_report
     */
    public java.lang.String getPerm_report() {
        return perm_report;
    }


    /**
     * Sets the perm_report value for this App_role_rec.
     * 
     * @param perm_report
     */
    public void setPerm_report(java.lang.String perm_report) {
        this.perm_report = perm_report;
    }


    /**
     * Gets the perm_fm_cpp value for this App_role_rec.
     * 
     * @return perm_fm_cpp
     */
    public java.lang.String getPerm_fm_cpp() {
        return perm_fm_cpp;
    }


    /**
     * Sets the perm_fm_cpp value for this App_role_rec.
     * 
     * @param perm_fm_cpp
     */
    public void setPerm_fm_cpp(java.lang.String perm_fm_cpp) {
        this.perm_fm_cpp = perm_fm_cpp;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof App_role_rec)) return false;
        App_role_rec other = (App_role_rec) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            this.app_role_id == other.getApp_role_id() &&
            ((this.import_id==null && other.getImport_id()==null) || 
             (this.import_id!=null &&
              this.import_id.equals(other.getImport_id()))) &&
            this.data_source_id == other.getData_source_id() &&
            ((this.name==null && other.getName()==null) || 
             (this.name!=null &&
              this.name.equals(other.getName()))) &&
            ((this.remarks==null && other.getRemarks()==null) || 
             (this.remarks!=null &&
              this.remarks.equals(other.getRemarks()))) &&
            ((this.perm_icm_compliance==null && other.getPerm_icm_compliance()==null) || 
             (this.perm_icm_compliance!=null &&
              this.perm_icm_compliance.equals(other.getPerm_icm_compliance()))) &&
            ((this.perm_st==null && other.getPerm_st()==null) || 
             (this.perm_st!=null &&
              this.perm_st.equals(other.getPerm_st()))) &&
            ((this.perm_lic_cert==null && other.getPerm_lic_cert()==null) || 
             (this.perm_lic_cert!=null &&
              this.perm_lic_cert.equals(other.getPerm_lic_cert()))) &&
            ((this.perm_import==null && other.getPerm_import()==null) || 
             (this.perm_import!=null &&
              this.perm_import.equals(other.getPerm_import()))) &&
            ((this.perm_lic_upd_base==null && other.getPerm_lic_upd_base()==null) || 
             (this.perm_lic_upd_base!=null &&
              this.perm_lic_upd_base.equals(other.getPerm_lic_upd_base()))) &&
            ((this.perm_lic_move==null && other.getPerm_lic_move()==null) || 
             (this.perm_lic_move!=null &&
              this.perm_lic_move.equals(other.getPerm_lic_move()))) &&
            ((this.perm_lic_transfer==null && other.getPerm_lic_transfer()==null) || 
             (this.perm_lic_transfer!=null &&
              this.perm_lic_transfer.equals(other.getPerm_lic_transfer()))) &&
            ((this.perm_md_sys_lic_stat==null && other.getPerm_md_sys_lic_stat()==null) || 
             (this.perm_md_sys_lic_stat!=null &&
              this.perm_md_sys_lic_stat.equals(other.getPerm_md_sys_lic_stat()))) &&
            ((this.perm_md_sys_lic_cl_stat==null && other.getPerm_md_sys_lic_cl_stat()==null) || 
             (this.perm_md_sys_lic_cl_stat!=null &&
              this.perm_md_sys_lic_cl_stat.equals(other.getPerm_md_sys_lic_cl_stat()))) &&
            ((this.perm_icm_usage==null && other.getPerm_icm_usage()==null) || 
             (this.perm_icm_usage!=null &&
              this.perm_icm_usage.equals(other.getPerm_icm_usage()))) &&
            ((this.perm_icm_me_hints==null && other.getPerm_icm_me_hints()==null) || 
             (this.perm_icm_me_hints!=null &&
              this.perm_icm_me_hints.equals(other.getPerm_icm_me_hints()))) &&
            ((this.perm_icm_raw==null && other.getPerm_icm_raw()==null) || 
             (this.perm_icm_raw!=null &&
              this.perm_icm_raw.equals(other.getPerm_icm_raw()))) &&
            ((this.perm_md_sys_inv_stat==null && other.getPerm_md_sys_inv_stat()==null) || 
             (this.perm_md_sys_inv_stat!=null &&
              this.perm_md_sys_inv_stat.equals(other.getPerm_md_sys_inv_stat()))) &&
            ((this.perm_cmm_cont==null && other.getPerm_cmm_cont()==null) || 
             (this.perm_cmm_cont!=null &&
              this.perm_cmm_cont.equals(other.getPerm_cmm_cont()))) &&
            ((this.perm_cmm_enrol==null && other.getPerm_cmm_enrol()==null) || 
             (this.perm_cmm_enrol!=null &&
              this.perm_cmm_enrol.equals(other.getPerm_cmm_enrol()))) &&
            ((this.perm_cmm_points==null && other.getPerm_cmm_points()==null) || 
             (this.perm_cmm_points!=null &&
              this.perm_cmm_points.equals(other.getPerm_cmm_points()))) &&
            ((this.perm_cmm_expend==null && other.getPerm_cmm_expend()==null) || 
             (this.perm_cmm_expend!=null &&
              this.perm_cmm_expend.equals(other.getPerm_cmm_expend()))) &&
            ((this.perm_md_cmm_class==null && other.getPerm_md_cmm_class()==null) || 
             (this.perm_md_cmm_class!=null &&
              this.perm_md_cmm_class.equals(other.getPerm_md_cmm_class()))) &&
            ((this.perm_md_cmm_rel_typ==null && other.getPerm_md_cmm_rel_typ()==null) || 
             (this.perm_md_cmm_rel_typ!=null &&
              this.perm_md_cmm_rel_typ.equals(other.getPerm_md_cmm_rel_typ()))) &&
            ((this.perm_md_cmm_trans==null && other.getPerm_md_cmm_trans()==null) || 
             (this.perm_md_cmm_trans!=null &&
              this.perm_md_cmm_trans.equals(other.getPerm_md_cmm_trans()))) &&
            ((this.perm_md_cmm_pay_terms==null && other.getPerm_md_cmm_pay_terms()==null) || 
             (this.perm_md_cmm_pay_terms!=null &&
              this.perm_md_cmm_pay_terms.equals(other.getPerm_md_cmm_pay_terms()))) &&
            ((this.perm_md_cmm_typ==null && other.getPerm_md_cmm_typ()==null) || 
             (this.perm_md_cmm_typ!=null &&
              this.perm_md_cmm_typ.equals(other.getPerm_md_cmm_typ()))) &&
            ((this.perm_md_cmm_status==null && other.getPerm_md_cmm_status()==null) || 
             (this.perm_md_cmm_status!=null &&
              this.perm_md_cmm_status.equals(other.getPerm_md_cmm_status()))) &&
            ((this.perm_md_cmm_exp_typ==null && other.getPerm_md_cmm_exp_typ()==null) || 
             (this.perm_md_cmm_exp_typ!=null &&
              this.perm_md_cmm_exp_typ.equals(other.getPerm_md_cmm_exp_typ()))) &&
            ((this.perm_fc==null && other.getPerm_fc()==null) || 
             (this.perm_fc!=null &&
              this.perm_fc.equals(other.getPerm_fc()))) &&
            ((this.perm_osm_demand_opt==null && other.getPerm_osm_demand_opt()==null) || 
             (this.perm_osm_demand_opt!=null &&
              this.perm_osm_demand_opt.equals(other.getPerm_osm_demand_opt()))) &&
            ((this.perm_osm_cost_sav==null && other.getPerm_osm_cost_sav()==null) || 
             (this.perm_osm_cost_sav!=null &&
              this.perm_osm_cost_sav.equals(other.getPerm_osm_cost_sav()))) &&
            ((this.perm_fm==null && other.getPerm_fm()==null) || 
             (this.perm_fm!=null &&
              this.perm_fm.equals(other.getPerm_fm()))) &&
            ((this.perm_fm_charging==null && other.getPerm_fm_charging()==null) || 
             (this.perm_fm_charging!=null &&
              this.perm_fm_charging.equals(other.getPerm_fm_charging()))) &&
            ((this.perm_adm==null && other.getPerm_adm()==null) || 
             (this.perm_adm!=null &&
              this.perm_adm.equals(other.getPerm_adm()))) &&
            ((this.perm_md_pr_man==null && other.getPerm_md_pr_man()==null) || 
             (this.perm_md_pr_man!=null &&
              this.perm_md_pr_man.equals(other.getPerm_md_pr_man()))) &&
            ((this.perm_md_pr_prod_fam==null && other.getPerm_md_pr_prod_fam()==null) || 
             (this.perm_md_pr_prod_fam!=null &&
              this.perm_md_pr_prod_fam.equals(other.getPerm_md_pr_prod_fam()))) &&
            ((this.perm_md_pr_prod==null && other.getPerm_md_pr_prod()==null) || 
             (this.perm_md_pr_prod!=null &&
              this.perm_md_pr_prod.equals(other.getPerm_md_pr_prod()))) &&
            ((this.perm_md_pr_pur==null && other.getPerm_md_pr_pur()==null) || 
             (this.perm_md_pr_pur!=null &&
              this.perm_md_pr_pur.equals(other.getPerm_md_pr_pur()))) &&
            ((this.perm_md_pr_art==null && other.getPerm_md_pr_art()==null) || 
             (this.perm_md_pr_art!=null &&
              this.perm_md_pr_art.equals(other.getPerm_md_pr_art()))) &&
            ((this.perm_md_pr_dg_path==null && other.getPerm_md_pr_dg_path()==null) || 
             (this.perm_md_pr_dg_path!=null &&
              this.perm_md_pr_dg_path.equals(other.getPerm_md_pr_dg_path()))) &&
            ((this.perm_md_pr_product_path==null && other.getPerm_md_pr_product_path()==null) || 
             (this.perm_md_pr_product_path!=null &&
              this.perm_md_pr_product_path.equals(other.getPerm_md_pr_product_path()))) &&
            ((this.perm_md_pr_prod_dep==null && other.getPerm_md_pr_prod_dep()==null) || 
             (this.perm_md_pr_prod_dep!=null &&
              this.perm_md_pr_prod_dep.equals(other.getPerm_md_pr_prod_dep()))) &&
            ((this.perm_md_pr_man_syn==null && other.getPerm_md_pr_man_syn()==null) || 
             (this.perm_md_pr_man_syn!=null &&
              this.perm_md_pr_man_syn.equals(other.getPerm_md_pr_man_syn()))) &&
            ((this.perm_md_org_cont==null && other.getPerm_md_org_cont()==null) || 
             (this.perm_md_org_cont!=null &&
              this.perm_md_org_cont.equals(other.getPerm_md_org_cont()))) &&
            ((this.perm_md_pr_inv_syn==null && other.getPerm_md_pr_inv_syn()==null) || 
             (this.perm_md_pr_inv_syn!=null &&
              this.perm_md_pr_inv_syn.equals(other.getPerm_md_pr_inv_syn()))) &&
            ((this.perm_md_pr_sw_class==null && other.getPerm_md_pr_sw_class()==null) || 
             (this.perm_md_pr_sw_class!=null &&
              this.perm_md_pr_sw_class.equals(other.getPerm_md_pr_sw_class()))) &&
            ((this.perm_md_org_sup==null && other.getPerm_md_org_sup()==null) || 
             (this.perm_md_org_sup!=null &&
              this.perm_md_org_sup.equals(other.getPerm_md_org_sup()))) &&
            ((this.perm_md_pr_supp_art==null && other.getPerm_md_pr_supp_art()==null) || 
             (this.perm_md_pr_supp_art!=null &&
              this.perm_md_pr_supp_art.equals(other.getPerm_md_pr_supp_art()))) &&
            ((this.perm_md_pr_lic_metr==null && other.getPerm_md_pr_lic_metr()==null) || 
             (this.perm_md_pr_lic_metr!=null &&
              this.perm_md_pr_lic_metr.equals(other.getPerm_md_pr_lic_metr()))) &&
            ((this.perm_md_pr_lic_types==null && other.getPerm_md_pr_lic_types()==null) || 
             (this.perm_md_pr_lic_types!=null &&
              this.perm_md_pr_lic_types.equals(other.getPerm_md_pr_lic_types()))) &&
            ((this.perm_md_pr_point_cat==null && other.getPerm_md_pr_point_cat()==null) || 
             (this.perm_md_pr_point_cat!=null &&
              this.perm_md_pr_point_cat.equals(other.getPerm_md_pr_point_cat()))) &&
            ((this.perm_md_pr_tiers==null && other.getPerm_md_pr_tiers()==null) || 
             (this.perm_md_pr_tiers!=null &&
              this.perm_md_pr_tiers.equals(other.getPerm_md_pr_tiers()))) &&
            ((this.perm_md_pr_status==null && other.getPerm_md_pr_status()==null) || 
             (this.perm_md_pr_status!=null &&
              this.perm_md_pr_status.equals(other.getPerm_md_pr_status()))) &&
            ((this.perm_md_sys_sig_stat==null && other.getPerm_md_sys_sig_stat()==null) || 
             (this.perm_md_sys_sig_stat!=null &&
              this.perm_md_sys_sig_stat.equals(other.getPerm_md_sys_sig_stat()))) &&
            ((this.perm_md_org_co==null && other.getPerm_md_org_co()==null) || 
             (this.perm_md_org_co!=null &&
              this.perm_md_org_co.equals(other.getPerm_md_org_co()))) &&
            ((this.perm_md_org_bu==null && other.getPerm_md_org_bu()==null) || 
             (this.perm_md_org_bu!=null &&
              this.perm_md_org_bu.equals(other.getPerm_md_org_bu()))) &&
            ((this.perm_md_org_cc==null && other.getPerm_md_org_cc()==null) || 
             (this.perm_md_org_cc!=null &&
              this.perm_md_org_cc.equals(other.getPerm_md_org_cc()))) &&
            ((this.perm_md_org_loc==null && other.getPerm_md_org_loc()==null) || 
             (this.perm_md_org_loc!=null &&
              this.perm_md_org_loc.equals(other.getPerm_md_org_loc()))) &&
            ((this.perm_md_org_proj==null && other.getPerm_md_org_proj()==null) || 
             (this.perm_md_org_proj!=null &&
              this.perm_md_org_proj.equals(other.getPerm_md_org_proj()))) &&
            ((this.perm_md_org_rep==null && other.getPerm_md_org_rep()==null) || 
             (this.perm_md_org_rep!=null &&
              this.perm_md_org_rep.equals(other.getPerm_md_org_rep()))) &&
            ((this.perm_md_dev_dev==null && other.getPerm_md_dev_dev()==null) || 
             (this.perm_md_dev_dev!=null &&
              this.perm_md_dev_dev.equals(other.getPerm_md_dev_dev()))) &&
            ((this.perm_md_dev_dev_rel==null && other.getPerm_md_dev_dev_rel()==null) || 
             (this.perm_md_dev_dev_rel!=null &&
              this.perm_md_dev_dev_rel.equals(other.getPerm_md_dev_dev_rel()))) &&
            ((this.perm_md_dev_dev_cap==null && other.getPerm_md_dev_dev_cap()==null) || 
             (this.perm_md_dev_dev_cap!=null &&
              this.perm_md_dev_dev_cap.equals(other.getPerm_md_dev_dev_cap()))) &&
            ((this.perm_md_user_users==null && other.getPerm_md_user_users()==null) || 
             (this.perm_md_user_users!=null &&
              this.perm_md_user_users.equals(other.getPerm_md_user_users()))) &&
            ((this.perm_md_user_acc==null && other.getPerm_md_user_acc()==null) || 
             (this.perm_md_user_acc!=null &&
              this.perm_md_user_acc.equals(other.getPerm_md_user_acc()))) &&
            ((this.perm_md_user_perms==null && other.getPerm_md_user_perms()==null) || 
             (this.perm_md_user_perms!=null &&
              this.perm_md_user_perms.equals(other.getPerm_md_user_perms()))) &&
            ((this.perm_md_dev_dev_rel_typ==null && other.getPerm_md_dev_dev_rel_typ()==null) || 
             (this.perm_md_dev_dev_rel_typ!=null &&
              this.perm_md_dev_dev_rel_typ.equals(other.getPerm_md_dev_dev_rel_typ()))) &&
            ((this.perm_md_dev_dev_typ==null && other.getPerm_md_dev_dev_typ()==null) || 
             (this.perm_md_dev_dev_typ!=null &&
              this.perm_md_dev_dev_typ.equals(other.getPerm_md_dev_dev_typ()))) &&
            ((this.perm_md_dev_dev_stat==null && other.getPerm_md_dev_dev_stat()==null) || 
             (this.perm_md_dev_dev_stat!=null &&
              this.perm_md_dev_dev_stat.equals(other.getPerm_md_dev_dev_stat()))) &&
            ((this.perm_md_dev_cpu_typ==null && other.getPerm_md_dev_cpu_typ()==null) || 
             (this.perm_md_dev_cpu_typ!=null &&
              this.perm_md_dev_cpu_typ.equals(other.getPerm_md_dev_cpu_typ()))) &&
            ((this.perm_exch_import==null && other.getPerm_exch_import()==null) || 
             (this.perm_exch_import!=null &&
              this.perm_exch_import.equals(other.getPerm_exch_import()))) &&
            ((this.perm_exch_exch_dir==null && other.getPerm_exch_exch_dir()==null) || 
             (this.perm_exch_exch_dir!=null &&
              this.perm_exch_exch_dir.equals(other.getPerm_exch_exch_dir()))) &&
            ((this.perm_exch_feeds==null && other.getPerm_exch_feeds()==null) || 
             (this.perm_exch_feeds!=null &&
              this.perm_exch_feeds.equals(other.getPerm_exch_feeds()))) &&
            ((this.perm_exch_export==null && other.getPerm_exch_export()==null) || 
             (this.perm_exch_export!=null &&
              this.perm_exch_export.equals(other.getPerm_exch_export()))) &&
            ((this.perm_exch_proc==null && other.getPerm_exch_proc()==null) || 
             (this.perm_exch_proc!=null &&
              this.perm_exch_proc.equals(other.getPerm_exch_proc()))) &&
            ((this.perm_exch_steps==null && other.getPerm_exch_steps()==null) || 
             (this.perm_exch_steps!=null &&
              this.perm_exch_steps.equals(other.getPerm_exch_steps()))) &&
            ((this.perm_exch_files==null && other.getPerm_exch_files()==null) || 
             (this.perm_exch_files!=null &&
              this.perm_exch_files.equals(other.getPerm_exch_files()))) &&
            ((this.perm_exch_err_stat==null && other.getPerm_exch_err_stat()==null) || 
             (this.perm_exch_err_stat!=null &&
              this.perm_exch_err_stat.equals(other.getPerm_exch_err_stat()))) &&
            ((this.perm_exch_err_det==null && other.getPerm_exch_err_det()==null) || 
             (this.perm_exch_err_det!=null &&
              this.perm_exch_err_det.equals(other.getPerm_exch_err_det()))) &&
            ((this.perm_exch_import_stat==null && other.getPerm_exch_import_stat()==null) || 
             (this.perm_exch_import_stat!=null &&
              this.perm_exch_import_stat.equals(other.getPerm_exch_import_stat()))) &&
            ((this.perm_exch_feed_cat==null && other.getPerm_exch_feed_cat()==null) || 
             (this.perm_exch_feed_cat!=null &&
              this.perm_exch_feed_cat.equals(other.getPerm_exch_feed_cat()))) &&
            ((this.perm_exch_feed_stat==null && other.getPerm_exch_feed_stat()==null) || 
             (this.perm_exch_feed_stat!=null &&
              this.perm_exch_feed_stat.equals(other.getPerm_exch_feed_stat()))) &&
            ((this.perm_admin==null && other.getPerm_admin()==null) || 
             (this.perm_admin!=null &&
              this.perm_admin.equals(other.getPerm_admin()))) &&
            ((this.perm_md_glob_lang==null && other.getPerm_md_glob_lang()==null) || 
             (this.perm_md_glob_lang!=null &&
              this.perm_md_glob_lang.equals(other.getPerm_md_glob_lang()))) &&
            ((this.perm_md_glob_reg==null && other.getPerm_md_glob_reg()==null) || 
             (this.perm_md_glob_reg!=null &&
              this.perm_md_glob_reg.equals(other.getPerm_md_glob_reg()))) &&
            ((this.perm_md_glob_count==null && other.getPerm_md_glob_count()==null) || 
             (this.perm_md_glob_count!=null &&
              this.perm_md_glob_count.equals(other.getPerm_md_glob_count()))) &&
            ((this.perm_md_glob_curr==null && other.getPerm_md_glob_curr()==null) || 
             (this.perm_md_glob_curr!=null &&
              this.perm_md_glob_curr.equals(other.getPerm_md_glob_curr()))) &&
            ((this.perm_md_glob_ex==null && other.getPerm_md_glob_ex()==null) || 
             (this.perm_md_glob_ex!=null &&
              this.perm_md_glob_ex.equals(other.getPerm_md_glob_ex()))) &&
            ((this.perm_md_sys_act_reas==null && other.getPerm_md_sys_act_reas()==null) || 
             (this.perm_md_sys_act_reas!=null &&
              this.perm_md_sys_act_reas.equals(other.getPerm_md_sys_act_reas()))) &&
            ((this.perm_md_sys_perimeters==null && other.getPerm_md_sys_perimeters()==null) || 
             (this.perm_md_sys_perimeters!=null &&
              this.perm_md_sys_perimeters.equals(other.getPerm_md_sys_perimeters()))) &&
            ((this.perm_md_sys_ds==null && other.getPerm_md_sys_ds()==null) || 
             (this.perm_md_sys_ds!=null &&
              this.perm_md_sys_ds.equals(other.getPerm_md_sys_ds()))) &&
            ((this.perm_mm==null && other.getPerm_mm()==null) || 
             (this.perm_mm!=null &&
              this.perm_mm.equals(other.getPerm_mm()))) &&
            ((this.perm_report==null && other.getPerm_report()==null) || 
             (this.perm_report!=null &&
              this.perm_report.equals(other.getPerm_report()))) &&
            ((this.perm_fm_cpp==null && other.getPerm_fm_cpp()==null) || 
             (this.perm_fm_cpp!=null &&
              this.perm_fm_cpp.equals(other.getPerm_fm_cpp())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        _hashCode += getApp_role_id();
        if (getImport_id() != null) {
            _hashCode += getImport_id().hashCode();
        }
        _hashCode += getData_source_id();
        if (getName() != null) {
            _hashCode += getName().hashCode();
        }
        if (getRemarks() != null) {
            _hashCode += getRemarks().hashCode();
        }
        if (getPerm_icm_compliance() != null) {
            _hashCode += getPerm_icm_compliance().hashCode();
        }
        if (getPerm_st() != null) {
            _hashCode += getPerm_st().hashCode();
        }
        if (getPerm_lic_cert() != null) {
            _hashCode += getPerm_lic_cert().hashCode();
        }
        if (getPerm_import() != null) {
            _hashCode += getPerm_import().hashCode();
        }
        if (getPerm_lic_upd_base() != null) {
            _hashCode += getPerm_lic_upd_base().hashCode();
        }
        if (getPerm_lic_move() != null) {
            _hashCode += getPerm_lic_move().hashCode();
        }
        if (getPerm_lic_transfer() != null) {
            _hashCode += getPerm_lic_transfer().hashCode();
        }
        if (getPerm_md_sys_lic_stat() != null) {
            _hashCode += getPerm_md_sys_lic_stat().hashCode();
        }
        if (getPerm_md_sys_lic_cl_stat() != null) {
            _hashCode += getPerm_md_sys_lic_cl_stat().hashCode();
        }
        if (getPerm_icm_usage() != null) {
            _hashCode += getPerm_icm_usage().hashCode();
        }
        if (getPerm_icm_me_hints() != null) {
            _hashCode += getPerm_icm_me_hints().hashCode();
        }
        if (getPerm_icm_raw() != null) {
            _hashCode += getPerm_icm_raw().hashCode();
        }
        if (getPerm_md_sys_inv_stat() != null) {
            _hashCode += getPerm_md_sys_inv_stat().hashCode();
        }
        if (getPerm_cmm_cont() != null) {
            _hashCode += getPerm_cmm_cont().hashCode();
        }
        if (getPerm_cmm_enrol() != null) {
            _hashCode += getPerm_cmm_enrol().hashCode();
        }
        if (getPerm_cmm_points() != null) {
            _hashCode += getPerm_cmm_points().hashCode();
        }
        if (getPerm_cmm_expend() != null) {
            _hashCode += getPerm_cmm_expend().hashCode();
        }
        if (getPerm_md_cmm_class() != null) {
            _hashCode += getPerm_md_cmm_class().hashCode();
        }
        if (getPerm_md_cmm_rel_typ() != null) {
            _hashCode += getPerm_md_cmm_rel_typ().hashCode();
        }
        if (getPerm_md_cmm_trans() != null) {
            _hashCode += getPerm_md_cmm_trans().hashCode();
        }
        if (getPerm_md_cmm_pay_terms() != null) {
            _hashCode += getPerm_md_cmm_pay_terms().hashCode();
        }
        if (getPerm_md_cmm_typ() != null) {
            _hashCode += getPerm_md_cmm_typ().hashCode();
        }
        if (getPerm_md_cmm_status() != null) {
            _hashCode += getPerm_md_cmm_status().hashCode();
        }
        if (getPerm_md_cmm_exp_typ() != null) {
            _hashCode += getPerm_md_cmm_exp_typ().hashCode();
        }
        if (getPerm_fc() != null) {
            _hashCode += getPerm_fc().hashCode();
        }
        if (getPerm_osm_demand_opt() != null) {
            _hashCode += getPerm_osm_demand_opt().hashCode();
        }
        if (getPerm_osm_cost_sav() != null) {
            _hashCode += getPerm_osm_cost_sav().hashCode();
        }
        if (getPerm_fm() != null) {
            _hashCode += getPerm_fm().hashCode();
        }
        if (getPerm_fm_charging() != null) {
            _hashCode += getPerm_fm_charging().hashCode();
        }
        if (getPerm_adm() != null) {
            _hashCode += getPerm_adm().hashCode();
        }
        if (getPerm_md_pr_man() != null) {
            _hashCode += getPerm_md_pr_man().hashCode();
        }
        if (getPerm_md_pr_prod_fam() != null) {
            _hashCode += getPerm_md_pr_prod_fam().hashCode();
        }
        if (getPerm_md_pr_prod() != null) {
            _hashCode += getPerm_md_pr_prod().hashCode();
        }
        if (getPerm_md_pr_pur() != null) {
            _hashCode += getPerm_md_pr_pur().hashCode();
        }
        if (getPerm_md_pr_art() != null) {
            _hashCode += getPerm_md_pr_art().hashCode();
        }
        if (getPerm_md_pr_dg_path() != null) {
            _hashCode += getPerm_md_pr_dg_path().hashCode();
        }
        if (getPerm_md_pr_product_path() != null) {
            _hashCode += getPerm_md_pr_product_path().hashCode();
        }
        if (getPerm_md_pr_prod_dep() != null) {
            _hashCode += getPerm_md_pr_prod_dep().hashCode();
        }
        if (getPerm_md_pr_man_syn() != null) {
            _hashCode += getPerm_md_pr_man_syn().hashCode();
        }
        if (getPerm_md_org_cont() != null) {
            _hashCode += getPerm_md_org_cont().hashCode();
        }
        if (getPerm_md_pr_inv_syn() != null) {
            _hashCode += getPerm_md_pr_inv_syn().hashCode();
        }
        if (getPerm_md_pr_sw_class() != null) {
            _hashCode += getPerm_md_pr_sw_class().hashCode();
        }
        if (getPerm_md_org_sup() != null) {
            _hashCode += getPerm_md_org_sup().hashCode();
        }
        if (getPerm_md_pr_supp_art() != null) {
            _hashCode += getPerm_md_pr_supp_art().hashCode();
        }
        if (getPerm_md_pr_lic_metr() != null) {
            _hashCode += getPerm_md_pr_lic_metr().hashCode();
        }
        if (getPerm_md_pr_lic_types() != null) {
            _hashCode += getPerm_md_pr_lic_types().hashCode();
        }
        if (getPerm_md_pr_point_cat() != null) {
            _hashCode += getPerm_md_pr_point_cat().hashCode();
        }
        if (getPerm_md_pr_tiers() != null) {
            _hashCode += getPerm_md_pr_tiers().hashCode();
        }
        if (getPerm_md_pr_status() != null) {
            _hashCode += getPerm_md_pr_status().hashCode();
        }
        if (getPerm_md_sys_sig_stat() != null) {
            _hashCode += getPerm_md_sys_sig_stat().hashCode();
        }
        if (getPerm_md_org_co() != null) {
            _hashCode += getPerm_md_org_co().hashCode();
        }
        if (getPerm_md_org_bu() != null) {
            _hashCode += getPerm_md_org_bu().hashCode();
        }
        if (getPerm_md_org_cc() != null) {
            _hashCode += getPerm_md_org_cc().hashCode();
        }
        if (getPerm_md_org_loc() != null) {
            _hashCode += getPerm_md_org_loc().hashCode();
        }
        if (getPerm_md_org_proj() != null) {
            _hashCode += getPerm_md_org_proj().hashCode();
        }
        if (getPerm_md_org_rep() != null) {
            _hashCode += getPerm_md_org_rep().hashCode();
        }
        if (getPerm_md_dev_dev() != null) {
            _hashCode += getPerm_md_dev_dev().hashCode();
        }
        if (getPerm_md_dev_dev_rel() != null) {
            _hashCode += getPerm_md_dev_dev_rel().hashCode();
        }
        if (getPerm_md_dev_dev_cap() != null) {
            _hashCode += getPerm_md_dev_dev_cap().hashCode();
        }
        if (getPerm_md_user_users() != null) {
            _hashCode += getPerm_md_user_users().hashCode();
        }
        if (getPerm_md_user_acc() != null) {
            _hashCode += getPerm_md_user_acc().hashCode();
        }
        if (getPerm_md_user_perms() != null) {
            _hashCode += getPerm_md_user_perms().hashCode();
        }
        if (getPerm_md_dev_dev_rel_typ() != null) {
            _hashCode += getPerm_md_dev_dev_rel_typ().hashCode();
        }
        if (getPerm_md_dev_dev_typ() != null) {
            _hashCode += getPerm_md_dev_dev_typ().hashCode();
        }
        if (getPerm_md_dev_dev_stat() != null) {
            _hashCode += getPerm_md_dev_dev_stat().hashCode();
        }
        if (getPerm_md_dev_cpu_typ() != null) {
            _hashCode += getPerm_md_dev_cpu_typ().hashCode();
        }
        if (getPerm_exch_import() != null) {
            _hashCode += getPerm_exch_import().hashCode();
        }
        if (getPerm_exch_exch_dir() != null) {
            _hashCode += getPerm_exch_exch_dir().hashCode();
        }
        if (getPerm_exch_feeds() != null) {
            _hashCode += getPerm_exch_feeds().hashCode();
        }
        if (getPerm_exch_export() != null) {
            _hashCode += getPerm_exch_export().hashCode();
        }
        if (getPerm_exch_proc() != null) {
            _hashCode += getPerm_exch_proc().hashCode();
        }
        if (getPerm_exch_steps() != null) {
            _hashCode += getPerm_exch_steps().hashCode();
        }
        if (getPerm_exch_files() != null) {
            _hashCode += getPerm_exch_files().hashCode();
        }
        if (getPerm_exch_err_stat() != null) {
            _hashCode += getPerm_exch_err_stat().hashCode();
        }
        if (getPerm_exch_err_det() != null) {
            _hashCode += getPerm_exch_err_det().hashCode();
        }
        if (getPerm_exch_import_stat() != null) {
            _hashCode += getPerm_exch_import_stat().hashCode();
        }
        if (getPerm_exch_feed_cat() != null) {
            _hashCode += getPerm_exch_feed_cat().hashCode();
        }
        if (getPerm_exch_feed_stat() != null) {
            _hashCode += getPerm_exch_feed_stat().hashCode();
        }
        if (getPerm_admin() != null) {
            _hashCode += getPerm_admin().hashCode();
        }
        if (getPerm_md_glob_lang() != null) {
            _hashCode += getPerm_md_glob_lang().hashCode();
        }
        if (getPerm_md_glob_reg() != null) {
            _hashCode += getPerm_md_glob_reg().hashCode();
        }
        if (getPerm_md_glob_count() != null) {
            _hashCode += getPerm_md_glob_count().hashCode();
        }
        if (getPerm_md_glob_curr() != null) {
            _hashCode += getPerm_md_glob_curr().hashCode();
        }
        if (getPerm_md_glob_ex() != null) {
            _hashCode += getPerm_md_glob_ex().hashCode();
        }
        if (getPerm_md_sys_act_reas() != null) {
            _hashCode += getPerm_md_sys_act_reas().hashCode();
        }
        if (getPerm_md_sys_perimeters() != null) {
            _hashCode += getPerm_md_sys_perimeters().hashCode();
        }
        if (getPerm_md_sys_ds() != null) {
            _hashCode += getPerm_md_sys_ds().hashCode();
        }
        if (getPerm_mm() != null) {
            _hashCode += getPerm_mm().hashCode();
        }
        if (getPerm_report() != null) {
            _hashCode += getPerm_report().hashCode();
        }
        if (getPerm_fm_cpp() != null) {
            _hashCode += getPerm_fm_cpp().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(App_role_rec.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://aspera.com/wsdl/", "app_role_rec"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("app_role_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "app_role_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("import_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "import_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("data_source_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "data_source_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("name");
        elemField.setXmlName(new javax.xml.namespace.QName("", "name"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("remarks");
        elemField.setXmlName(new javax.xml.namespace.QName("", "remarks"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("perm_icm_compliance");
        elemField.setXmlName(new javax.xml.namespace.QName("", "perm_icm_compliance"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("perm_st");
        elemField.setXmlName(new javax.xml.namespace.QName("", "perm_st"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("perm_lic_cert");
        elemField.setXmlName(new javax.xml.namespace.QName("", "perm_lic_cert"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("perm_import");
        elemField.setXmlName(new javax.xml.namespace.QName("", "perm_import"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("perm_lic_upd_base");
        elemField.setXmlName(new javax.xml.namespace.QName("", "perm_lic_upd_base"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("perm_lic_move");
        elemField.setXmlName(new javax.xml.namespace.QName("", "perm_lic_move"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("perm_lic_transfer");
        elemField.setXmlName(new javax.xml.namespace.QName("", "perm_lic_transfer"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("perm_md_sys_lic_stat");
        elemField.setXmlName(new javax.xml.namespace.QName("", "perm_md_sys_lic_stat"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("perm_md_sys_lic_cl_stat");
        elemField.setXmlName(new javax.xml.namespace.QName("", "perm_md_sys_lic_cl_stat"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("perm_icm_usage");
        elemField.setXmlName(new javax.xml.namespace.QName("", "perm_icm_usage"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("perm_icm_me_hints");
        elemField.setXmlName(new javax.xml.namespace.QName("", "perm_icm_me_hints"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("perm_icm_raw");
        elemField.setXmlName(new javax.xml.namespace.QName("", "perm_icm_raw"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("perm_md_sys_inv_stat");
        elemField.setXmlName(new javax.xml.namespace.QName("", "perm_md_sys_inv_stat"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("perm_cmm_cont");
        elemField.setXmlName(new javax.xml.namespace.QName("", "perm_cmm_cont"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("perm_cmm_enrol");
        elemField.setXmlName(new javax.xml.namespace.QName("", "perm_cmm_enrol"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("perm_cmm_points");
        elemField.setXmlName(new javax.xml.namespace.QName("", "perm_cmm_points"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("perm_cmm_expend");
        elemField.setXmlName(new javax.xml.namespace.QName("", "perm_cmm_expend"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("perm_md_cmm_class");
        elemField.setXmlName(new javax.xml.namespace.QName("", "perm_md_cmm_class"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("perm_md_cmm_rel_typ");
        elemField.setXmlName(new javax.xml.namespace.QName("", "perm_md_cmm_rel_typ"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("perm_md_cmm_trans");
        elemField.setXmlName(new javax.xml.namespace.QName("", "perm_md_cmm_trans"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("perm_md_cmm_pay_terms");
        elemField.setXmlName(new javax.xml.namespace.QName("", "perm_md_cmm_pay_terms"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("perm_md_cmm_typ");
        elemField.setXmlName(new javax.xml.namespace.QName("", "perm_md_cmm_typ"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("perm_md_cmm_status");
        elemField.setXmlName(new javax.xml.namespace.QName("", "perm_md_cmm_status"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("perm_md_cmm_exp_typ");
        elemField.setXmlName(new javax.xml.namespace.QName("", "perm_md_cmm_exp_typ"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("perm_fc");
        elemField.setXmlName(new javax.xml.namespace.QName("", "perm_fc"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("perm_osm_demand_opt");
        elemField.setXmlName(new javax.xml.namespace.QName("", "perm_osm_demand_opt"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("perm_osm_cost_sav");
        elemField.setXmlName(new javax.xml.namespace.QName("", "perm_osm_cost_sav"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("perm_fm");
        elemField.setXmlName(new javax.xml.namespace.QName("", "perm_fm"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("perm_fm_charging");
        elemField.setXmlName(new javax.xml.namespace.QName("", "perm_fm_charging"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("perm_adm");
        elemField.setXmlName(new javax.xml.namespace.QName("", "perm_adm"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("perm_md_pr_man");
        elemField.setXmlName(new javax.xml.namespace.QName("", "perm_md_pr_man"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("perm_md_pr_prod_fam");
        elemField.setXmlName(new javax.xml.namespace.QName("", "perm_md_pr_prod_fam"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("perm_md_pr_prod");
        elemField.setXmlName(new javax.xml.namespace.QName("", "perm_md_pr_prod"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("perm_md_pr_pur");
        elemField.setXmlName(new javax.xml.namespace.QName("", "perm_md_pr_pur"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("perm_md_pr_art");
        elemField.setXmlName(new javax.xml.namespace.QName("", "perm_md_pr_art"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("perm_md_pr_dg_path");
        elemField.setXmlName(new javax.xml.namespace.QName("", "perm_md_pr_dg_path"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("perm_md_pr_product_path");
        elemField.setXmlName(new javax.xml.namespace.QName("", "perm_md_pr_product_path"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("perm_md_pr_prod_dep");
        elemField.setXmlName(new javax.xml.namespace.QName("", "perm_md_pr_prod_dep"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("perm_md_pr_man_syn");
        elemField.setXmlName(new javax.xml.namespace.QName("", "perm_md_pr_man_syn"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("perm_md_org_cont");
        elemField.setXmlName(new javax.xml.namespace.QName("", "perm_md_org_cont"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("perm_md_pr_inv_syn");
        elemField.setXmlName(new javax.xml.namespace.QName("", "perm_md_pr_inv_syn"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("perm_md_pr_sw_class");
        elemField.setXmlName(new javax.xml.namespace.QName("", "perm_md_pr_sw_class"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("perm_md_org_sup");
        elemField.setXmlName(new javax.xml.namespace.QName("", "perm_md_org_sup"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("perm_md_pr_supp_art");
        elemField.setXmlName(new javax.xml.namespace.QName("", "perm_md_pr_supp_art"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("perm_md_pr_lic_metr");
        elemField.setXmlName(new javax.xml.namespace.QName("", "perm_md_pr_lic_metr"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("perm_md_pr_lic_types");
        elemField.setXmlName(new javax.xml.namespace.QName("", "perm_md_pr_lic_types"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("perm_md_pr_point_cat");
        elemField.setXmlName(new javax.xml.namespace.QName("", "perm_md_pr_point_cat"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("perm_md_pr_tiers");
        elemField.setXmlName(new javax.xml.namespace.QName("", "perm_md_pr_tiers"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("perm_md_pr_status");
        elemField.setXmlName(new javax.xml.namespace.QName("", "perm_md_pr_status"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("perm_md_sys_sig_stat");
        elemField.setXmlName(new javax.xml.namespace.QName("", "perm_md_sys_sig_stat"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("perm_md_org_co");
        elemField.setXmlName(new javax.xml.namespace.QName("", "perm_md_org_co"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("perm_md_org_bu");
        elemField.setXmlName(new javax.xml.namespace.QName("", "perm_md_org_bu"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("perm_md_org_cc");
        elemField.setXmlName(new javax.xml.namespace.QName("", "perm_md_org_cc"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("perm_md_org_loc");
        elemField.setXmlName(new javax.xml.namespace.QName("", "perm_md_org_loc"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("perm_md_org_proj");
        elemField.setXmlName(new javax.xml.namespace.QName("", "perm_md_org_proj"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("perm_md_org_rep");
        elemField.setXmlName(new javax.xml.namespace.QName("", "perm_md_org_rep"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("perm_md_dev_dev");
        elemField.setXmlName(new javax.xml.namespace.QName("", "perm_md_dev_dev"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("perm_md_dev_dev_rel");
        elemField.setXmlName(new javax.xml.namespace.QName("", "perm_md_dev_dev_rel"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("perm_md_dev_dev_cap");
        elemField.setXmlName(new javax.xml.namespace.QName("", "perm_md_dev_dev_cap"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("perm_md_user_users");
        elemField.setXmlName(new javax.xml.namespace.QName("", "perm_md_user_users"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("perm_md_user_acc");
        elemField.setXmlName(new javax.xml.namespace.QName("", "perm_md_user_acc"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("perm_md_user_perms");
        elemField.setXmlName(new javax.xml.namespace.QName("", "perm_md_user_perms"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("perm_md_dev_dev_rel_typ");
        elemField.setXmlName(new javax.xml.namespace.QName("", "perm_md_dev_dev_rel_typ"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("perm_md_dev_dev_typ");
        elemField.setXmlName(new javax.xml.namespace.QName("", "perm_md_dev_dev_typ"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("perm_md_dev_dev_stat");
        elemField.setXmlName(new javax.xml.namespace.QName("", "perm_md_dev_dev_stat"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("perm_md_dev_cpu_typ");
        elemField.setXmlName(new javax.xml.namespace.QName("", "perm_md_dev_cpu_typ"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("perm_exch_import");
        elemField.setXmlName(new javax.xml.namespace.QName("", "perm_exch_import"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("perm_exch_exch_dir");
        elemField.setXmlName(new javax.xml.namespace.QName("", "perm_exch_exch_dir"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("perm_exch_feeds");
        elemField.setXmlName(new javax.xml.namespace.QName("", "perm_exch_feeds"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("perm_exch_export");
        elemField.setXmlName(new javax.xml.namespace.QName("", "perm_exch_export"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("perm_exch_proc");
        elemField.setXmlName(new javax.xml.namespace.QName("", "perm_exch_proc"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("perm_exch_steps");
        elemField.setXmlName(new javax.xml.namespace.QName("", "perm_exch_steps"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("perm_exch_files");
        elemField.setXmlName(new javax.xml.namespace.QName("", "perm_exch_files"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("perm_exch_err_stat");
        elemField.setXmlName(new javax.xml.namespace.QName("", "perm_exch_err_stat"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("perm_exch_err_det");
        elemField.setXmlName(new javax.xml.namespace.QName("", "perm_exch_err_det"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("perm_exch_import_stat");
        elemField.setXmlName(new javax.xml.namespace.QName("", "perm_exch_import_stat"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("perm_exch_feed_cat");
        elemField.setXmlName(new javax.xml.namespace.QName("", "perm_exch_feed_cat"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("perm_exch_feed_stat");
        elemField.setXmlName(new javax.xml.namespace.QName("", "perm_exch_feed_stat"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("perm_admin");
        elemField.setXmlName(new javax.xml.namespace.QName("", "perm_admin"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("perm_md_glob_lang");
        elemField.setXmlName(new javax.xml.namespace.QName("", "perm_md_glob_lang"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("perm_md_glob_reg");
        elemField.setXmlName(new javax.xml.namespace.QName("", "perm_md_glob_reg"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("perm_md_glob_count");
        elemField.setXmlName(new javax.xml.namespace.QName("", "perm_md_glob_count"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("perm_md_glob_curr");
        elemField.setXmlName(new javax.xml.namespace.QName("", "perm_md_glob_curr"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("perm_md_glob_ex");
        elemField.setXmlName(new javax.xml.namespace.QName("", "perm_md_glob_ex"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("perm_md_sys_act_reas");
        elemField.setXmlName(new javax.xml.namespace.QName("", "perm_md_sys_act_reas"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("perm_md_sys_perimeters");
        elemField.setXmlName(new javax.xml.namespace.QName("", "perm_md_sys_perimeters"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("perm_md_sys_ds");
        elemField.setXmlName(new javax.xml.namespace.QName("", "perm_md_sys_ds"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("perm_mm");
        elemField.setXmlName(new javax.xml.namespace.QName("", "perm_mm"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("perm_report");
        elemField.setXmlName(new javax.xml.namespace.QName("", "perm_report"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("perm_fm_cpp");
        elemField.setXmlName(new javax.xml.namespace.QName("", "perm_fm_cpp"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}

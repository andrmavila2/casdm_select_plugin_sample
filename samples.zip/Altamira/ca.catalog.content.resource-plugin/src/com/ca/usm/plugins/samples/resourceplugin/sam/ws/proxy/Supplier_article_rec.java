/**
 * Supplier_article_rec.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ca.usm.plugins.samples.resourceplugin.sam.ws.proxy;

public class Supplier_article_rec  implements java.io.Serializable {
    private int supplier_article_id;

    private java.lang.String import_id;

    private int data_source_id;

    private int article_id;

    private int supplier_id;

    private java.lang.String supp_article_number;

    private java.lang.String description;

    private java.lang.String price;

    private int currency_id;

    private java.math.BigInteger delivery_days;

    private java.lang.String tax_description;

    private boolean is_enabled;

    public Supplier_article_rec() {
    }

    public Supplier_article_rec(
           int supplier_article_id,
           java.lang.String import_id,
           int data_source_id,
           int article_id,
           int supplier_id,
           java.lang.String supp_article_number,
           java.lang.String description,
           java.lang.String price,
           int currency_id,
           java.math.BigInteger delivery_days,
           java.lang.String tax_description,
           boolean is_enabled) {
           this.supplier_article_id = supplier_article_id;
           this.import_id = import_id;
           this.data_source_id = data_source_id;
           this.article_id = article_id;
           this.supplier_id = supplier_id;
           this.supp_article_number = supp_article_number;
           this.description = description;
           this.price = price;
           this.currency_id = currency_id;
           this.delivery_days = delivery_days;
           this.tax_description = tax_description;
           this.is_enabled = is_enabled;
    }


    /**
     * Gets the supplier_article_id value for this Supplier_article_rec.
     * 
     * @return supplier_article_id
     */
    public int getSupplier_article_id() {
        return supplier_article_id;
    }


    /**
     * Sets the supplier_article_id value for this Supplier_article_rec.
     * 
     * @param supplier_article_id
     */
    public void setSupplier_article_id(int supplier_article_id) {
        this.supplier_article_id = supplier_article_id;
    }


    /**
     * Gets the import_id value for this Supplier_article_rec.
     * 
     * @return import_id
     */
    public java.lang.String getImport_id() {
        return import_id;
    }


    /**
     * Sets the import_id value for this Supplier_article_rec.
     * 
     * @param import_id
     */
    public void setImport_id(java.lang.String import_id) {
        this.import_id = import_id;
    }


    /**
     * Gets the data_source_id value for this Supplier_article_rec.
     * 
     * @return data_source_id
     */
    public int getData_source_id() {
        return data_source_id;
    }


    /**
     * Sets the data_source_id value for this Supplier_article_rec.
     * 
     * @param data_source_id
     */
    public void setData_source_id(int data_source_id) {
        this.data_source_id = data_source_id;
    }


    /**
     * Gets the article_id value for this Supplier_article_rec.
     * 
     * @return article_id
     */
    public int getArticle_id() {
        return article_id;
    }


    /**
     * Sets the article_id value for this Supplier_article_rec.
     * 
     * @param article_id
     */
    public void setArticle_id(int article_id) {
        this.article_id = article_id;
    }


    /**
     * Gets the supplier_id value for this Supplier_article_rec.
     * 
     * @return supplier_id
     */
    public int getSupplier_id() {
        return supplier_id;
    }


    /**
     * Sets the supplier_id value for this Supplier_article_rec.
     * 
     * @param supplier_id
     */
    public void setSupplier_id(int supplier_id) {
        this.supplier_id = supplier_id;
    }


    /**
     * Gets the supp_article_number value for this Supplier_article_rec.
     * 
     * @return supp_article_number
     */
    public java.lang.String getSupp_article_number() {
        return supp_article_number;
    }


    /**
     * Sets the supp_article_number value for this Supplier_article_rec.
     * 
     * @param supp_article_number
     */
    public void setSupp_article_number(java.lang.String supp_article_number) {
        this.supp_article_number = supp_article_number;
    }


    /**
     * Gets the description value for this Supplier_article_rec.
     * 
     * @return description
     */
    public java.lang.String getDescription() {
        return description;
    }


    /**
     * Sets the description value for this Supplier_article_rec.
     * 
     * @param description
     */
    public void setDescription(java.lang.String description) {
        this.description = description;
    }


    /**
     * Gets the price value for this Supplier_article_rec.
     * 
     * @return price
     */
    public java.lang.String getPrice() {
        return price;
    }


    /**
     * Sets the price value for this Supplier_article_rec.
     * 
     * @param price
     */
    public void setPrice(java.lang.String price) {
        this.price = price;
    }


    /**
     * Gets the currency_id value for this Supplier_article_rec.
     * 
     * @return currency_id
     */
    public int getCurrency_id() {
        return currency_id;
    }


    /**
     * Sets the currency_id value for this Supplier_article_rec.
     * 
     * @param currency_id
     */
    public void setCurrency_id(int currency_id) {
        this.currency_id = currency_id;
    }


    /**
     * Gets the delivery_days value for this Supplier_article_rec.
     * 
     * @return delivery_days
     */
    public java.math.BigInteger getDelivery_days() {
        return delivery_days;
    }


    /**
     * Sets the delivery_days value for this Supplier_article_rec.
     * 
     * @param delivery_days
     */
    public void setDelivery_days(java.math.BigInteger delivery_days) {
        this.delivery_days = delivery_days;
    }


    /**
     * Gets the tax_description value for this Supplier_article_rec.
     * 
     * @return tax_description
     */
    public java.lang.String getTax_description() {
        return tax_description;
    }


    /**
     * Sets the tax_description value for this Supplier_article_rec.
     * 
     * @param tax_description
     */
    public void setTax_description(java.lang.String tax_description) {
        this.tax_description = tax_description;
    }


    /**
     * Gets the is_enabled value for this Supplier_article_rec.
     * 
     * @return is_enabled
     */
    public boolean isIs_enabled() {
        return is_enabled;
    }


    /**
     * Sets the is_enabled value for this Supplier_article_rec.
     * 
     * @param is_enabled
     */
    public void setIs_enabled(boolean is_enabled) {
        this.is_enabled = is_enabled;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Supplier_article_rec)) return false;
        Supplier_article_rec other = (Supplier_article_rec) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            this.supplier_article_id == other.getSupplier_article_id() &&
            ((this.import_id==null && other.getImport_id()==null) || 
             (this.import_id!=null &&
              this.import_id.equals(other.getImport_id()))) &&
            this.data_source_id == other.getData_source_id() &&
            this.article_id == other.getArticle_id() &&
            this.supplier_id == other.getSupplier_id() &&
            ((this.supp_article_number==null && other.getSupp_article_number()==null) || 
             (this.supp_article_number!=null &&
              this.supp_article_number.equals(other.getSupp_article_number()))) &&
            ((this.description==null && other.getDescription()==null) || 
             (this.description!=null &&
              this.description.equals(other.getDescription()))) &&
            ((this.price==null && other.getPrice()==null) || 
             (this.price!=null &&
              this.price.equals(other.getPrice()))) &&
            this.currency_id == other.getCurrency_id() &&
            ((this.delivery_days==null && other.getDelivery_days()==null) || 
             (this.delivery_days!=null &&
              this.delivery_days.equals(other.getDelivery_days()))) &&
            ((this.tax_description==null && other.getTax_description()==null) || 
             (this.tax_description!=null &&
              this.tax_description.equals(other.getTax_description()))) &&
            this.is_enabled == other.isIs_enabled();
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        _hashCode += getSupplier_article_id();
        if (getImport_id() != null) {
            _hashCode += getImport_id().hashCode();
        }
        _hashCode += getData_source_id();
        _hashCode += getArticle_id();
        _hashCode += getSupplier_id();
        if (getSupp_article_number() != null) {
            _hashCode += getSupp_article_number().hashCode();
        }
        if (getDescription() != null) {
            _hashCode += getDescription().hashCode();
        }
        if (getPrice() != null) {
            _hashCode += getPrice().hashCode();
        }
        _hashCode += getCurrency_id();
        if (getDelivery_days() != null) {
            _hashCode += getDelivery_days().hashCode();
        }
        if (getTax_description() != null) {
            _hashCode += getTax_description().hashCode();
        }
        _hashCode += (isIs_enabled() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Supplier_article_rec.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://aspera.com/wsdl/", "supplier_article_rec"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("supplier_article_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "supplier_article_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("import_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "import_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("data_source_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "data_source_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("article_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "article_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("supplier_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "supplier_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("supp_article_number");
        elemField.setXmlName(new javax.xml.namespace.QName("", "supp_article_number"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("description");
        elemField.setXmlName(new javax.xml.namespace.QName("", "description"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("price");
        elemField.setXmlName(new javax.xml.namespace.QName("", "price"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("currency_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "currency_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("delivery_days");
        elemField.setXmlName(new javax.xml.namespace.QName("", "delivery_days"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("tax_description");
        elemField.setXmlName(new javax.xml.namespace.QName("", "tax_description"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("is_enabled");
        elemField.setXmlName(new javax.xml.namespace.QName("", "is_enabled"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}

/**
 * Inv_raw_arp_rec.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ca.usm.plugins.samples.resourceplugin.sam.ws.proxy;

public class Inv_raw_arp_rec  implements java.io.Serializable {
    private int inv_raw_arp_id;

    private java.lang.String import_id;

    private int data_source_id;

    private java.lang.String publisher;

    private java.lang.String product;

    private java.lang.String product_version;

    private int device_id;

    private java.lang.String package_id;

    private java.lang.String installation_date;

    public Inv_raw_arp_rec() {
    }

    public Inv_raw_arp_rec(
           int inv_raw_arp_id,
           java.lang.String import_id,
           int data_source_id,
           java.lang.String publisher,
           java.lang.String product,
           java.lang.String product_version,
           int device_id,
           java.lang.String package_id,
           java.lang.String installation_date) {
           this.inv_raw_arp_id = inv_raw_arp_id;
           this.import_id = import_id;
           this.data_source_id = data_source_id;
           this.publisher = publisher;
           this.product = product;
           this.product_version = product_version;
           this.device_id = device_id;
           this.package_id = package_id;
           this.installation_date = installation_date;
    }


    /**
     * Gets the inv_raw_arp_id value for this Inv_raw_arp_rec.
     * 
     * @return inv_raw_arp_id
     */
    public int getInv_raw_arp_id() {
        return inv_raw_arp_id;
    }


    /**
     * Sets the inv_raw_arp_id value for this Inv_raw_arp_rec.
     * 
     * @param inv_raw_arp_id
     */
    public void setInv_raw_arp_id(int inv_raw_arp_id) {
        this.inv_raw_arp_id = inv_raw_arp_id;
    }


    /**
     * Gets the import_id value for this Inv_raw_arp_rec.
     * 
     * @return import_id
     */
    public java.lang.String getImport_id() {
        return import_id;
    }


    /**
     * Sets the import_id value for this Inv_raw_arp_rec.
     * 
     * @param import_id
     */
    public void setImport_id(java.lang.String import_id) {
        this.import_id = import_id;
    }


    /**
     * Gets the data_source_id value for this Inv_raw_arp_rec.
     * 
     * @return data_source_id
     */
    public int getData_source_id() {
        return data_source_id;
    }


    /**
     * Sets the data_source_id value for this Inv_raw_arp_rec.
     * 
     * @param data_source_id
     */
    public void setData_source_id(int data_source_id) {
        this.data_source_id = data_source_id;
    }


    /**
     * Gets the publisher value for this Inv_raw_arp_rec.
     * 
     * @return publisher
     */
    public java.lang.String getPublisher() {
        return publisher;
    }


    /**
     * Sets the publisher value for this Inv_raw_arp_rec.
     * 
     * @param publisher
     */
    public void setPublisher(java.lang.String publisher) {
        this.publisher = publisher;
    }


    /**
     * Gets the product value for this Inv_raw_arp_rec.
     * 
     * @return product
     */
    public java.lang.String getProduct() {
        return product;
    }


    /**
     * Sets the product value for this Inv_raw_arp_rec.
     * 
     * @param product
     */
    public void setProduct(java.lang.String product) {
        this.product = product;
    }


    /**
     * Gets the product_version value for this Inv_raw_arp_rec.
     * 
     * @return product_version
     */
    public java.lang.String getProduct_version() {
        return product_version;
    }


    /**
     * Sets the product_version value for this Inv_raw_arp_rec.
     * 
     * @param product_version
     */
    public void setProduct_version(java.lang.String product_version) {
        this.product_version = product_version;
    }


    /**
     * Gets the device_id value for this Inv_raw_arp_rec.
     * 
     * @return device_id
     */
    public int getDevice_id() {
        return device_id;
    }


    /**
     * Sets the device_id value for this Inv_raw_arp_rec.
     * 
     * @param device_id
     */
    public void setDevice_id(int device_id) {
        this.device_id = device_id;
    }


    /**
     * Gets the package_id value for this Inv_raw_arp_rec.
     * 
     * @return package_id
     */
    public java.lang.String getPackage_id() {
        return package_id;
    }


    /**
     * Sets the package_id value for this Inv_raw_arp_rec.
     * 
     * @param package_id
     */
    public void setPackage_id(java.lang.String package_id) {
        this.package_id = package_id;
    }


    /**
     * Gets the installation_date value for this Inv_raw_arp_rec.
     * 
     * @return installation_date
     */
    public java.lang.String getInstallation_date() {
        return installation_date;
    }


    /**
     * Sets the installation_date value for this Inv_raw_arp_rec.
     * 
     * @param installation_date
     */
    public void setInstallation_date(java.lang.String installation_date) {
        this.installation_date = installation_date;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Inv_raw_arp_rec)) return false;
        Inv_raw_arp_rec other = (Inv_raw_arp_rec) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            this.inv_raw_arp_id == other.getInv_raw_arp_id() &&
            ((this.import_id==null && other.getImport_id()==null) || 
             (this.import_id!=null &&
              this.import_id.equals(other.getImport_id()))) &&
            this.data_source_id == other.getData_source_id() &&
            ((this.publisher==null && other.getPublisher()==null) || 
             (this.publisher!=null &&
              this.publisher.equals(other.getPublisher()))) &&
            ((this.product==null && other.getProduct()==null) || 
             (this.product!=null &&
              this.product.equals(other.getProduct()))) &&
            ((this.product_version==null && other.getProduct_version()==null) || 
             (this.product_version!=null &&
              this.product_version.equals(other.getProduct_version()))) &&
            this.device_id == other.getDevice_id() &&
            ((this.package_id==null && other.getPackage_id()==null) || 
             (this.package_id!=null &&
              this.package_id.equals(other.getPackage_id()))) &&
            ((this.installation_date==null && other.getInstallation_date()==null) || 
             (this.installation_date!=null &&
              this.installation_date.equals(other.getInstallation_date())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        _hashCode += getInv_raw_arp_id();
        if (getImport_id() != null) {
            _hashCode += getImport_id().hashCode();
        }
        _hashCode += getData_source_id();
        if (getPublisher() != null) {
            _hashCode += getPublisher().hashCode();
        }
        if (getProduct() != null) {
            _hashCode += getProduct().hashCode();
        }
        if (getProduct_version() != null) {
            _hashCode += getProduct_version().hashCode();
        }
        _hashCode += getDevice_id();
        if (getPackage_id() != null) {
            _hashCode += getPackage_id().hashCode();
        }
        if (getInstallation_date() != null) {
            _hashCode += getInstallation_date().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Inv_raw_arp_rec.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://aspera.com/wsdl/", "inv_raw_arp_rec"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("inv_raw_arp_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "inv_raw_arp_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("import_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "import_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("data_source_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "data_source_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("publisher");
        elemField.setXmlName(new javax.xml.namespace.QName("", "publisher"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("product");
        elemField.setXmlName(new javax.xml.namespace.QName("", "product"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("product_version");
        elemField.setXmlName(new javax.xml.namespace.QName("", "product_version"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("device_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "device_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("package_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "package_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("installation_date");
        elemField.setXmlName(new javax.xml.namespace.QName("", "installation_date"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}

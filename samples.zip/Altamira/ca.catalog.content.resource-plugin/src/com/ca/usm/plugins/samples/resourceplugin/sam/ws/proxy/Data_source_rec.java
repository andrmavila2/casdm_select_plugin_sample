/**
 * Data_source_rec.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ca.usm.plugins.samples.resourceplugin.sam.ws.proxy;

public class Data_source_rec  implements java.io.Serializable {
    private int data_source_id;

    private java.lang.String import_id;

    private java.lang.String source_key;

    private java.lang.String description;

    private java.lang.String remarks;

    public Data_source_rec() {
    }

    public Data_source_rec(
           int data_source_id,
           java.lang.String import_id,
           java.lang.String source_key,
           java.lang.String description,
           java.lang.String remarks) {
           this.data_source_id = data_source_id;
           this.import_id = import_id;
           this.source_key = source_key;
           this.description = description;
           this.remarks = remarks;
    }


    /**
     * Gets the data_source_id value for this Data_source_rec.
     * 
     * @return data_source_id
     */
    public int getData_source_id() {
        return data_source_id;
    }


    /**
     * Sets the data_source_id value for this Data_source_rec.
     * 
     * @param data_source_id
     */
    public void setData_source_id(int data_source_id) {
        this.data_source_id = data_source_id;
    }


    /**
     * Gets the import_id value for this Data_source_rec.
     * 
     * @return import_id
     */
    public java.lang.String getImport_id() {
        return import_id;
    }


    /**
     * Sets the import_id value for this Data_source_rec.
     * 
     * @param import_id
     */
    public void setImport_id(java.lang.String import_id) {
        this.import_id = import_id;
    }


    /**
     * Gets the source_key value for this Data_source_rec.
     * 
     * @return source_key
     */
    public java.lang.String getSource_key() {
        return source_key;
    }


    /**
     * Sets the source_key value for this Data_source_rec.
     * 
     * @param source_key
     */
    public void setSource_key(java.lang.String source_key) {
        this.source_key = source_key;
    }


    /**
     * Gets the description value for this Data_source_rec.
     * 
     * @return description
     */
    public java.lang.String getDescription() {
        return description;
    }


    /**
     * Sets the description value for this Data_source_rec.
     * 
     * @param description
     */
    public void setDescription(java.lang.String description) {
        this.description = description;
    }


    /**
     * Gets the remarks value for this Data_source_rec.
     * 
     * @return remarks
     */
    public java.lang.String getRemarks() {
        return remarks;
    }


    /**
     * Sets the remarks value for this Data_source_rec.
     * 
     * @param remarks
     */
    public void setRemarks(java.lang.String remarks) {
        this.remarks = remarks;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Data_source_rec)) return false;
        Data_source_rec other = (Data_source_rec) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            this.data_source_id == other.getData_source_id() &&
            ((this.import_id==null && other.getImport_id()==null) || 
             (this.import_id!=null &&
              this.import_id.equals(other.getImport_id()))) &&
            ((this.source_key==null && other.getSource_key()==null) || 
             (this.source_key!=null &&
              this.source_key.equals(other.getSource_key()))) &&
            ((this.description==null && other.getDescription()==null) || 
             (this.description!=null &&
              this.description.equals(other.getDescription()))) &&
            ((this.remarks==null && other.getRemarks()==null) || 
             (this.remarks!=null &&
              this.remarks.equals(other.getRemarks())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        _hashCode += getData_source_id();
        if (getImport_id() != null) {
            _hashCode += getImport_id().hashCode();
        }
        if (getSource_key() != null) {
            _hashCode += getSource_key().hashCode();
        }
        if (getDescription() != null) {
            _hashCode += getDescription().hashCode();
        }
        if (getRemarks() != null) {
            _hashCode += getRemarks().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Data_source_rec.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://aspera.com/wsdl/", "data_source_rec"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("data_source_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "data_source_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("import_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "import_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("source_key");
        elemField.setXmlName(new javax.xml.namespace.QName("", "source_key"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("description");
        elemField.setXmlName(new javax.xml.namespace.QName("", "description"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("remarks");
        elemField.setXmlName(new javax.xml.namespace.QName("", "remarks"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}

package com.ca.usm.plugins.samples.resourceplugin;

import org.w3c.dom.Document;

import java.io.File;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

public class GenerateXML {
	
	
	public void createXML(String query, String outputFile) throws Exception
	{
			 
		  DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
	 
			// root elements
			Document doc = docBuilder.newDocument();
			org.w3c.dom.Element rootElement = doc.createElement("import_set");
			doc.appendChild(rootElement);
	 
			// child elements
			org.w3c.dom.Element keepProcessorFile = doc.createElement("keep_processor_file");
			keepProcessorFile.appendChild(doc.createTextNode("true"));
			rootElement.appendChild(keepProcessorFile);
			
			org.w3c.dom.Element importDefaults = doc.createElement("import_defaults");
			rootElement.appendChild(importDefaults);
			
			org.w3c.dom.Element keepInputFile = doc.createElement("keep_input_file");
			keepInputFile.appendChild(doc.createTextNode("true"));
			importDefaults.appendChild(keepInputFile);
			
			org.w3c.dom.Element strategy = doc.createElement("strategy");
			strategy.appendChild(doc.createTextNode("incremental"));
			importDefaults.appendChild(strategy);
			
			org.w3c.dom.Element mode = doc.createElement("mode");
			mode.appendChild(doc.createTextNode("single"));
			importDefaults.appendChild(mode);
			
			org.w3c.dom.Element headlineValidation = doc.createElement("headline_validation");
			headlineValidation.appendChild(doc.createTextNode("loose"));
			importDefaults.appendChild(headlineValidation);
			
			org.w3c.dom.Element importStep = doc.createElement("import_step");			
			rootElement.appendChild(importStep);
			
			org.w3c.dom.Element importPreprocessor = doc.createElement("import_preprocessor");			
			importStep.appendChild(importPreprocessor);
			
			org.w3c.dom.Element ippName = doc.createElement("ipp_name");
			ippName.appendChild(doc.createTextNode("csv_db_connector"));
			importPreprocessor.appendChild(ippName);
			
			org.w3c.dom.Element ippPparameters = doc.createElement("ipp_parameters");			
			importPreprocessor.appendChild(ippPparameters);
			
			//Param 1
			org.w3c.dom.Element param1 = doc.createElement("param");			
			ippPparameters.appendChild(param1);
			
			org.w3c.dom.Element param1Key = doc.createElement("key");
			param1Key.appendChild(doc.createTextNode("query"));
			param1.appendChild(param1Key);
			
			org.w3c.dom.Element param1Value = doc.createElement("value");
			//CDATASection cdata = doc.createCDATASection("select product_id,description from products");			
			param1Value.appendChild(doc.createCDATASection(query));
			param1.appendChild(param1Value);
			
			//param 2
			org.w3c.dom.Element param2 = doc.createElement("param");			
			ippPparameters.appendChild(param2);
			
			org.w3c.dom.Element param2Key = doc.createElement("key");
			param2Key.appendChild(doc.createTextNode("output_filename"));
			param2.appendChild(param2Key);
			
			org.w3c.dom.Element param2Value = doc.createElement("value");
			param2Value.appendChild(doc.createTextNode(outputFile + ".csv"));
			param2.appendChild(param2Value);
			
			//Param 3
			org.w3c.dom.Element param3 = doc.createElement("param");			
			ippPparameters.appendChild(param3);
			
			org.w3c.dom.Element param3Key = doc.createElement("key");
			param3Key.appendChild(doc.createTextNode("self_connect"));
			param3.appendChild(param3Key);
			
			org.w3c.dom.Element param3Value = doc.createElement("value");
			param3Value.appendChild(doc.createTextNode("true"));
			param3.appendChild(param3Value);
	 
			// write the content into xml file
			TransformerFactory transformerFactory = TransformerFactory.newInstance();
			Transformer transformer = transformerFactory.newTransformer();
			DOMSource source = new DOMSource(doc);
						
			String tempFolder = System.getProperty("java.io.tmpdir");
			StreamResult result = new StreamResult(new File(tempFolder + File.separator + outputFile + ".xml").getAbsolutePath());	
			transformer.transform(source, result);	 
		 
	}
}

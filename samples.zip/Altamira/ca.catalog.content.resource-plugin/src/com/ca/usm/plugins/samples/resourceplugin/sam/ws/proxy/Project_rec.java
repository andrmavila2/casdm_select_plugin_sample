/**
 * Project_rec.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ca.usm.plugins.samples.resourceplugin.sam.ws.proxy;

public class Project_rec  implements java.io.Serializable {
    private int project_id;

    private java.lang.String import_id;

    private int data_source_id;

    private java.lang.String project_key;

    private java.lang.String name;

    private int org_level_0_id;

    private int org_level_1_id;

    private int org_level_2_id;

    private int project_contact_id;

    private java.lang.String start_date;

    private java.lang.String end_date;

    private java.lang.String remarks;

    public Project_rec() {
    }

    public Project_rec(
           int project_id,
           java.lang.String import_id,
           int data_source_id,
           java.lang.String project_key,
           java.lang.String name,
           int org_level_0_id,
           int org_level_1_id,
           int org_level_2_id,
           int project_contact_id,
           java.lang.String start_date,
           java.lang.String end_date,
           java.lang.String remarks) {
           this.project_id = project_id;
           this.import_id = import_id;
           this.data_source_id = data_source_id;
           this.project_key = project_key;
           this.name = name;
           this.org_level_0_id = org_level_0_id;
           this.org_level_1_id = org_level_1_id;
           this.org_level_2_id = org_level_2_id;
           this.project_contact_id = project_contact_id;
           this.start_date = start_date;
           this.end_date = end_date;
           this.remarks = remarks;
    }


    /**
     * Gets the project_id value for this Project_rec.
     * 
     * @return project_id
     */
    public int getProject_id() {
        return project_id;
    }


    /**
     * Sets the project_id value for this Project_rec.
     * 
     * @param project_id
     */
    public void setProject_id(int project_id) {
        this.project_id = project_id;
    }


    /**
     * Gets the import_id value for this Project_rec.
     * 
     * @return import_id
     */
    public java.lang.String getImport_id() {
        return import_id;
    }


    /**
     * Sets the import_id value for this Project_rec.
     * 
     * @param import_id
     */
    public void setImport_id(java.lang.String import_id) {
        this.import_id = import_id;
    }


    /**
     * Gets the data_source_id value for this Project_rec.
     * 
     * @return data_source_id
     */
    public int getData_source_id() {
        return data_source_id;
    }


    /**
     * Sets the data_source_id value for this Project_rec.
     * 
     * @param data_source_id
     */
    public void setData_source_id(int data_source_id) {
        this.data_source_id = data_source_id;
    }


    /**
     * Gets the project_key value for this Project_rec.
     * 
     * @return project_key
     */
    public java.lang.String getProject_key() {
        return project_key;
    }


    /**
     * Sets the project_key value for this Project_rec.
     * 
     * @param project_key
     */
    public void setProject_key(java.lang.String project_key) {
        this.project_key = project_key;
    }


    /**
     * Gets the name value for this Project_rec.
     * 
     * @return name
     */
    public java.lang.String getName() {
        return name;
    }


    /**
     * Sets the name value for this Project_rec.
     * 
     * @param name
     */
    public void setName(java.lang.String name) {
        this.name = name;
    }


    /**
     * Gets the org_level_0_id value for this Project_rec.
     * 
     * @return org_level_0_id
     */
    public int getOrg_level_0_id() {
        return org_level_0_id;
    }


    /**
     * Sets the org_level_0_id value for this Project_rec.
     * 
     * @param org_level_0_id
     */
    public void setOrg_level_0_id(int org_level_0_id) {
        this.org_level_0_id = org_level_0_id;
    }


    /**
     * Gets the org_level_1_id value for this Project_rec.
     * 
     * @return org_level_1_id
     */
    public int getOrg_level_1_id() {
        return org_level_1_id;
    }


    /**
     * Sets the org_level_1_id value for this Project_rec.
     * 
     * @param org_level_1_id
     */
    public void setOrg_level_1_id(int org_level_1_id) {
        this.org_level_1_id = org_level_1_id;
    }


    /**
     * Gets the org_level_2_id value for this Project_rec.
     * 
     * @return org_level_2_id
     */
    public int getOrg_level_2_id() {
        return org_level_2_id;
    }


    /**
     * Sets the org_level_2_id value for this Project_rec.
     * 
     * @param org_level_2_id
     */
    public void setOrg_level_2_id(int org_level_2_id) {
        this.org_level_2_id = org_level_2_id;
    }


    /**
     * Gets the project_contact_id value for this Project_rec.
     * 
     * @return project_contact_id
     */
    public int getProject_contact_id() {
        return project_contact_id;
    }


    /**
     * Sets the project_contact_id value for this Project_rec.
     * 
     * @param project_contact_id
     */
    public void setProject_contact_id(int project_contact_id) {
        this.project_contact_id = project_contact_id;
    }


    /**
     * Gets the start_date value for this Project_rec.
     * 
     * @return start_date
     */
    public java.lang.String getStart_date() {
        return start_date;
    }


    /**
     * Sets the start_date value for this Project_rec.
     * 
     * @param start_date
     */
    public void setStart_date(java.lang.String start_date) {
        this.start_date = start_date;
    }


    /**
     * Gets the end_date value for this Project_rec.
     * 
     * @return end_date
     */
    public java.lang.String getEnd_date() {
        return end_date;
    }


    /**
     * Sets the end_date value for this Project_rec.
     * 
     * @param end_date
     */
    public void setEnd_date(java.lang.String end_date) {
        this.end_date = end_date;
    }


    /**
     * Gets the remarks value for this Project_rec.
     * 
     * @return remarks
     */
    public java.lang.String getRemarks() {
        return remarks;
    }


    /**
     * Sets the remarks value for this Project_rec.
     * 
     * @param remarks
     */
    public void setRemarks(java.lang.String remarks) {
        this.remarks = remarks;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Project_rec)) return false;
        Project_rec other = (Project_rec) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            this.project_id == other.getProject_id() &&
            ((this.import_id==null && other.getImport_id()==null) || 
             (this.import_id!=null &&
              this.import_id.equals(other.getImport_id()))) &&
            this.data_source_id == other.getData_source_id() &&
            ((this.project_key==null && other.getProject_key()==null) || 
             (this.project_key!=null &&
              this.project_key.equals(other.getProject_key()))) &&
            ((this.name==null && other.getName()==null) || 
             (this.name!=null &&
              this.name.equals(other.getName()))) &&
            this.org_level_0_id == other.getOrg_level_0_id() &&
            this.org_level_1_id == other.getOrg_level_1_id() &&
            this.org_level_2_id == other.getOrg_level_2_id() &&
            this.project_contact_id == other.getProject_contact_id() &&
            ((this.start_date==null && other.getStart_date()==null) || 
             (this.start_date!=null &&
              this.start_date.equals(other.getStart_date()))) &&
            ((this.end_date==null && other.getEnd_date()==null) || 
             (this.end_date!=null &&
              this.end_date.equals(other.getEnd_date()))) &&
            ((this.remarks==null && other.getRemarks()==null) || 
             (this.remarks!=null &&
              this.remarks.equals(other.getRemarks())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        _hashCode += getProject_id();
        if (getImport_id() != null) {
            _hashCode += getImport_id().hashCode();
        }
        _hashCode += getData_source_id();
        if (getProject_key() != null) {
            _hashCode += getProject_key().hashCode();
        }
        if (getName() != null) {
            _hashCode += getName().hashCode();
        }
        _hashCode += getOrg_level_0_id();
        _hashCode += getOrg_level_1_id();
        _hashCode += getOrg_level_2_id();
        _hashCode += getProject_contact_id();
        if (getStart_date() != null) {
            _hashCode += getStart_date().hashCode();
        }
        if (getEnd_date() != null) {
            _hashCode += getEnd_date().hashCode();
        }
        if (getRemarks() != null) {
            _hashCode += getRemarks().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Project_rec.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://aspera.com/wsdl/", "project_rec"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("project_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "project_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("import_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "import_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("data_source_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "data_source_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("project_key");
        elemField.setXmlName(new javax.xml.namespace.QName("", "project_key"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("name");
        elemField.setXmlName(new javax.xml.namespace.QName("", "name"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("org_level_0_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "org_level_0_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("org_level_1_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "org_level_1_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("org_level_2_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "org_level_2_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("project_contact_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "project_contact_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("start_date");
        elemField.setXmlName(new javax.xml.namespace.QName("", "start_date"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("end_date");
        elemField.setXmlName(new javax.xml.namespace.QName("", "end_date"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("remarks");
        elemField.setXmlName(new javax.xml.namespace.QName("", "remarks"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}

/**
 * Device_rec.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ca.usm.plugins.samples.resourceplugin.sam.ws.proxy;

public class Device_rec  implements java.io.Serializable {
    private int device_id;

    private java.lang.String import_id;

    private int data_source_id;

    private java.lang.String device_key;

    private int org_level_2_id;

    private java.lang.String device_name;

    private java.lang.String device_manufacturer;

    private java.lang.String device_model;

    private java.lang.String serial_number;

    private java.lang.String operating_system;

    private int device_type_id;

    private int device_status_id;

    private int location_id;

    private int user_id;

    private int contract_id;

    private java.lang.String ip_address;

    private java.lang.String mac_address;

    private java.lang.String fqdn;

    private java.lang.String inventory_number;

    private java.lang.String inventory_date;

    private java.lang.String delivery_date;

    private java.lang.String installation_date;

    private java.math.BigInteger cpu_socket_count;

    private java.lang.String cpu_chip_count;

    private java.lang.String cpu_core_count;

    private java.math.BigInteger cpu_speed;

    private int cpu_type_id;

    private java.lang.String cpu_name;

    private java.math.BigInteger ram;

    private java.math.BigInteger storage;

    private java.lang.String graphics;

    private java.lang.String network;

    private java.lang.String bios;

    private java.lang.String remarks;

    private java.lang.String cust_col_0;

    private java.lang.String cust_col_1;

    public Device_rec() {
    }

    public Device_rec(
           int device_id,
           java.lang.String import_id,
           int data_source_id,
           java.lang.String device_key,
           int org_level_2_id,
           java.lang.String device_name,
           java.lang.String device_manufacturer,
           java.lang.String device_model,
           java.lang.String serial_number,
           java.lang.String operating_system,
           int device_type_id,
           int device_status_id,
           int location_id,
           int user_id,
           int contract_id,
           java.lang.String ip_address,
           java.lang.String mac_address,
           java.lang.String fqdn,
           java.lang.String inventory_number,
           java.lang.String inventory_date,
           java.lang.String delivery_date,
           java.lang.String installation_date,
           java.math.BigInteger cpu_socket_count,
           java.lang.String cpu_chip_count,
           java.lang.String cpu_core_count,
           java.math.BigInteger cpu_speed,
           int cpu_type_id,
           java.lang.String cpu_name,
           java.math.BigInteger ram,
           java.math.BigInteger storage,
           java.lang.String graphics,
           java.lang.String network,
           java.lang.String bios,
           java.lang.String remarks,
           java.lang.String cust_col_0,
           java.lang.String cust_col_1) {
           this.device_id = device_id;
           this.import_id = import_id;
           this.data_source_id = data_source_id;
           this.device_key = device_key;
           this.org_level_2_id = org_level_2_id;
           this.device_name = device_name;
           this.device_manufacturer = device_manufacturer;
           this.device_model = device_model;
           this.serial_number = serial_number;
           this.operating_system = operating_system;
           this.device_type_id = device_type_id;
           this.device_status_id = device_status_id;
           this.location_id = location_id;
           this.user_id = user_id;
           this.contract_id = contract_id;
           this.ip_address = ip_address;
           this.mac_address = mac_address;
           this.fqdn = fqdn;
           this.inventory_number = inventory_number;
           this.inventory_date = inventory_date;
           this.delivery_date = delivery_date;
           this.installation_date = installation_date;
           this.cpu_socket_count = cpu_socket_count;
           this.cpu_chip_count = cpu_chip_count;
           this.cpu_core_count = cpu_core_count;
           this.cpu_speed = cpu_speed;
           this.cpu_type_id = cpu_type_id;
           this.cpu_name = cpu_name;
           this.ram = ram;
           this.storage = storage;
           this.graphics = graphics;
           this.network = network;
           this.bios = bios;
           this.remarks = remarks;
           this.cust_col_0 = cust_col_0;
           this.cust_col_1 = cust_col_1;
    }


    /**
     * Gets the device_id value for this Device_rec.
     * 
     * @return device_id
     */
    public int getDevice_id() {
        return device_id;
    }


    /**
     * Sets the device_id value for this Device_rec.
     * 
     * @param device_id
     */
    public void setDevice_id(int device_id) {
        this.device_id = device_id;
    }


    /**
     * Gets the import_id value for this Device_rec.
     * 
     * @return import_id
     */
    public java.lang.String getImport_id() {
        return import_id;
    }


    /**
     * Sets the import_id value for this Device_rec.
     * 
     * @param import_id
     */
    public void setImport_id(java.lang.String import_id) {
        this.import_id = import_id;
    }


    /**
     * Gets the data_source_id value for this Device_rec.
     * 
     * @return data_source_id
     */
    public int getData_source_id() {
        return data_source_id;
    }


    /**
     * Sets the data_source_id value for this Device_rec.
     * 
     * @param data_source_id
     */
    public void setData_source_id(int data_source_id) {
        this.data_source_id = data_source_id;
    }


    /**
     * Gets the device_key value for this Device_rec.
     * 
     * @return device_key
     */
    public java.lang.String getDevice_key() {
        return device_key;
    }


    /**
     * Sets the device_key value for this Device_rec.
     * 
     * @param device_key
     */
    public void setDevice_key(java.lang.String device_key) {
        this.device_key = device_key;
    }


    /**
     * Gets the org_level_2_id value for this Device_rec.
     * 
     * @return org_level_2_id
     */
    public int getOrg_level_2_id() {
        return org_level_2_id;
    }


    /**
     * Sets the org_level_2_id value for this Device_rec.
     * 
     * @param org_level_2_id
     */
    public void setOrg_level_2_id(int org_level_2_id) {
        this.org_level_2_id = org_level_2_id;
    }


    /**
     * Gets the device_name value for this Device_rec.
     * 
     * @return device_name
     */
    public java.lang.String getDevice_name() {
        return device_name;
    }


    /**
     * Sets the device_name value for this Device_rec.
     * 
     * @param device_name
     */
    public void setDevice_name(java.lang.String device_name) {
        this.device_name = device_name;
    }


    /**
     * Gets the device_manufacturer value for this Device_rec.
     * 
     * @return device_manufacturer
     */
    public java.lang.String getDevice_manufacturer() {
        return device_manufacturer;
    }


    /**
     * Sets the device_manufacturer value for this Device_rec.
     * 
     * @param device_manufacturer
     */
    public void setDevice_manufacturer(java.lang.String device_manufacturer) {
        this.device_manufacturer = device_manufacturer;
    }


    /**
     * Gets the device_model value for this Device_rec.
     * 
     * @return device_model
     */
    public java.lang.String getDevice_model() {
        return device_model;
    }


    /**
     * Sets the device_model value for this Device_rec.
     * 
     * @param device_model
     */
    public void setDevice_model(java.lang.String device_model) {
        this.device_model = device_model;
    }


    /**
     * Gets the serial_number value for this Device_rec.
     * 
     * @return serial_number
     */
    public java.lang.String getSerial_number() {
        return serial_number;
    }


    /**
     * Sets the serial_number value for this Device_rec.
     * 
     * @param serial_number
     */
    public void setSerial_number(java.lang.String serial_number) {
        this.serial_number = serial_number;
    }


    /**
     * Gets the operating_system value for this Device_rec.
     * 
     * @return operating_system
     */
    public java.lang.String getOperating_system() {
        return operating_system;
    }


    /**
     * Sets the operating_system value for this Device_rec.
     * 
     * @param operating_system
     */
    public void setOperating_system(java.lang.String operating_system) {
        this.operating_system = operating_system;
    }


    /**
     * Gets the device_type_id value for this Device_rec.
     * 
     * @return device_type_id
     */
    public int getDevice_type_id() {
        return device_type_id;
    }


    /**
     * Sets the device_type_id value for this Device_rec.
     * 
     * @param device_type_id
     */
    public void setDevice_type_id(int device_type_id) {
        this.device_type_id = device_type_id;
    }


    /**
     * Gets the device_status_id value for this Device_rec.
     * 
     * @return device_status_id
     */
    public int getDevice_status_id() {
        return device_status_id;
    }


    /**
     * Sets the device_status_id value for this Device_rec.
     * 
     * @param device_status_id
     */
    public void setDevice_status_id(int device_status_id) {
        this.device_status_id = device_status_id;
    }


    /**
     * Gets the location_id value for this Device_rec.
     * 
     * @return location_id
     */
    public int getLocation_id() {
        return location_id;
    }


    /**
     * Sets the location_id value for this Device_rec.
     * 
     * @param location_id
     */
    public void setLocation_id(int location_id) {
        this.location_id = location_id;
    }


    /**
     * Gets the user_id value for this Device_rec.
     * 
     * @return user_id
     */
    public int getUser_id() {
        return user_id;
    }


    /**
     * Sets the user_id value for this Device_rec.
     * 
     * @param user_id
     */
    public void setUser_id(int user_id) {
        this.user_id = user_id;
    }


    /**
     * Gets the contract_id value for this Device_rec.
     * 
     * @return contract_id
     */
    public int getContract_id() {
        return contract_id;
    }


    /**
     * Sets the contract_id value for this Device_rec.
     * 
     * @param contract_id
     */
    public void setContract_id(int contract_id) {
        this.contract_id = contract_id;
    }


    /**
     * Gets the ip_address value for this Device_rec.
     * 
     * @return ip_address
     */
    public java.lang.String getIp_address() {
        return ip_address;
    }


    /**
     * Sets the ip_address value for this Device_rec.
     * 
     * @param ip_address
     */
    public void setIp_address(java.lang.String ip_address) {
        this.ip_address = ip_address;
    }


    /**
     * Gets the mac_address value for this Device_rec.
     * 
     * @return mac_address
     */
    public java.lang.String getMac_address() {
        return mac_address;
    }


    /**
     * Sets the mac_address value for this Device_rec.
     * 
     * @param mac_address
     */
    public void setMac_address(java.lang.String mac_address) {
        this.mac_address = mac_address;
    }


    /**
     * Gets the fqdn value for this Device_rec.
     * 
     * @return fqdn
     */
    public java.lang.String getFqdn() {
        return fqdn;
    }


    /**
     * Sets the fqdn value for this Device_rec.
     * 
     * @param fqdn
     */
    public void setFqdn(java.lang.String fqdn) {
        this.fqdn = fqdn;
    }


    /**
     * Gets the inventory_number value for this Device_rec.
     * 
     * @return inventory_number
     */
    public java.lang.String getInventory_number() {
        return inventory_number;
    }


    /**
     * Sets the inventory_number value for this Device_rec.
     * 
     * @param inventory_number
     */
    public void setInventory_number(java.lang.String inventory_number) {
        this.inventory_number = inventory_number;
    }


    /**
     * Gets the inventory_date value for this Device_rec.
     * 
     * @return inventory_date
     */
    public java.lang.String getInventory_date() {
        return inventory_date;
    }


    /**
     * Sets the inventory_date value for this Device_rec.
     * 
     * @param inventory_date
     */
    public void setInventory_date(java.lang.String inventory_date) {
        this.inventory_date = inventory_date;
    }


    /**
     * Gets the delivery_date value for this Device_rec.
     * 
     * @return delivery_date
     */
    public java.lang.String getDelivery_date() {
        return delivery_date;
    }


    /**
     * Sets the delivery_date value for this Device_rec.
     * 
     * @param delivery_date
     */
    public void setDelivery_date(java.lang.String delivery_date) {
        this.delivery_date = delivery_date;
    }


    /**
     * Gets the installation_date value for this Device_rec.
     * 
     * @return installation_date
     */
    public java.lang.String getInstallation_date() {
        return installation_date;
    }


    /**
     * Sets the installation_date value for this Device_rec.
     * 
     * @param installation_date
     */
    public void setInstallation_date(java.lang.String installation_date) {
        this.installation_date = installation_date;
    }


    /**
     * Gets the cpu_socket_count value for this Device_rec.
     * 
     * @return cpu_socket_count
     */
    public java.math.BigInteger getCpu_socket_count() {
        return cpu_socket_count;
    }


    /**
     * Sets the cpu_socket_count value for this Device_rec.
     * 
     * @param cpu_socket_count
     */
    public void setCpu_socket_count(java.math.BigInteger cpu_socket_count) {
        this.cpu_socket_count = cpu_socket_count;
    }


    /**
     * Gets the cpu_chip_count value for this Device_rec.
     * 
     * @return cpu_chip_count
     */
    public java.lang.String getCpu_chip_count() {
        return cpu_chip_count;
    }


    /**
     * Sets the cpu_chip_count value for this Device_rec.
     * 
     * @param cpu_chip_count
     */
    public void setCpu_chip_count(java.lang.String cpu_chip_count) {
        this.cpu_chip_count = cpu_chip_count;
    }


    /**
     * Gets the cpu_core_count value for this Device_rec.
     * 
     * @return cpu_core_count
     */
    public java.lang.String getCpu_core_count() {
        return cpu_core_count;
    }


    /**
     * Sets the cpu_core_count value for this Device_rec.
     * 
     * @param cpu_core_count
     */
    public void setCpu_core_count(java.lang.String cpu_core_count) {
        this.cpu_core_count = cpu_core_count;
    }


    /**
     * Gets the cpu_speed value for this Device_rec.
     * 
     * @return cpu_speed
     */
    public java.math.BigInteger getCpu_speed() {
        return cpu_speed;
    }


    /**
     * Sets the cpu_speed value for this Device_rec.
     * 
     * @param cpu_speed
     */
    public void setCpu_speed(java.math.BigInteger cpu_speed) {
        this.cpu_speed = cpu_speed;
    }


    /**
     * Gets the cpu_type_id value for this Device_rec.
     * 
     * @return cpu_type_id
     */
    public int getCpu_type_id() {
        return cpu_type_id;
    }


    /**
     * Sets the cpu_type_id value for this Device_rec.
     * 
     * @param cpu_type_id
     */
    public void setCpu_type_id(int cpu_type_id) {
        this.cpu_type_id = cpu_type_id;
    }


    /**
     * Gets the cpu_name value for this Device_rec.
     * 
     * @return cpu_name
     */
    public java.lang.String getCpu_name() {
        return cpu_name;
    }


    /**
     * Sets the cpu_name value for this Device_rec.
     * 
     * @param cpu_name
     */
    public void setCpu_name(java.lang.String cpu_name) {
        this.cpu_name = cpu_name;
    }


    /**
     * Gets the ram value for this Device_rec.
     * 
     * @return ram
     */
    public java.math.BigInteger getRam() {
        return ram;
    }


    /**
     * Sets the ram value for this Device_rec.
     * 
     * @param ram
     */
    public void setRam(java.math.BigInteger ram) {
        this.ram = ram;
    }


    /**
     * Gets the storage value for this Device_rec.
     * 
     * @return storage
     */
    public java.math.BigInteger getStorage() {
        return storage;
    }


    /**
     * Sets the storage value for this Device_rec.
     * 
     * @param storage
     */
    public void setStorage(java.math.BigInteger storage) {
        this.storage = storage;
    }


    /**
     * Gets the graphics value for this Device_rec.
     * 
     * @return graphics
     */
    public java.lang.String getGraphics() {
        return graphics;
    }


    /**
     * Sets the graphics value for this Device_rec.
     * 
     * @param graphics
     */
    public void setGraphics(java.lang.String graphics) {
        this.graphics = graphics;
    }


    /**
     * Gets the network value for this Device_rec.
     * 
     * @return network
     */
    public java.lang.String getNetwork() {
        return network;
    }


    /**
     * Sets the network value for this Device_rec.
     * 
     * @param network
     */
    public void setNetwork(java.lang.String network) {
        this.network = network;
    }


    /**
     * Gets the bios value for this Device_rec.
     * 
     * @return bios
     */
    public java.lang.String getBios() {
        return bios;
    }


    /**
     * Sets the bios value for this Device_rec.
     * 
     * @param bios
     */
    public void setBios(java.lang.String bios) {
        this.bios = bios;
    }


    /**
     * Gets the remarks value for this Device_rec.
     * 
     * @return remarks
     */
    public java.lang.String getRemarks() {
        return remarks;
    }


    /**
     * Sets the remarks value for this Device_rec.
     * 
     * @param remarks
     */
    public void setRemarks(java.lang.String remarks) {
        this.remarks = remarks;
    }


    /**
     * Gets the cust_col_0 value for this Device_rec.
     * 
     * @return cust_col_0
     */
    public java.lang.String getCust_col_0() {
        return cust_col_0;
    }


    /**
     * Sets the cust_col_0 value for this Device_rec.
     * 
     * @param cust_col_0
     */
    public void setCust_col_0(java.lang.String cust_col_0) {
        this.cust_col_0 = cust_col_0;
    }


    /**
     * Gets the cust_col_1 value for this Device_rec.
     * 
     * @return cust_col_1
     */
    public java.lang.String getCust_col_1() {
        return cust_col_1;
    }


    /**
     * Sets the cust_col_1 value for this Device_rec.
     * 
     * @param cust_col_1
     */
    public void setCust_col_1(java.lang.String cust_col_1) {
        this.cust_col_1 = cust_col_1;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Device_rec)) return false;
        Device_rec other = (Device_rec) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            this.device_id == other.getDevice_id() &&
            ((this.import_id==null && other.getImport_id()==null) || 
             (this.import_id!=null &&
              this.import_id.equals(other.getImport_id()))) &&
            this.data_source_id == other.getData_source_id() &&
            ((this.device_key==null && other.getDevice_key()==null) || 
             (this.device_key!=null &&
              this.device_key.equals(other.getDevice_key()))) &&
            this.org_level_2_id == other.getOrg_level_2_id() &&
            ((this.device_name==null && other.getDevice_name()==null) || 
             (this.device_name!=null &&
              this.device_name.equals(other.getDevice_name()))) &&
            ((this.device_manufacturer==null && other.getDevice_manufacturer()==null) || 
             (this.device_manufacturer!=null &&
              this.device_manufacturer.equals(other.getDevice_manufacturer()))) &&
            ((this.device_model==null && other.getDevice_model()==null) || 
             (this.device_model!=null &&
              this.device_model.equals(other.getDevice_model()))) &&
            ((this.serial_number==null && other.getSerial_number()==null) || 
             (this.serial_number!=null &&
              this.serial_number.equals(other.getSerial_number()))) &&
            ((this.operating_system==null && other.getOperating_system()==null) || 
             (this.operating_system!=null &&
              this.operating_system.equals(other.getOperating_system()))) &&
            this.device_type_id == other.getDevice_type_id() &&
            this.device_status_id == other.getDevice_status_id() &&
            this.location_id == other.getLocation_id() &&
            this.user_id == other.getUser_id() &&
            this.contract_id == other.getContract_id() &&
            ((this.ip_address==null && other.getIp_address()==null) || 
             (this.ip_address!=null &&
              this.ip_address.equals(other.getIp_address()))) &&
            ((this.mac_address==null && other.getMac_address()==null) || 
             (this.mac_address!=null &&
              this.mac_address.equals(other.getMac_address()))) &&
            ((this.fqdn==null && other.getFqdn()==null) || 
             (this.fqdn!=null &&
              this.fqdn.equals(other.getFqdn()))) &&
            ((this.inventory_number==null && other.getInventory_number()==null) || 
             (this.inventory_number!=null &&
              this.inventory_number.equals(other.getInventory_number()))) &&
            ((this.inventory_date==null && other.getInventory_date()==null) || 
             (this.inventory_date!=null &&
              this.inventory_date.equals(other.getInventory_date()))) &&
            ((this.delivery_date==null && other.getDelivery_date()==null) || 
             (this.delivery_date!=null &&
              this.delivery_date.equals(other.getDelivery_date()))) &&
            ((this.installation_date==null && other.getInstallation_date()==null) || 
             (this.installation_date!=null &&
              this.installation_date.equals(other.getInstallation_date()))) &&
            ((this.cpu_socket_count==null && other.getCpu_socket_count()==null) || 
             (this.cpu_socket_count!=null &&
              this.cpu_socket_count.equals(other.getCpu_socket_count()))) &&
            ((this.cpu_chip_count==null && other.getCpu_chip_count()==null) || 
             (this.cpu_chip_count!=null &&
              this.cpu_chip_count.equals(other.getCpu_chip_count()))) &&
            ((this.cpu_core_count==null && other.getCpu_core_count()==null) || 
             (this.cpu_core_count!=null &&
              this.cpu_core_count.equals(other.getCpu_core_count()))) &&
            ((this.cpu_speed==null && other.getCpu_speed()==null) || 
             (this.cpu_speed!=null &&
              this.cpu_speed.equals(other.getCpu_speed()))) &&
            this.cpu_type_id == other.getCpu_type_id() &&
            ((this.cpu_name==null && other.getCpu_name()==null) || 
             (this.cpu_name!=null &&
              this.cpu_name.equals(other.getCpu_name()))) &&
            ((this.ram==null && other.getRam()==null) || 
             (this.ram!=null &&
              this.ram.equals(other.getRam()))) &&
            ((this.storage==null && other.getStorage()==null) || 
             (this.storage!=null &&
              this.storage.equals(other.getStorage()))) &&
            ((this.graphics==null && other.getGraphics()==null) || 
             (this.graphics!=null &&
              this.graphics.equals(other.getGraphics()))) &&
            ((this.network==null && other.getNetwork()==null) || 
             (this.network!=null &&
              this.network.equals(other.getNetwork()))) &&
            ((this.bios==null && other.getBios()==null) || 
             (this.bios!=null &&
              this.bios.equals(other.getBios()))) &&
            ((this.remarks==null && other.getRemarks()==null) || 
             (this.remarks!=null &&
              this.remarks.equals(other.getRemarks()))) &&
            ((this.cust_col_0==null && other.getCust_col_0()==null) || 
             (this.cust_col_0!=null &&
              this.cust_col_0.equals(other.getCust_col_0()))) &&
            ((this.cust_col_1==null && other.getCust_col_1()==null) || 
             (this.cust_col_1!=null &&
              this.cust_col_1.equals(other.getCust_col_1())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        _hashCode += getDevice_id();
        if (getImport_id() != null) {
            _hashCode += getImport_id().hashCode();
        }
        _hashCode += getData_source_id();
        if (getDevice_key() != null) {
            _hashCode += getDevice_key().hashCode();
        }
        _hashCode += getOrg_level_2_id();
        if (getDevice_name() != null) {
            _hashCode += getDevice_name().hashCode();
        }
        if (getDevice_manufacturer() != null) {
            _hashCode += getDevice_manufacturer().hashCode();
        }
        if (getDevice_model() != null) {
            _hashCode += getDevice_model().hashCode();
        }
        if (getSerial_number() != null) {
            _hashCode += getSerial_number().hashCode();
        }
        if (getOperating_system() != null) {
            _hashCode += getOperating_system().hashCode();
        }
        _hashCode += getDevice_type_id();
        _hashCode += getDevice_status_id();
        _hashCode += getLocation_id();
        _hashCode += getUser_id();
        _hashCode += getContract_id();
        if (getIp_address() != null) {
            _hashCode += getIp_address().hashCode();
        }
        if (getMac_address() != null) {
            _hashCode += getMac_address().hashCode();
        }
        if (getFqdn() != null) {
            _hashCode += getFqdn().hashCode();
        }
        if (getInventory_number() != null) {
            _hashCode += getInventory_number().hashCode();
        }
        if (getInventory_date() != null) {
            _hashCode += getInventory_date().hashCode();
        }
        if (getDelivery_date() != null) {
            _hashCode += getDelivery_date().hashCode();
        }
        if (getInstallation_date() != null) {
            _hashCode += getInstallation_date().hashCode();
        }
        if (getCpu_socket_count() != null) {
            _hashCode += getCpu_socket_count().hashCode();
        }
        if (getCpu_chip_count() != null) {
            _hashCode += getCpu_chip_count().hashCode();
        }
        if (getCpu_core_count() != null) {
            _hashCode += getCpu_core_count().hashCode();
        }
        if (getCpu_speed() != null) {
            _hashCode += getCpu_speed().hashCode();
        }
        _hashCode += getCpu_type_id();
        if (getCpu_name() != null) {
            _hashCode += getCpu_name().hashCode();
        }
        if (getRam() != null) {
            _hashCode += getRam().hashCode();
        }
        if (getStorage() != null) {
            _hashCode += getStorage().hashCode();
        }
        if (getGraphics() != null) {
            _hashCode += getGraphics().hashCode();
        }
        if (getNetwork() != null) {
            _hashCode += getNetwork().hashCode();
        }
        if (getBios() != null) {
            _hashCode += getBios().hashCode();
        }
        if (getRemarks() != null) {
            _hashCode += getRemarks().hashCode();
        }
        if (getCust_col_0() != null) {
            _hashCode += getCust_col_0().hashCode();
        }
        if (getCust_col_1() != null) {
            _hashCode += getCust_col_1().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Device_rec.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://aspera.com/wsdl/", "device_rec"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("device_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "device_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("import_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "import_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("data_source_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "data_source_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("device_key");
        elemField.setXmlName(new javax.xml.namespace.QName("", "device_key"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("org_level_2_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "org_level_2_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("device_name");
        elemField.setXmlName(new javax.xml.namespace.QName("", "device_name"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("device_manufacturer");
        elemField.setXmlName(new javax.xml.namespace.QName("", "device_manufacturer"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("device_model");
        elemField.setXmlName(new javax.xml.namespace.QName("", "device_model"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("serial_number");
        elemField.setXmlName(new javax.xml.namespace.QName("", "serial_number"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("operating_system");
        elemField.setXmlName(new javax.xml.namespace.QName("", "operating_system"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("device_type_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "device_type_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("device_status_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "device_status_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("location_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "location_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("user_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "user_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("contract_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "contract_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ip_address");
        elemField.setXmlName(new javax.xml.namespace.QName("", "ip_address"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("mac_address");
        elemField.setXmlName(new javax.xml.namespace.QName("", "mac_address"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("fqdn");
        elemField.setXmlName(new javax.xml.namespace.QName("", "fqdn"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("inventory_number");
        elemField.setXmlName(new javax.xml.namespace.QName("", "inventory_number"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("inventory_date");
        elemField.setXmlName(new javax.xml.namespace.QName("", "inventory_date"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("delivery_date");
        elemField.setXmlName(new javax.xml.namespace.QName("", "delivery_date"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("installation_date");
        elemField.setXmlName(new javax.xml.namespace.QName("", "installation_date"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("cpu_socket_count");
        elemField.setXmlName(new javax.xml.namespace.QName("", "cpu_socket_count"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("cpu_chip_count");
        elemField.setXmlName(new javax.xml.namespace.QName("", "cpu_chip_count"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("cpu_core_count");
        elemField.setXmlName(new javax.xml.namespace.QName("", "cpu_core_count"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("cpu_speed");
        elemField.setXmlName(new javax.xml.namespace.QName("", "cpu_speed"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("cpu_type_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "cpu_type_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("cpu_name");
        elemField.setXmlName(new javax.xml.namespace.QName("", "cpu_name"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ram");
        elemField.setXmlName(new javax.xml.namespace.QName("", "ram"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("storage");
        elemField.setXmlName(new javax.xml.namespace.QName("", "storage"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("graphics");
        elemField.setXmlName(new javax.xml.namespace.QName("", "graphics"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("network");
        elemField.setXmlName(new javax.xml.namespace.QName("", "network"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("bios");
        elemField.setXmlName(new javax.xml.namespace.QName("", "bios"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("remarks");
        elemField.setXmlName(new javax.xml.namespace.QName("", "remarks"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("cust_col_0");
        elemField.setXmlName(new javax.xml.namespace.QName("", "cust_col_0"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("cust_col_1");
        elemField.setXmlName(new javax.xml.namespace.QName("", "cust_col_1"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}

/**
 * Inv_user_metering_rec.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ca.usm.plugins.samples.resourceplugin.sam.ws.proxy;

public class Inv_user_metering_rec  implements java.io.Serializable {
    private int inv_user_metering_id;

    private java.lang.String import_id;

    private int data_source_id;

    private int inv_user_id;

    private java.lang.String last_usage;

    private int last_usage_device_id;

    private java.math.BigInteger usage_frequency_month;

    public Inv_user_metering_rec() {
    }

    public Inv_user_metering_rec(
           int inv_user_metering_id,
           java.lang.String import_id,
           int data_source_id,
           int inv_user_id,
           java.lang.String last_usage,
           int last_usage_device_id,
           java.math.BigInteger usage_frequency_month) {
           this.inv_user_metering_id = inv_user_metering_id;
           this.import_id = import_id;
           this.data_source_id = data_source_id;
           this.inv_user_id = inv_user_id;
           this.last_usage = last_usage;
           this.last_usage_device_id = last_usage_device_id;
           this.usage_frequency_month = usage_frequency_month;
    }


    /**
     * Gets the inv_user_metering_id value for this Inv_user_metering_rec.
     * 
     * @return inv_user_metering_id
     */
    public int getInv_user_metering_id() {
        return inv_user_metering_id;
    }


    /**
     * Sets the inv_user_metering_id value for this Inv_user_metering_rec.
     * 
     * @param inv_user_metering_id
     */
    public void setInv_user_metering_id(int inv_user_metering_id) {
        this.inv_user_metering_id = inv_user_metering_id;
    }


    /**
     * Gets the import_id value for this Inv_user_metering_rec.
     * 
     * @return import_id
     */
    public java.lang.String getImport_id() {
        return import_id;
    }


    /**
     * Sets the import_id value for this Inv_user_metering_rec.
     * 
     * @param import_id
     */
    public void setImport_id(java.lang.String import_id) {
        this.import_id = import_id;
    }


    /**
     * Gets the data_source_id value for this Inv_user_metering_rec.
     * 
     * @return data_source_id
     */
    public int getData_source_id() {
        return data_source_id;
    }


    /**
     * Sets the data_source_id value for this Inv_user_metering_rec.
     * 
     * @param data_source_id
     */
    public void setData_source_id(int data_source_id) {
        this.data_source_id = data_source_id;
    }


    /**
     * Gets the inv_user_id value for this Inv_user_metering_rec.
     * 
     * @return inv_user_id
     */
    public int getInv_user_id() {
        return inv_user_id;
    }


    /**
     * Sets the inv_user_id value for this Inv_user_metering_rec.
     * 
     * @param inv_user_id
     */
    public void setInv_user_id(int inv_user_id) {
        this.inv_user_id = inv_user_id;
    }


    /**
     * Gets the last_usage value for this Inv_user_metering_rec.
     * 
     * @return last_usage
     */
    public java.lang.String getLast_usage() {
        return last_usage;
    }


    /**
     * Sets the last_usage value for this Inv_user_metering_rec.
     * 
     * @param last_usage
     */
    public void setLast_usage(java.lang.String last_usage) {
        this.last_usage = last_usage;
    }


    /**
     * Gets the last_usage_device_id value for this Inv_user_metering_rec.
     * 
     * @return last_usage_device_id
     */
    public int getLast_usage_device_id() {
        return last_usage_device_id;
    }


    /**
     * Sets the last_usage_device_id value for this Inv_user_metering_rec.
     * 
     * @param last_usage_device_id
     */
    public void setLast_usage_device_id(int last_usage_device_id) {
        this.last_usage_device_id = last_usage_device_id;
    }


    /**
     * Gets the usage_frequency_month value for this Inv_user_metering_rec.
     * 
     * @return usage_frequency_month
     */
    public java.math.BigInteger getUsage_frequency_month() {
        return usage_frequency_month;
    }


    /**
     * Sets the usage_frequency_month value for this Inv_user_metering_rec.
     * 
     * @param usage_frequency_month
     */
    public void setUsage_frequency_month(java.math.BigInteger usage_frequency_month) {
        this.usage_frequency_month = usage_frequency_month;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Inv_user_metering_rec)) return false;
        Inv_user_metering_rec other = (Inv_user_metering_rec) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            this.inv_user_metering_id == other.getInv_user_metering_id() &&
            ((this.import_id==null && other.getImport_id()==null) || 
             (this.import_id!=null &&
              this.import_id.equals(other.getImport_id()))) &&
            this.data_source_id == other.getData_source_id() &&
            this.inv_user_id == other.getInv_user_id() &&
            ((this.last_usage==null && other.getLast_usage()==null) || 
             (this.last_usage!=null &&
              this.last_usage.equals(other.getLast_usage()))) &&
            this.last_usage_device_id == other.getLast_usage_device_id() &&
            ((this.usage_frequency_month==null && other.getUsage_frequency_month()==null) || 
             (this.usage_frequency_month!=null &&
              this.usage_frequency_month.equals(other.getUsage_frequency_month())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        _hashCode += getInv_user_metering_id();
        if (getImport_id() != null) {
            _hashCode += getImport_id().hashCode();
        }
        _hashCode += getData_source_id();
        _hashCode += getInv_user_id();
        if (getLast_usage() != null) {
            _hashCode += getLast_usage().hashCode();
        }
        _hashCode += getLast_usage_device_id();
        if (getUsage_frequency_month() != null) {
            _hashCode += getUsage_frequency_month().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Inv_user_metering_rec.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://aspera.com/wsdl/", "inv_user_metering_rec"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("inv_user_metering_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "inv_user_metering_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("import_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "import_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("data_source_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "data_source_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("inv_user_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "inv_user_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("last_usage");
        elemField.setXmlName(new javax.xml.namespace.QName("", "last_usage"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("last_usage_device_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "last_usage_device_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("usage_frequency_month");
        elemField.setXmlName(new javax.xml.namespace.QName("", "usage_frequency_month"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}

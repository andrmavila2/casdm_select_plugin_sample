/**
 * Monitor_data_exchange_process_rec.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ca.usm.plugins.samples.resourceplugin.sam.ws.proxy;

public class Monitor_data_exchange_process_rec  implements java.io.Serializable {
    private java.lang.String file_name;

    private java.lang.String exchange_dir;

    private java.lang.String unique_part;

    private java.lang.String start_date;

    private java.lang.String end_date;

    public Monitor_data_exchange_process_rec() {
    }

    public Monitor_data_exchange_process_rec(
           java.lang.String file_name,
           java.lang.String exchange_dir,
           java.lang.String unique_part,
           java.lang.String start_date,
           java.lang.String end_date) {
           this.file_name = file_name;
           this.exchange_dir = exchange_dir;
           this.unique_part = unique_part;
           this.start_date = start_date;
           this.end_date = end_date;
    }


    /**
     * Gets the file_name value for this Monitor_data_exchange_process_rec.
     * 
     * @return file_name
     */
    public java.lang.String getFile_name() {
        return file_name;
    }


    /**
     * Sets the file_name value for this Monitor_data_exchange_process_rec.
     * 
     * @param file_name
     */
    public void setFile_name(java.lang.String file_name) {
        this.file_name = file_name;
    }


    /**
     * Gets the exchange_dir value for this Monitor_data_exchange_process_rec.
     * 
     * @return exchange_dir
     */
    public java.lang.String getExchange_dir() {
        return exchange_dir;
    }


    /**
     * Sets the exchange_dir value for this Monitor_data_exchange_process_rec.
     * 
     * @param exchange_dir
     */
    public void setExchange_dir(java.lang.String exchange_dir) {
        this.exchange_dir = exchange_dir;
    }


    /**
     * Gets the unique_part value for this Monitor_data_exchange_process_rec.
     * 
     * @return unique_part
     */
    public java.lang.String getUnique_part() {
        return unique_part;
    }


    /**
     * Sets the unique_part value for this Monitor_data_exchange_process_rec.
     * 
     * @param unique_part
     */
    public void setUnique_part(java.lang.String unique_part) {
        this.unique_part = unique_part;
    }


    /**
     * Gets the start_date value for this Monitor_data_exchange_process_rec.
     * 
     * @return start_date
     */
    public java.lang.String getStart_date() {
        return start_date;
    }


    /**
     * Sets the start_date value for this Monitor_data_exchange_process_rec.
     * 
     * @param start_date
     */
    public void setStart_date(java.lang.String start_date) {
        this.start_date = start_date;
    }


    /**
     * Gets the end_date value for this Monitor_data_exchange_process_rec.
     * 
     * @return end_date
     */
    public java.lang.String getEnd_date() {
        return end_date;
    }


    /**
     * Sets the end_date value for this Monitor_data_exchange_process_rec.
     * 
     * @param end_date
     */
    public void setEnd_date(java.lang.String end_date) {
        this.end_date = end_date;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Monitor_data_exchange_process_rec)) return false;
        Monitor_data_exchange_process_rec other = (Monitor_data_exchange_process_rec) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.file_name==null && other.getFile_name()==null) || 
             (this.file_name!=null &&
              this.file_name.equals(other.getFile_name()))) &&
            ((this.exchange_dir==null && other.getExchange_dir()==null) || 
             (this.exchange_dir!=null &&
              this.exchange_dir.equals(other.getExchange_dir()))) &&
            ((this.unique_part==null && other.getUnique_part()==null) || 
             (this.unique_part!=null &&
              this.unique_part.equals(other.getUnique_part()))) &&
            ((this.start_date==null && other.getStart_date()==null) || 
             (this.start_date!=null &&
              this.start_date.equals(other.getStart_date()))) &&
            ((this.end_date==null && other.getEnd_date()==null) || 
             (this.end_date!=null &&
              this.end_date.equals(other.getEnd_date())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getFile_name() != null) {
            _hashCode += getFile_name().hashCode();
        }
        if (getExchange_dir() != null) {
            _hashCode += getExchange_dir().hashCode();
        }
        if (getUnique_part() != null) {
            _hashCode += getUnique_part().hashCode();
        }
        if (getStart_date() != null) {
            _hashCode += getStart_date().hashCode();
        }
        if (getEnd_date() != null) {
            _hashCode += getEnd_date().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Monitor_data_exchange_process_rec.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://aspera.com/wsdl/", "monitor_data_exchange_process_rec"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("file_name");
        elemField.setXmlName(new javax.xml.namespace.QName("", "file_name"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("exchange_dir");
        elemField.setXmlName(new javax.xml.namespace.QName("", "exchange_dir"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("unique_part");
        elemField.setXmlName(new javax.xml.namespace.QName("", "unique_part"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("start_date");
        elemField.setXmlName(new javax.xml.namespace.QName("", "start_date"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("end_date");
        elemField.setXmlName(new javax.xml.namespace.QName("", "end_date"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}

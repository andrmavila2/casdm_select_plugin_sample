/**
 * Lic_cert_scope_rec.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ca.usm.plugins.samples.resourceplugin.sam.ws.proxy;

public class Lic_cert_scope_rec  implements java.io.Serializable {
    private int lic_cert_scope_id;

    private java.lang.String import_id;

    private int data_source_id;

    private int license_certificate_id;

    private int org_level_0_id;

    private int org_level_1_id;

    private int org_level_2_id;

    public Lic_cert_scope_rec() {
    }

    public Lic_cert_scope_rec(
           int lic_cert_scope_id,
           java.lang.String import_id,
           int data_source_id,
           int license_certificate_id,
           int org_level_0_id,
           int org_level_1_id,
           int org_level_2_id) {
           this.lic_cert_scope_id = lic_cert_scope_id;
           this.import_id = import_id;
           this.data_source_id = data_source_id;
           this.license_certificate_id = license_certificate_id;
           this.org_level_0_id = org_level_0_id;
           this.org_level_1_id = org_level_1_id;
           this.org_level_2_id = org_level_2_id;
    }


    /**
     * Gets the lic_cert_scope_id value for this Lic_cert_scope_rec.
     * 
     * @return lic_cert_scope_id
     */
    public int getLic_cert_scope_id() {
        return lic_cert_scope_id;
    }


    /**
     * Sets the lic_cert_scope_id value for this Lic_cert_scope_rec.
     * 
     * @param lic_cert_scope_id
     */
    public void setLic_cert_scope_id(int lic_cert_scope_id) {
        this.lic_cert_scope_id = lic_cert_scope_id;
    }


    /**
     * Gets the import_id value for this Lic_cert_scope_rec.
     * 
     * @return import_id
     */
    public java.lang.String getImport_id() {
        return import_id;
    }


    /**
     * Sets the import_id value for this Lic_cert_scope_rec.
     * 
     * @param import_id
     */
    public void setImport_id(java.lang.String import_id) {
        this.import_id = import_id;
    }


    /**
     * Gets the data_source_id value for this Lic_cert_scope_rec.
     * 
     * @return data_source_id
     */
    public int getData_source_id() {
        return data_source_id;
    }


    /**
     * Sets the data_source_id value for this Lic_cert_scope_rec.
     * 
     * @param data_source_id
     */
    public void setData_source_id(int data_source_id) {
        this.data_source_id = data_source_id;
    }


    /**
     * Gets the license_certificate_id value for this Lic_cert_scope_rec.
     * 
     * @return license_certificate_id
     */
    public int getLicense_certificate_id() {
        return license_certificate_id;
    }


    /**
     * Sets the license_certificate_id value for this Lic_cert_scope_rec.
     * 
     * @param license_certificate_id
     */
    public void setLicense_certificate_id(int license_certificate_id) {
        this.license_certificate_id = license_certificate_id;
    }


    /**
     * Gets the org_level_0_id value for this Lic_cert_scope_rec.
     * 
     * @return org_level_0_id
     */
    public int getOrg_level_0_id() {
        return org_level_0_id;
    }


    /**
     * Sets the org_level_0_id value for this Lic_cert_scope_rec.
     * 
     * @param org_level_0_id
     */
    public void setOrg_level_0_id(int org_level_0_id) {
        this.org_level_0_id = org_level_0_id;
    }


    /**
     * Gets the org_level_1_id value for this Lic_cert_scope_rec.
     * 
     * @return org_level_1_id
     */
    public int getOrg_level_1_id() {
        return org_level_1_id;
    }


    /**
     * Sets the org_level_1_id value for this Lic_cert_scope_rec.
     * 
     * @param org_level_1_id
     */
    public void setOrg_level_1_id(int org_level_1_id) {
        this.org_level_1_id = org_level_1_id;
    }


    /**
     * Gets the org_level_2_id value for this Lic_cert_scope_rec.
     * 
     * @return org_level_2_id
     */
    public int getOrg_level_2_id() {
        return org_level_2_id;
    }


    /**
     * Sets the org_level_2_id value for this Lic_cert_scope_rec.
     * 
     * @param org_level_2_id
     */
    public void setOrg_level_2_id(int org_level_2_id) {
        this.org_level_2_id = org_level_2_id;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Lic_cert_scope_rec)) return false;
        Lic_cert_scope_rec other = (Lic_cert_scope_rec) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            this.lic_cert_scope_id == other.getLic_cert_scope_id() &&
            ((this.import_id==null && other.getImport_id()==null) || 
             (this.import_id!=null &&
              this.import_id.equals(other.getImport_id()))) &&
            this.data_source_id == other.getData_source_id() &&
            this.license_certificate_id == other.getLicense_certificate_id() &&
            this.org_level_0_id == other.getOrg_level_0_id() &&
            this.org_level_1_id == other.getOrg_level_1_id() &&
            this.org_level_2_id == other.getOrg_level_2_id();
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        _hashCode += getLic_cert_scope_id();
        if (getImport_id() != null) {
            _hashCode += getImport_id().hashCode();
        }
        _hashCode += getData_source_id();
        _hashCode += getLicense_certificate_id();
        _hashCode += getOrg_level_0_id();
        _hashCode += getOrg_level_1_id();
        _hashCode += getOrg_level_2_id();
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Lic_cert_scope_rec.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://aspera.com/wsdl/", "lic_cert_scope_rec"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lic_cert_scope_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "lic_cert_scope_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("import_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "import_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("data_source_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "data_source_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("license_certificate_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "license_certificate_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("org_level_0_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "org_level_0_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("org_level_1_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "org_level_1_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("org_level_2_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "org_level_2_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}

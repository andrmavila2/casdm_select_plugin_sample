/**
 * Inv_user_tracking_rec.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ca.usm.plugins.samples.resourceplugin.sam.ws.proxy;

public class Inv_user_tracking_rec  implements java.io.Serializable {
    private int inv_user_tracking_id;

    private java.lang.String import_id;

    private int data_source_id;

    private int inv_user_id;

    private java.lang.String tracking_date;

    private java.lang.String quantity;

    private java.lang.String remarks;

    public Inv_user_tracking_rec() {
    }

    public Inv_user_tracking_rec(
           int inv_user_tracking_id,
           java.lang.String import_id,
           int data_source_id,
           int inv_user_id,
           java.lang.String tracking_date,
           java.lang.String quantity,
           java.lang.String remarks) {
           this.inv_user_tracking_id = inv_user_tracking_id;
           this.import_id = import_id;
           this.data_source_id = data_source_id;
           this.inv_user_id = inv_user_id;
           this.tracking_date = tracking_date;
           this.quantity = quantity;
           this.remarks = remarks;
    }


    /**
     * Gets the inv_user_tracking_id value for this Inv_user_tracking_rec.
     * 
     * @return inv_user_tracking_id
     */
    public int getInv_user_tracking_id() {
        return inv_user_tracking_id;
    }


    /**
     * Sets the inv_user_tracking_id value for this Inv_user_tracking_rec.
     * 
     * @param inv_user_tracking_id
     */
    public void setInv_user_tracking_id(int inv_user_tracking_id) {
        this.inv_user_tracking_id = inv_user_tracking_id;
    }


    /**
     * Gets the import_id value for this Inv_user_tracking_rec.
     * 
     * @return import_id
     */
    public java.lang.String getImport_id() {
        return import_id;
    }


    /**
     * Sets the import_id value for this Inv_user_tracking_rec.
     * 
     * @param import_id
     */
    public void setImport_id(java.lang.String import_id) {
        this.import_id = import_id;
    }


    /**
     * Gets the data_source_id value for this Inv_user_tracking_rec.
     * 
     * @return data_source_id
     */
    public int getData_source_id() {
        return data_source_id;
    }


    /**
     * Sets the data_source_id value for this Inv_user_tracking_rec.
     * 
     * @param data_source_id
     */
    public void setData_source_id(int data_source_id) {
        this.data_source_id = data_source_id;
    }


    /**
     * Gets the inv_user_id value for this Inv_user_tracking_rec.
     * 
     * @return inv_user_id
     */
    public int getInv_user_id() {
        return inv_user_id;
    }


    /**
     * Sets the inv_user_id value for this Inv_user_tracking_rec.
     * 
     * @param inv_user_id
     */
    public void setInv_user_id(int inv_user_id) {
        this.inv_user_id = inv_user_id;
    }


    /**
     * Gets the tracking_date value for this Inv_user_tracking_rec.
     * 
     * @return tracking_date
     */
    public java.lang.String getTracking_date() {
        return tracking_date;
    }


    /**
     * Sets the tracking_date value for this Inv_user_tracking_rec.
     * 
     * @param tracking_date
     */
    public void setTracking_date(java.lang.String tracking_date) {
        this.tracking_date = tracking_date;
    }


    /**
     * Gets the quantity value for this Inv_user_tracking_rec.
     * 
     * @return quantity
     */
    public java.lang.String getQuantity() {
        return quantity;
    }


    /**
     * Sets the quantity value for this Inv_user_tracking_rec.
     * 
     * @param quantity
     */
    public void setQuantity(java.lang.String quantity) {
        this.quantity = quantity;
    }


    /**
     * Gets the remarks value for this Inv_user_tracking_rec.
     * 
     * @return remarks
     */
    public java.lang.String getRemarks() {
        return remarks;
    }


    /**
     * Sets the remarks value for this Inv_user_tracking_rec.
     * 
     * @param remarks
     */
    public void setRemarks(java.lang.String remarks) {
        this.remarks = remarks;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Inv_user_tracking_rec)) return false;
        Inv_user_tracking_rec other = (Inv_user_tracking_rec) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            this.inv_user_tracking_id == other.getInv_user_tracking_id() &&
            ((this.import_id==null && other.getImport_id()==null) || 
             (this.import_id!=null &&
              this.import_id.equals(other.getImport_id()))) &&
            this.data_source_id == other.getData_source_id() &&
            this.inv_user_id == other.getInv_user_id() &&
            ((this.tracking_date==null && other.getTracking_date()==null) || 
             (this.tracking_date!=null &&
              this.tracking_date.equals(other.getTracking_date()))) &&
            ((this.quantity==null && other.getQuantity()==null) || 
             (this.quantity!=null &&
              this.quantity.equals(other.getQuantity()))) &&
            ((this.remarks==null && other.getRemarks()==null) || 
             (this.remarks!=null &&
              this.remarks.equals(other.getRemarks())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        _hashCode += getInv_user_tracking_id();
        if (getImport_id() != null) {
            _hashCode += getImport_id().hashCode();
        }
        _hashCode += getData_source_id();
        _hashCode += getInv_user_id();
        if (getTracking_date() != null) {
            _hashCode += getTracking_date().hashCode();
        }
        if (getQuantity() != null) {
            _hashCode += getQuantity().hashCode();
        }
        if (getRemarks() != null) {
            _hashCode += getRemarks().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Inv_user_tracking_rec.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://aspera.com/wsdl/", "inv_user_tracking_rec"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("inv_user_tracking_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "inv_user_tracking_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("import_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "import_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("data_source_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "data_source_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("inv_user_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "inv_user_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("tracking_date");
        elemField.setXmlName(new javax.xml.namespace.QName("", "tracking_date"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("quantity");
        elemField.setXmlName(new javax.xml.namespace.QName("", "quantity"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("remarks");
        elemField.setXmlName(new javax.xml.namespace.QName("", "remarks"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}

/**
 * Cpu_type_rec.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ca.usm.plugins.samples.resourceplugin.sam.ws.proxy;

public class Cpu_type_rec  implements java.io.Serializable {
    private int cpu_type_id;

    private java.lang.String import_id;

    private int data_source_id;

    private java.lang.String name;

    private java.math.BigInteger ibm_pvus;

    private java.lang.String oracle_core_factor;

    private java.lang.String microsoft_core_factor;

    private java.lang.String remarks;

    public Cpu_type_rec() {
    }

    public Cpu_type_rec(
           int cpu_type_id,
           java.lang.String import_id,
           int data_source_id,
           java.lang.String name,
           java.math.BigInteger ibm_pvus,
           java.lang.String oracle_core_factor,
           java.lang.String microsoft_core_factor,
           java.lang.String remarks) {
           this.cpu_type_id = cpu_type_id;
           this.import_id = import_id;
           this.data_source_id = data_source_id;
           this.name = name;
           this.ibm_pvus = ibm_pvus;
           this.oracle_core_factor = oracle_core_factor;
           this.microsoft_core_factor = microsoft_core_factor;
           this.remarks = remarks;
    }


    /**
     * Gets the cpu_type_id value for this Cpu_type_rec.
     * 
     * @return cpu_type_id
     */
    public int getCpu_type_id() {
        return cpu_type_id;
    }


    /**
     * Sets the cpu_type_id value for this Cpu_type_rec.
     * 
     * @param cpu_type_id
     */
    public void setCpu_type_id(int cpu_type_id) {
        this.cpu_type_id = cpu_type_id;
    }


    /**
     * Gets the import_id value for this Cpu_type_rec.
     * 
     * @return import_id
     */
    public java.lang.String getImport_id() {
        return import_id;
    }


    /**
     * Sets the import_id value for this Cpu_type_rec.
     * 
     * @param import_id
     */
    public void setImport_id(java.lang.String import_id) {
        this.import_id = import_id;
    }


    /**
     * Gets the data_source_id value for this Cpu_type_rec.
     * 
     * @return data_source_id
     */
    public int getData_source_id() {
        return data_source_id;
    }


    /**
     * Sets the data_source_id value for this Cpu_type_rec.
     * 
     * @param data_source_id
     */
    public void setData_source_id(int data_source_id) {
        this.data_source_id = data_source_id;
    }


    /**
     * Gets the name value for this Cpu_type_rec.
     * 
     * @return name
     */
    public java.lang.String getName() {
        return name;
    }


    /**
     * Sets the name value for this Cpu_type_rec.
     * 
     * @param name
     */
    public void setName(java.lang.String name) {
        this.name = name;
    }


    /**
     * Gets the ibm_pvus value for this Cpu_type_rec.
     * 
     * @return ibm_pvus
     */
    public java.math.BigInteger getIbm_pvus() {
        return ibm_pvus;
    }


    /**
     * Sets the ibm_pvus value for this Cpu_type_rec.
     * 
     * @param ibm_pvus
     */
    public void setIbm_pvus(java.math.BigInteger ibm_pvus) {
        this.ibm_pvus = ibm_pvus;
    }


    /**
     * Gets the oracle_core_factor value for this Cpu_type_rec.
     * 
     * @return oracle_core_factor
     */
    public java.lang.String getOracle_core_factor() {
        return oracle_core_factor;
    }


    /**
     * Sets the oracle_core_factor value for this Cpu_type_rec.
     * 
     * @param oracle_core_factor
     */
    public void setOracle_core_factor(java.lang.String oracle_core_factor) {
        this.oracle_core_factor = oracle_core_factor;
    }


    /**
     * Gets the microsoft_core_factor value for this Cpu_type_rec.
     * 
     * @return microsoft_core_factor
     */
    public java.lang.String getMicrosoft_core_factor() {
        return microsoft_core_factor;
    }


    /**
     * Sets the microsoft_core_factor value for this Cpu_type_rec.
     * 
     * @param microsoft_core_factor
     */
    public void setMicrosoft_core_factor(java.lang.String microsoft_core_factor) {
        this.microsoft_core_factor = microsoft_core_factor;
    }


    /**
     * Gets the remarks value for this Cpu_type_rec.
     * 
     * @return remarks
     */
    public java.lang.String getRemarks() {
        return remarks;
    }


    /**
     * Sets the remarks value for this Cpu_type_rec.
     * 
     * @param remarks
     */
    public void setRemarks(java.lang.String remarks) {
        this.remarks = remarks;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Cpu_type_rec)) return false;
        Cpu_type_rec other = (Cpu_type_rec) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            this.cpu_type_id == other.getCpu_type_id() &&
            ((this.import_id==null && other.getImport_id()==null) || 
             (this.import_id!=null &&
              this.import_id.equals(other.getImport_id()))) &&
            this.data_source_id == other.getData_source_id() &&
            ((this.name==null && other.getName()==null) || 
             (this.name!=null &&
              this.name.equals(other.getName()))) &&
            ((this.ibm_pvus==null && other.getIbm_pvus()==null) || 
             (this.ibm_pvus!=null &&
              this.ibm_pvus.equals(other.getIbm_pvus()))) &&
            ((this.oracle_core_factor==null && other.getOracle_core_factor()==null) || 
             (this.oracle_core_factor!=null &&
              this.oracle_core_factor.equals(other.getOracle_core_factor()))) &&
            ((this.microsoft_core_factor==null && other.getMicrosoft_core_factor()==null) || 
             (this.microsoft_core_factor!=null &&
              this.microsoft_core_factor.equals(other.getMicrosoft_core_factor()))) &&
            ((this.remarks==null && other.getRemarks()==null) || 
             (this.remarks!=null &&
              this.remarks.equals(other.getRemarks())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        _hashCode += getCpu_type_id();
        if (getImport_id() != null) {
            _hashCode += getImport_id().hashCode();
        }
        _hashCode += getData_source_id();
        if (getName() != null) {
            _hashCode += getName().hashCode();
        }
        if (getIbm_pvus() != null) {
            _hashCode += getIbm_pvus().hashCode();
        }
        if (getOracle_core_factor() != null) {
            _hashCode += getOracle_core_factor().hashCode();
        }
        if (getMicrosoft_core_factor() != null) {
            _hashCode += getMicrosoft_core_factor().hashCode();
        }
        if (getRemarks() != null) {
            _hashCode += getRemarks().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Cpu_type_rec.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://aspera.com/wsdl/", "cpu_type_rec"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("cpu_type_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "cpu_type_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("import_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "import_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("data_source_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "data_source_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("name");
        elemField.setXmlName(new javax.xml.namespace.QName("", "name"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ibm_pvus");
        elemField.setXmlName(new javax.xml.namespace.QName("", "ibm_pvus"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("oracle_core_factor");
        elemField.setXmlName(new javax.xml.namespace.QName("", "oracle_core_factor"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("microsoft_core_factor");
        elemField.setXmlName(new javax.xml.namespace.QName("", "microsoft_core_factor"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("remarks");
        elemField.setXmlName(new javax.xml.namespace.QName("", "remarks"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}

/**
 * Inv_synonym_rec.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ca.usm.plugins.samples.resourceplugin.sam.ws.proxy;

public class Inv_synonym_rec  implements java.io.Serializable {
    private int inv_synonym_id;

    private java.lang.String import_id;

    private int data_source_id;

    private java.lang.String inv_synonym_key;

    private java.lang.String description;

    private java.lang.String remarks;

    private int product_id;

    private boolean use_to_install;

    private boolean ignore_usage;

    public Inv_synonym_rec() {
    }

    public Inv_synonym_rec(
           int inv_synonym_id,
           java.lang.String import_id,
           int data_source_id,
           java.lang.String inv_synonym_key,
           java.lang.String description,
           java.lang.String remarks,
           int product_id,
           boolean use_to_install,
           boolean ignore_usage) {
           this.inv_synonym_id = inv_synonym_id;
           this.import_id = import_id;
           this.data_source_id = data_source_id;
           this.inv_synonym_key = inv_synonym_key;
           this.description = description;
           this.remarks = remarks;
           this.product_id = product_id;
           this.use_to_install = use_to_install;
           this.ignore_usage = ignore_usage;
    }


    /**
     * Gets the inv_synonym_id value for this Inv_synonym_rec.
     * 
     * @return inv_synonym_id
     */
    public int getInv_synonym_id() {
        return inv_synonym_id;
    }


    /**
     * Sets the inv_synonym_id value for this Inv_synonym_rec.
     * 
     * @param inv_synonym_id
     */
    public void setInv_synonym_id(int inv_synonym_id) {
        this.inv_synonym_id = inv_synonym_id;
    }


    /**
     * Gets the import_id value for this Inv_synonym_rec.
     * 
     * @return import_id
     */
    public java.lang.String getImport_id() {
        return import_id;
    }


    /**
     * Sets the import_id value for this Inv_synonym_rec.
     * 
     * @param import_id
     */
    public void setImport_id(java.lang.String import_id) {
        this.import_id = import_id;
    }


    /**
     * Gets the data_source_id value for this Inv_synonym_rec.
     * 
     * @return data_source_id
     */
    public int getData_source_id() {
        return data_source_id;
    }


    /**
     * Sets the data_source_id value for this Inv_synonym_rec.
     * 
     * @param data_source_id
     */
    public void setData_source_id(int data_source_id) {
        this.data_source_id = data_source_id;
    }


    /**
     * Gets the inv_synonym_key value for this Inv_synonym_rec.
     * 
     * @return inv_synonym_key
     */
    public java.lang.String getInv_synonym_key() {
        return inv_synonym_key;
    }


    /**
     * Sets the inv_synonym_key value for this Inv_synonym_rec.
     * 
     * @param inv_synonym_key
     */
    public void setInv_synonym_key(java.lang.String inv_synonym_key) {
        this.inv_synonym_key = inv_synonym_key;
    }


    /**
     * Gets the description value for this Inv_synonym_rec.
     * 
     * @return description
     */
    public java.lang.String getDescription() {
        return description;
    }


    /**
     * Sets the description value for this Inv_synonym_rec.
     * 
     * @param description
     */
    public void setDescription(java.lang.String description) {
        this.description = description;
    }


    /**
     * Gets the remarks value for this Inv_synonym_rec.
     * 
     * @return remarks
     */
    public java.lang.String getRemarks() {
        return remarks;
    }


    /**
     * Sets the remarks value for this Inv_synonym_rec.
     * 
     * @param remarks
     */
    public void setRemarks(java.lang.String remarks) {
        this.remarks = remarks;
    }


    /**
     * Gets the product_id value for this Inv_synonym_rec.
     * 
     * @return product_id
     */
    public int getProduct_id() {
        return product_id;
    }


    /**
     * Sets the product_id value for this Inv_synonym_rec.
     * 
     * @param product_id
     */
    public void setProduct_id(int product_id) {
        this.product_id = product_id;
    }


    /**
     * Gets the use_to_install value for this Inv_synonym_rec.
     * 
     * @return use_to_install
     */
    public boolean isUse_to_install() {
        return use_to_install;
    }


    /**
     * Sets the use_to_install value for this Inv_synonym_rec.
     * 
     * @param use_to_install
     */
    public void setUse_to_install(boolean use_to_install) {
        this.use_to_install = use_to_install;
    }


    /**
     * Gets the ignore_usage value for this Inv_synonym_rec.
     * 
     * @return ignore_usage
     */
    public boolean isIgnore_usage() {
        return ignore_usage;
    }


    /**
     * Sets the ignore_usage value for this Inv_synonym_rec.
     * 
     * @param ignore_usage
     */
    public void setIgnore_usage(boolean ignore_usage) {
        this.ignore_usage = ignore_usage;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Inv_synonym_rec)) return false;
        Inv_synonym_rec other = (Inv_synonym_rec) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            this.inv_synonym_id == other.getInv_synonym_id() &&
            ((this.import_id==null && other.getImport_id()==null) || 
             (this.import_id!=null &&
              this.import_id.equals(other.getImport_id()))) &&
            this.data_source_id == other.getData_source_id() &&
            ((this.inv_synonym_key==null && other.getInv_synonym_key()==null) || 
             (this.inv_synonym_key!=null &&
              this.inv_synonym_key.equals(other.getInv_synonym_key()))) &&
            ((this.description==null && other.getDescription()==null) || 
             (this.description!=null &&
              this.description.equals(other.getDescription()))) &&
            ((this.remarks==null && other.getRemarks()==null) || 
             (this.remarks!=null &&
              this.remarks.equals(other.getRemarks()))) &&
            this.product_id == other.getProduct_id() &&
            this.use_to_install == other.isUse_to_install() &&
            this.ignore_usage == other.isIgnore_usage();
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        _hashCode += getInv_synonym_id();
        if (getImport_id() != null) {
            _hashCode += getImport_id().hashCode();
        }
        _hashCode += getData_source_id();
        if (getInv_synonym_key() != null) {
            _hashCode += getInv_synonym_key().hashCode();
        }
        if (getDescription() != null) {
            _hashCode += getDescription().hashCode();
        }
        if (getRemarks() != null) {
            _hashCode += getRemarks().hashCode();
        }
        _hashCode += getProduct_id();
        _hashCode += (isUse_to_install() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        _hashCode += (isIgnore_usage() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Inv_synonym_rec.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://aspera.com/wsdl/", "inv_synonym_rec"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("inv_synonym_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "inv_synonym_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("import_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "import_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("data_source_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "data_source_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("inv_synonym_key");
        elemField.setXmlName(new javax.xml.namespace.QName("", "inv_synonym_key"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("description");
        elemField.setXmlName(new javax.xml.namespace.QName("", "description"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("remarks");
        elemField.setXmlName(new javax.xml.namespace.QName("", "remarks"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("product_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "product_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("use_to_install");
        elemField.setXmlName(new javax.xml.namespace.QName("", "use_to_install"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ignore_usage");
        elemField.setXmlName(new javax.xml.namespace.QName("", "ignore_usage"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}

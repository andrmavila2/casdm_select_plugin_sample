/**
 * Product_family_rec.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ca.usm.plugins.samples.resourceplugin.sam.ws.proxy;

public class Product_family_rec  implements java.io.Serializable {
    private int product_family_id;

    private java.lang.String import_id;

    private int data_source_id;

    private int manufacturer_id;

    private int software_class_id;

    private java.lang.String description;

    private boolean is_line_of_business;

    private java.lang.String long_description;

    private java.lang.String remarks;

    public Product_family_rec() {
    }

    public Product_family_rec(
           int product_family_id,
           java.lang.String import_id,
           int data_source_id,
           int manufacturer_id,
           int software_class_id,
           java.lang.String description,
           boolean is_line_of_business,
           java.lang.String long_description,
           java.lang.String remarks) {
           this.product_family_id = product_family_id;
           this.import_id = import_id;
           this.data_source_id = data_source_id;
           this.manufacturer_id = manufacturer_id;
           this.software_class_id = software_class_id;
           this.description = description;
           this.is_line_of_business = is_line_of_business;
           this.long_description = long_description;
           this.remarks = remarks;
    }


    /**
     * Gets the product_family_id value for this Product_family_rec.
     * 
     * @return product_family_id
     */
    public int getProduct_family_id() {
        return product_family_id;
    }


    /**
     * Sets the product_family_id value for this Product_family_rec.
     * 
     * @param product_family_id
     */
    public void setProduct_family_id(int product_family_id) {
        this.product_family_id = product_family_id;
    }


    /**
     * Gets the import_id value for this Product_family_rec.
     * 
     * @return import_id
     */
    public java.lang.String getImport_id() {
        return import_id;
    }


    /**
     * Sets the import_id value for this Product_family_rec.
     * 
     * @param import_id
     */
    public void setImport_id(java.lang.String import_id) {
        this.import_id = import_id;
    }


    /**
     * Gets the data_source_id value for this Product_family_rec.
     * 
     * @return data_source_id
     */
    public int getData_source_id() {
        return data_source_id;
    }


    /**
     * Sets the data_source_id value for this Product_family_rec.
     * 
     * @param data_source_id
     */
    public void setData_source_id(int data_source_id) {
        this.data_source_id = data_source_id;
    }


    /**
     * Gets the manufacturer_id value for this Product_family_rec.
     * 
     * @return manufacturer_id
     */
    public int getManufacturer_id() {
        return manufacturer_id;
    }


    /**
     * Sets the manufacturer_id value for this Product_family_rec.
     * 
     * @param manufacturer_id
     */
    public void setManufacturer_id(int manufacturer_id) {
        this.manufacturer_id = manufacturer_id;
    }


    /**
     * Gets the software_class_id value for this Product_family_rec.
     * 
     * @return software_class_id
     */
    public int getSoftware_class_id() {
        return software_class_id;
    }


    /**
     * Sets the software_class_id value for this Product_family_rec.
     * 
     * @param software_class_id
     */
    public void setSoftware_class_id(int software_class_id) {
        this.software_class_id = software_class_id;
    }


    /**
     * Gets the description value for this Product_family_rec.
     * 
     * @return description
     */
    public java.lang.String getDescription() {
        return description;
    }


    /**
     * Sets the description value for this Product_family_rec.
     * 
     * @param description
     */
    public void setDescription(java.lang.String description) {
        this.description = description;
    }


    /**
     * Gets the is_line_of_business value for this Product_family_rec.
     * 
     * @return is_line_of_business
     */
    public boolean isIs_line_of_business() {
        return is_line_of_business;
    }


    /**
     * Sets the is_line_of_business value for this Product_family_rec.
     * 
     * @param is_line_of_business
     */
    public void setIs_line_of_business(boolean is_line_of_business) {
        this.is_line_of_business = is_line_of_business;
    }


    /**
     * Gets the long_description value for this Product_family_rec.
     * 
     * @return long_description
     */
    public java.lang.String getLong_description() {
        return long_description;
    }


    /**
     * Sets the long_description value for this Product_family_rec.
     * 
     * @param long_description
     */
    public void setLong_description(java.lang.String long_description) {
        this.long_description = long_description;
    }


    /**
     * Gets the remarks value for this Product_family_rec.
     * 
     * @return remarks
     */
    public java.lang.String getRemarks() {
        return remarks;
    }


    /**
     * Sets the remarks value for this Product_family_rec.
     * 
     * @param remarks
     */
    public void setRemarks(java.lang.String remarks) {
        this.remarks = remarks;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Product_family_rec)) return false;
        Product_family_rec other = (Product_family_rec) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            this.product_family_id == other.getProduct_family_id() &&
            ((this.import_id==null && other.getImport_id()==null) || 
             (this.import_id!=null &&
              this.import_id.equals(other.getImport_id()))) &&
            this.data_source_id == other.getData_source_id() &&
            this.manufacturer_id == other.getManufacturer_id() &&
            this.software_class_id == other.getSoftware_class_id() &&
            ((this.description==null && other.getDescription()==null) || 
             (this.description!=null &&
              this.description.equals(other.getDescription()))) &&
            this.is_line_of_business == other.isIs_line_of_business() &&
            ((this.long_description==null && other.getLong_description()==null) || 
             (this.long_description!=null &&
              this.long_description.equals(other.getLong_description()))) &&
            ((this.remarks==null && other.getRemarks()==null) || 
             (this.remarks!=null &&
              this.remarks.equals(other.getRemarks())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        _hashCode += getProduct_family_id();
        if (getImport_id() != null) {
            _hashCode += getImport_id().hashCode();
        }
        _hashCode += getData_source_id();
        _hashCode += getManufacturer_id();
        _hashCode += getSoftware_class_id();
        if (getDescription() != null) {
            _hashCode += getDescription().hashCode();
        }
        _hashCode += (isIs_line_of_business() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        if (getLong_description() != null) {
            _hashCode += getLong_description().hashCode();
        }
        if (getRemarks() != null) {
            _hashCode += getRemarks().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Product_family_rec.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://aspera.com/wsdl/", "product_family_rec"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("product_family_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "product_family_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("import_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "import_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("data_source_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "data_source_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("manufacturer_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "manufacturer_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("software_class_id");
        elemField.setXmlName(new javax.xml.namespace.QName("", "software_class_id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("description");
        elemField.setXmlName(new javax.xml.namespace.QName("", "description"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("is_line_of_business");
        elemField.setXmlName(new javax.xml.namespace.QName("", "is_line_of_business"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("long_description");
        elemField.setXmlName(new javax.xml.namespace.QName("", "long_description"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("remarks");
        elemField.setXmlName(new javax.xml.namespace.QName("", "remarks"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}

/**
 * St_import.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.ca.usm.plugins.samples.resourceplugin.sam.ws.proxy;

public interface St_import extends javax.xml.rpc.Service {
    public java.lang.String getst_importPortAddress();

    public com.ca.usm.plugins.samples.resourceplugin.sam.ws.proxy.St_importPortType getst_importPort() throws javax.xml.rpc.ServiceException;

    public com.ca.usm.plugins.samples.resourceplugin.sam.ws.proxy.St_importPortType getst_importPort(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}

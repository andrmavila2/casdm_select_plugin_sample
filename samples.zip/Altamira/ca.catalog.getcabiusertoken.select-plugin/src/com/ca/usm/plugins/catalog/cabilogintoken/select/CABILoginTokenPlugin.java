package com.ca.usm.plugins.catalog.cabilogintoken.select;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import java.util.Map; 
import java.util.Properties;

//import com.ca.usm.domain.user.service.ContactHelper;
import com.ca.usm.plugins.apis.PluginContext;
import com.ca.usm.plugins.apis.forms.FDOption;
import com.ca.usm.plugins.apis.forms.FDSelectDataProvider;
//import com.ca.usm.user.User;

import org.apache.commons.logging.Log;
import java.util.LinkedList;

import com.crystaldecisions.sdk.framework.CrystalEnterprise;
import com.crystaldecisions.sdk.framework.IEnterpriseSession;
import com.crystaldecisions.sdk.framework.ISessionMgr;
import com.crystaldecisions.sdk.framework.ITrustedPrincipal;


public class CABILoginTokenPlugin implements FDSelectDataProvider {
	
	private PluginContext context;
	private Log log;
	private int totalCount = 0;   
	int sessionID = -1;  
	private String userID;
	private String cabiHostName;

	@Override
	public void setContext(PluginContext context) {
		this.context = context;
	    this.log = this.context.getLogger(CABILoginTokenPlugin.class);
	    log.info("Initializing CABILoginTakenPlugin plugin");

	}

	@Override
	public void setInputs(Map<String, Object> inputs) {
		// getting input from plug-in call/variables
		log.debug("setting inputs");
	    userID = (String) inputs.get("userid");
	    cabiHostName = (String) inputs.get("cabihostname");
	    log.debug("Setting input values to CABILoginTakenPlugin plugin");
	}

	@Override
	public List<FDOption> getOptions(int start, int numToReturn) {		
		log.info("Entered into getOptions method");
		String token = getCabiToken();
		List<FDOption> options = new LinkedList<FDOption>();	
		//FDOption option = new FDOption("1", token);
		FDOption option = new FDOption("1", token);
		options.add(option);	  
		totalCount = options.size();
		  
		return options;		
	}

	@Override
	public int totalCount() {
		// TODO Auto-generated method stub
		return 0;
	}
	
	private String getCabiToken()
	{
		 String logonToken = "";
		    /*try { 
		      System.setProperty("bobj.trustedauth.home", System.getProperty("usm.home") + "\\reporting\\cabi");      
		      ISessionMgr sessionMgr = CrystalEnterprise.getSessionMgr();     
		      //String test = "5a1eefbfbd4befbfbdefbfbdefbfbdefbfbd4fefbfbd50efbfbd2befbfbd4b63c2806b00efbfbd0defbfbd5d21efbfbd3a07efbfbdefbfbd4e05efbfbdefbfbd22efbfbdefbfbd2e4cefbfbdefbfbde386adefbfbd52efbfbd1f4fc6aa61d7af78efbfbdefbfbd302befbfbd6d";
		      ITrustedPrincipal trustedPrincipal = sessionMgr.createTrustedPrincipal(userID, cabiHostName);
		      IEnterpriseSession enterpriseSession = sessionMgr.logon(trustedPrincipal);
		      logonToken = enterpriseSession.getLogonTokenMgr().createLogonToken("", 1,1);
		      
		    } catch (Exception e) {
		      log.error("WSMGR", e);
		    }*/
		 
		 Properties prop = new Properties();
	        try
	        {
	            // the configuration file name
	            String fileName = System.getProperty("usm.home") + "\\reporting\\cabi\\TrustedPrincipal.conf";            
	            InputStream is = new FileInputStream(fileName);

	            // load the properties file
	            prop.load(is);

	            // get the value for app.name key
	            String secretKey = prop.getProperty("SharedSecret","");	            
	            if(secretKey != null && secretKey != "")
	            {
		            ISessionMgr sessionMgr = CrystalEnterprise.getSessionMgr();     
				    ITrustedPrincipal trustedPrincipal = sessionMgr.createTrustedPrincipal(userID, cabiHostName,secretKey);
				    IEnterpriseSession enterpriseSession = sessionMgr.logon(trustedPrincipal);
				    logonToken = enterpriseSession.getLogonTokenMgr().createLogonToken("", 1,1);
	            }
	           
	        } catch (Exception e)
	        {
	        	 log.error("Error occurred while reading the TrustedPrincipal.conf file : " + e.getMessage());
	        } 
		    return logonToken;
	}

}

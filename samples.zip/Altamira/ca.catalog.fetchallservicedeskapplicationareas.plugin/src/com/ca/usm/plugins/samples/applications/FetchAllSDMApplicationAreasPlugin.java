package com.ca.usm.plugins.samples.applications;

import com.ca.usm.plugins.apis.PluginContext;
import com.ca.usm.plugins.apis.forms.FDTableDataProvider;
import com.ca.usm.plugins.apis.forms.FDTableRow;
import com.ca.www.UnicenterServicePlus.ServiceDesk.ListResult;
import com.ca.www.UnicenterServicePlus.ServiceDesk.USD_WebServiceLocator;
import com.ca.www.UnicenterServicePlus.ServiceDesk.USD_WebServiceSoap;

import org.apache.axis.encoding.Base64;
import org.apache.commons.logging.Log;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.w3c.dom.Text;
import org.xml.sax.InputSource;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.StringReader;
import java.net.URL;
import java.rmi.RemoteException;
import java.security.InvalidKeyException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.Signature;
import java.security.SignatureException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Vector;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.rpc.ServiceException;

public class FetchAllSDMApplicationAreasPlugin
  implements FDTableDataProvider
{
  private PluginContext context;
  private Log log;
  private int totalCount = 0;
  private USD_WebServiceSoap wsSoap;
  private USD_WebServiceLocator wsLocator;
  private String m_wsUrlFullAddress = "";
  private Map<String, Object> configVals = null;
  int sessionID = -1;
  private String userID;
  private String domain;
  private String ApplicationAreaName;
  private HashMap<String, String> ApplicationNames;
  private ArrayList<String> deleteList;
  private boolean initialSetup = false;
  private Map<String, String> mapped_config_data;
  
  public void setContext(PluginContext context)
  {
    this.context = context;
    this.log = this.context.getLogger(FetchAllSDMApplicationAreasPlugin.class);
  }
  
  public void setInputs(Map<String, Object> inputs)
  {
    this.userID = ((String)inputs.get("userid"));
    this.domain = ((String)inputs.get("domain"));
    this.ApplicationAreaName = ((String)inputs.get("AreaName"));
    this.log.debug("Got UserID" + this.userID + " and Domain " + this.domain);
  }
  
  public List<FDTableRow> getTableRows(int start, int numToReturn, String sortField, boolean sortAscending)
  {
    List<FDTableRow> rows = new LinkedList();
    try
    {
      Map<String, Object> content_config_form_data = this.context.getCatalogConfigValues("ca_cc_reset_config_form", this.domain);
      if (content_config_form_data.size() == 0)
      {
        this.initialSetup = true;
      }
      String[][] dataFromSDM = getApplicationAreasFromSDM();
      if (this.initialSetup)
      {
        for (int i = 0; i < dataFromSDM.length; i++)
        {
          FDTableRow row = new FDTableRow();
          row.setColumnValue("id", dataFromSDM[i][0]);
          row.setColumnValue("key", dataFromSDM[i][1]);
          rows.add(row);
        }
      }
      else
      {
        this.mapped_config_data = generateConfigMap(content_config_form_data);
        this.deleteList = fetchRemovedApplications(this.mapped_config_data.keySet(), dataFromSDM);
        for (int i = 0; i < dataFromSDM.length; i++) {
          if (!this.mapped_config_data.containsKey(dataFromSDM[i][0]))
          {
            FDTableRow row = new FDTableRow();
            row.setColumnValue("id", dataFromSDM[i][0]);
            row.setColumnValue("key", dataFromSDM[i][1]);
            rows.add(row);
          }
          else if(this.ApplicationAreaName.equalsIgnoreCase((String)content_config_form_data.get("AreaName"))) {
            FDTableRow row = new FDTableRow();
            row.setColumnValue("id", dataFromSDM[i][0]);
            row.setColumnValue("key", "update$" + ((String)this.ApplicationNames.get(dataFromSDM[i][0])).toString() + "$" + dataFromSDM[i][1] + "$" + (String)this.mapped_config_data.get(dataFromSDM[i][0]));
            rows.add(row);
          }
          else if (!((String)this.ApplicationNames.get(dataFromSDM[i][0])).toString().equals(dataFromSDM[i][1]))
          {
            FDTableRow row = new FDTableRow();
            row.setColumnValue("id", dataFromSDM[i][0]);
            row.setColumnValue("key", "update$" + ((String)this.ApplicationNames.get(dataFromSDM[i][0])).toString() + "$" + dataFromSDM[i][1] + "$" + (String)this.mapped_config_data.get(dataFromSDM[i][0]));
            rows.add(row);
          }
        }
        for (int i = 0; i < this.deleteList.size(); i++)
        {
          FDTableRow row = new FDTableRow();
          row.setColumnValue("id", ((String)this.deleteList.get(i)).toString());
          row.setColumnValue("key", "delete$" + (String)this.ApplicationNames.get(((String)this.deleteList.get(i)).toString()) + "$" + (String)this.ApplicationNames.get(((String)this.deleteList.get(i)).toString()) + "$" + (String)this.mapped_config_data.get(((String)this.deleteList.get(i)).toString()));
          rows.add(row);
        }
      }
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
    return rows;
  }
  
  private ArrayList fetchRemovedApplications(Set keySet, String[][] data)
  {
    Iterator<String> itr = keySet.iterator();
    HashSet<String> keys = new HashSet();
    ArrayList<String> deleteList = new ArrayList();
    for (int i = 0; i < data.length; i++) {
      keys.add(data[i][0]);
    }
    while (itr.hasNext())
    {
      String id = (String)itr.next();
      if (!keys.contains(id)) {
        deleteList.add(id);
      }
    }
    return deleteList;
  }
  
  public int totalCount()
  {
    return 0;
  }
  
  private String[][] getApplicationAreasFromSDM()
    throws Exception
  {
    String[][] data = (String[][])null;
    

    this.configVals = this.context.getSystemConfigValues("servicedesk");
    if ((this.configVals == null) || (this.configVals.size() < 1)) {
      return data;
    }
    String sdHostName = this.configVals.get("hostname").toString();
    if ((sdHostName == null) || (sdHostName == "")) {
      throw new Exception("ServiceDesk is not configured");
    }
    this.log.debug("Got HostName" + sdHostName);
    

    String sdPortNo = this.configVals.get("portno").toString();
    this.log.debug("Got sdPortNo" + sdPortNo);
    

    String sdWSbasepath = this.configVals.get("wsbasepath").toString();
    this.log.debug("Got sdWSbasepath" + sdWSbasepath);
    

    String sdIsHttpsEnabled = this.configVals.get("enablehttps").toString();
    this.log.debug("Got sdIsHttpsEnabled" + sdIsHttpsEnabled);
    if (sdIsHttpsEnabled.equals("false")) {
      this.m_wsUrlFullAddress = ("http://" + sdHostName + ":" + sdPortNo + "/" + sdWSbasepath + "?wsdl");
    } else {
      this.m_wsUrlFullAddress = ("https://" + sdHostName + ":" + sdPortNo + "/" + sdWSbasepath + "?wsdl");
    }
    this.log.debug("Generated URL" + this.m_wsUrlFullAddress);
    

    String ispkiEnabled = this.configVals.get("enablepki").toString();
    this.log.debug("Got ispkiEnabled " + ispkiEnabled);
    if (ispkiEnabled.equals("true")) {
      this.sessionID = loginMethodPki();
    } else {
      this.sessionID = loginMethodUserPass();
    }
    this.wsLocator = new USD_WebServiceLocator();
    
    this.wsLocator.setUSD_WebServiceSoapEndpointAddress(this.m_wsUrlFullAddress);
    this.wsSoap = this.wsLocator.getUSD_WebServiceSoap();
    
    this.sessionID = this.wsSoap.impersonate(this.sessionID, this.userID);
    
    USD_WebServiceLocator ws = new USD_WebServiceLocator();
    URL url = new URL(this.m_wsUrlFullAddress);
    USD_WebServiceSoap usd = ws.getUSD_WebServiceSoap(url);
    if (this.sessionID <= 0) {
      this.log.debug("login failed");
    } else {
      this.log.debug("login() succeeded. SID: " + this.sessionID);
    }
    ListResult doQueryResult = new ListResult();
    doQueryResult = usd.doQuery(this.sessionID, "pcat", "sym like '" + this.ApplicationAreaName + ".%' and ss_include=1 and delete_flag=0");
    int listHandle = doQueryResult.getListHandle();
    int listLength = doQueryResult.getListLength();
    
    int startIndex = 0;
    String lResult = usd.getListValues(this.sessionID, listHandle, startIndex, listLength - 1, new String[] { "id", "ss_sym" });
    
    usd.freeListHandles(this.sessionID, new int[] { listHandle });
    

    usd.logout(this.sessionID);
    data = retrieve_attribute_values(lResult, listLength);
    
    return data;
  }
  
  private int loginMethodPki()
    throws UnrecoverableKeyException, KeyStoreException, NoSuchAlgorithmException, CertificateException, FileNotFoundException, IOException, InvalidKeyException, SignatureException, ServiceException
  {
    this.log.trace("begin:loginMethodPki");
    

    this.wsLocator = new USD_WebServiceLocator();
    
    this.wsLocator.setUSD_WebServiceSoapEndpointAddress(this.m_wsUrlFullAddress);
    

    this.log.trace("begin:loginMethodPki-2:" + this.m_wsUrlFullAddress);
    
    this.wsSoap = this.wsLocator.getUSD_WebServiceSoap();
    

    KeyStore ks = KeyStore.getInstance("PKCS12");
    

    String keyFileName = this.configVals.get("ws_key_filename").toString();
    this.log.debug("keyFileName" + keyFileName);
    
    String m_keyFilePath = System.getProperty("usm.home") + File.separator + keyFileName;
    this.log.debug("keyFilePath" + m_keyFilePath);
    



    ks.load(new FileInputStream(m_keyFilePath), null);
    

    String m_policyCode = this.configVals.get("ws_policy_code").toString();
    this.log.debug("policyCode" + m_policyCode);
    


    char[] privateKeyPassword = m_policyCode.toCharArray();
    



    PrivateKey key = (PrivateKey)ks.getKey("servicedesk " + m_policyCode.toLowerCase(), privateKeyPassword);
    


    Signature s = Signature.getInstance("SHA1withRSA");
    

    s.initSign(key);
    

    s.update(m_policyCode.getBytes());
    

    byte[] sig = s.sign();
    


    String encryption = Base64.encode(sig);
    
    String sessionid = this.wsSoap.loginServiceManaged(m_policyCode, encryption);
    

    int SID = Integer.parseInt(sessionid);
    this.log.trace("end:loginMethodPki");
    
    return SID;
  }
  
  private int loginMethodUserPass()
    throws RemoteException, ServiceException
  {
    this.log.trace("begin:loginMethodUserPass");
    
    this.wsLocator = new USD_WebServiceLocator();
    this.wsLocator.setUSD_WebServiceSoapEndpointAddress(this.m_wsUrlFullAddress);
    this.wsSoap = this.wsLocator.getUSD_WebServiceSoap();
    String m_username = this.configVals.get("login").toString();
    this.log.debug("Got username" + m_username);
    String m_password = this.configVals.get("password").toString();
    
    int SID = this.wsSoap.login(m_username, m_password);
    this.log.trace("end:loginMethodUserPass");
    return SID;
  }
  
  private String[][] retrieve_attribute_values(String result, int listLength)
  {
    this.log.debug("begin:retrieve_attribute_values");
    String[][] returnData = new String[listLength][1];
    int index = 0;
    try
    {
      DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
      DocumentBuilder db = dbf.newDocumentBuilder();
      Document doc = db.parse(new InputSource(new StringReader(result)));
      Element root = doc.getDocumentElement();
      NodeList udsObjectList = root.getElementsByTagName("UDSObject");
      int udsObjectListLength = udsObjectList.getLength();
      for (int j = 0; j < udsObjectListLength; j++)
      {
        Element udsObjectElement = (Element)udsObjectList.item(j);
        
        NodeList attributesList = udsObjectElement.getElementsByTagName("Attributes");
        String outString = "";
        if (attributesList.getLength() > 0)
        {
          Element attributesElement = (Element)attributesList.item(0);
          NodeList attributeList = attributesElement.getElementsByTagName("Attribute");
          for (int i = 0; i < attributeList.getLength(); i++)
          {
            Element attributeElement = (Element)attributeList.item(i);
            NodeList attrNameList = attributeElement.getElementsByTagName("AttrName");
            
            Element attrNameElement = (Element)attrNameList.item(0);
            Text attrNameText = (Text)attrNameElement.getFirstChild();
            String attrNameString = attrNameText.getNodeValue();
            

            NodeList attrValueList = attributeElement.getElementsByTagName("AttrValue");
            Element attrValueElement = (Element)attrValueList.item(0);
            Text attrValueText = (Text)attrValueElement.getFirstChild();
            String attrValueString = "";
            if (attrValueText != null) {
              attrValueString = attrValueText.getNodeValue();
            }
            if (i > 0) {
              outString = outString + ",";
            }
            outString = outString + attrValueString;
          }
          if (index < listLength) {
            returnData[(index++)] = outString.split(",");
          }
        }
      }
    }
    catch (Exception ex)
    {
      this.log.debug("Exception occurred:" + ex.getMessage());
      ex.printStackTrace(System.out);
    }
    return returnData;
  }
  
  private Map<String, String> generateConfigMap(Map defaultMap)
  {
    HashMap<String, String> configMap = new HashMap();
    this.ApplicationNames = new HashMap();
    int size = 0;
    for (int i = 1; i <= defaultMap.size(); i++) {
      if (defaultMap.containsKey("links_config_table-id--" + i)) {
        size++;
      }
    }
    for (int i = 1; i <= size; i++)
    {
      String key = (String)defaultMap.get("links_config_table-id--" + i);
      String value = (String)defaultMap.get("links_config_table-links--" + i);
      Vector reset =  (Vector)defaultMap.get("links_config_table-ResetType--" + i);
      
      String resetValue ="1";
      
      if(reset != null && reset.size() >0 && reset.get(0) != null && (((String)reset.get(0))).length() > 0)
        resetValue = ((String)reset.get(0)).substring(0,1);
      
      value = value+"$"+resetValue;
      this.ApplicationNames.put(key, (String)defaultMap.get("links_config_table-key--" + i));
      configMap.put(key, value);
    }
    return configMap;
  }
}

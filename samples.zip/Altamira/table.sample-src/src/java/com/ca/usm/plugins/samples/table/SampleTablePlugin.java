package com.ca.usm.plugins.samples.table;

import com.ca.usm.plugins.apis.PluginContext;
import com.ca.usm.plugins.apis.forms.FDTableDataProvider;
import com.ca.usm.plugins.apis.forms.FDTableRow;

import org.apache.commons.logging.Log;

import java.util.Arrays;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

public class SampleTablePlugin implements FDTableDataProvider {

  private PluginContext context;
  private Log log;

  private int totalCount;

  @Override
  public void setContext(PluginContext context) {
    this.context = context;
    this.log = this.context.getLogger(SampleTablePlugin.class);
  }

  @Override
  public void setInputs(Map<String, Object> input) {
    // Not used in this example. Inputs are returned from the Report/Plugin
    // Variables attribute of the table and can be used to pass extra
    // information to the plugin

    // this.inputs = inputs;
  }

  @Override
  public List<FDTableRow> getTableRows(int start, int numToReturn, final String sortField, final boolean sortAscending) {
    log.trace("Fetching table rows");

    List<FDTableRow> rows = new LinkedList<FDTableRow>();

    // Fetch data from source. In this example the data is hard-coded, in actual
    // use cases this call would be replaced to a call to a database or web
    // service to fetch data. Also in this example we fetch all the data
    // everytime which would not be efficient in real world scenarios. In most
    // cases we would pass the start, numToReturn, sortField, sortAscending
    // fields to the datasource to reduce the amount of data we would fetch from
    // the data source
    String[][] data = getData();

    if (log.isDebugEnabled()) log.debug("Fetched data:" + Arrays.asList(data));

    // Map data returned into FDTableRow objects
    for (int i = 0; i < data.length; i++) {
      if (i < start || i >= start + numToReturn)
        continue;
      
      FDTableRow row = new FDTableRow();

      row.setColumnValue("first_name", data[i][0]);
      row.setColumnValue("last_name", data[i][1]);
      row.setColumnValue("date_added", new Date().getTime() + "");
      row.setColumnValue("label", "label " + i);
      row.setColumnValue("role", data[i][2]);

      rows.add(row);
    }
    
    return rows;
  }

  /**
   * @return total number of records available in the data source
   */
  @Override
  public int totalCount() {
    return getData().length;
  }

  private String[][] getData() {
    return new String[][] {
            { "Joshua", "Abare", "administrator" },
            { "Jim", "Adams", "catadministrator" },
            { "Sam", "Alford", "catalogenduser" },
            { "Alverson", "Perla", "enduser" },
            { "Edwin", "Anshutz", "requestmanager" },
            { "Vincent", "Baas", "servicemanager" },
            { "Joel", "Barthold", "spadministrator" },
            { "Donald", "Bell", "stadministrator" } };
  }
}
